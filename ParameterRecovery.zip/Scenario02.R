# Run or resume Scenario02.
ScriptDirectory <- local({
  Paths <- unlist(lapply(sys.frames(), function(Frame) Frame$ofile), use.names = FALSE)
  Arguments <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (length(Paths)) {
    dirname(normalizePath(tail(Paths, 1), winslash = "/", mustWork = TRUE))
  } else if (length(Arguments)) {
    dirname(normalizePath(sub("^--file=", "", Arguments[1]), winslash = "/", mustWork = TRUE))
  } else {
    stop("Run this script with source() or Rscript.", call. = FALSE)
  }
})
source(file.path(ScriptDirectory, "CustomSimulation.R"))

SimulationSummary <- RunCustomScenarios(2)