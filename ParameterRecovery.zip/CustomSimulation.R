# Parameter recovery for a joint recurrence and mortality model.

SimulationSettings <- list(
  Replications = 500,  # Total replications per scenario.
  Seed = 20261010,
  CoreFraction = 0.60,
  MaxConcurrentFits = Inf,
  Chains = 2,
  Warmup = 2000,
  Sampling = 8000,  # Iterations per chain in each assessment or sampling block.
  MaximumWarmupBlocks = 5,
  MaximumSamplingBlocks = 5,
  FixedEffectSd = 5,
  AlphaSd = 5,
  FrailtyShape = 0.5,
  FrailtyRate = 0.05,
  BaselineLogMean = 0,
  BaselineLogSd = 5,
  BlockMoves = TRUE,
  MinimumEss = 400,
  MaximumRhat = 1.05,
  OutputFolder = "SimulationResults",
  InstallMissingPackages = TRUE
)

CustomSimulationVersion <- 3
CustomProgramPath <- local({
  Paths <- unlist(lapply(sys.frames(), function(Frame) Frame$ofile), use.names = FALSE)
  Arguments <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (length(Paths)) normalizePath(tail(Paths, 1), winslash = "/", mustWork = TRUE)
  else if (length(Arguments)) normalizePath(sub("^--file=", "", Arguments[1]), winslash = "/", mustWork = TRUE)
  else ""
})

GetSimulationScenario <- function(Index) {
  if (length(Index) != 1 || !is.numeric(Index) || is.na(Index) || !Index %in% 1:4) {
    stop("Choose scenario 1, 2, 3 or 4.", call. = FALSE)
  }
  N <- c(200, 200, 300, 300)[Index]
  CheckSimulationScenario(list(
    Name = sprintf("Scenario%02d", Index),
    Participants = N,
    ActiveParticipants = N/2,
    AgeProbability = 0.50,
    Cutpoints = seq(0, 4.5, length.out = 5),
    RecurrenceRates = c(0.510, 0.565, 0.610, 0.650),
    DeathRates = c(0.0575, 0.0675, 0.0775, 0.0875),
    BetaR = log(0.75), GammaR = log(1.25),
    BetaD = log(0.70), GammaD = log(1.50),
    Alpha = c(0.50, 0.90, 0.50, 0.90)[Index],
    FrailtyVariance = 1.00,
    CensoringRate = 0.17,
    BaselineTimes = c(2, 4.5)
  ))
}

GetFrailtyPriorSummary <- function(Shape = SimulationSettings$FrailtyShape,
    Rate = SimulationSettings$FrailtyRate) {
  if (length(Shape) != 1 || length(Rate) != 1 ||
      any(!is.finite(c(Shape, Rate))) || Shape <= 0 || Rate <= 0) {
    stop("Frailty shape and rate must be positive.", call. = FALSE)
  }
  Probabilities <- c(0.025, 0.5, 0.975)
  Precision <- stats::qgamma(Probabilities, shape = Shape, rate = Rate)
  Variance <- 1/rev(Precision)
  data.frame(Quantity = c("Precision", "Variance", "Standard deviation"),
    Shape = Shape, Rate = Rate,
    Lower = c(Precision[1], Variance[1], sqrt(Variance[1])),
    Median = c(Precision[2], Variance[2], sqrt(Variance[2])),
    Upper = c(Precision[3], Variance[3], sqrt(Variance[3])))
}

CheckSimulationScenario <- function(Scenario) {
  Required <- c("Name", "Participants", "ActiveParticipants", "AgeProbability", "Cutpoints",
    "RecurrenceRates", "DeathRates", "BetaR", "GammaR", "BetaD", "GammaD",
    "Alpha", "FrailtyVariance", "CensoringRate", "BaselineTimes")
  if (!is.list(Scenario) || !setequal(names(Scenario), Required)) {
    stop("The scenario has missing or unknown settings.", call. = FALSE)
  }
  if (!is.character(Scenario$Name) || length(Scenario$Name) != 1 ||
      !grepl("^[A-Za-z][A-Za-z0-9]*$", Scenario$Name)) stop("Use a simple scenario name.", call. = FALSE)
  Numeric <- unlist(Scenario[setdiff(Required, "Name")], use.names = FALSE)
  if (!is.numeric(Numeric) || any(!is.finite(Numeric))) stop("Scenario values must be finite numbers.", call. = FALSE)
  Scalars <- setdiff(Required, c("Name", "Cutpoints", "RecurrenceRates", "DeathRates", "BaselineTimes"))
  if (any(lengths(Scenario[Scalars]) != 1)) stop("A scenario setting must be a single number.", call. = FALSE)
  N <- Scenario$Participants
  A <- Scenario$ActiveParticipants
  if (N < 20 || N != floor(N) || A < 2 || A > N - 2 || A != floor(A)) stop("Invalid arm sizes.", call. = FALSE)
  if (Scenario$AgeProbability <= 0 || Scenario$AgeProbability >= 1 || Scenario$FrailtyVariance <= 0 ||
      Scenario$CensoringRate < 0) stop("Invalid covariate, frailty or censoring setting.", call. = FALSE)
  Cutpoints <- Scenario$Cutpoints
  K <- length(Cutpoints) - 1
  if (K < 1 || Cutpoints[1] != 0 || any(diff(Cutpoints) <= 0)) {
    stop("Cutpoints must start at zero and increase strictly.", call. = FALSE)
  }
  if (length(Scenario$RecurrenceRates) != K || length(Scenario$DeathRates) != K ||
      any(c(Scenario$RecurrenceRates, Scenario$DeathRates) <= 0)) stop("Supply one positive rate per interval for each process.", call. = FALSE)
  if (!length(Scenario$BaselineTimes) || anyDuplicated(Scenario$BaselineTimes) ||
      any(Scenario$BaselineTimes <= 0 | Scenario$BaselineTimes > tail(Cutpoints, 1))) {
    stop("Baseline assessment times must lie within follow-up.", call. = FALSE)
  }
  Scenario[Required]
}

GetSimulationSeed <- function(Seed, Replication, Stream) {
  Value <- Seed + 100000*Replication + Stream
  if (any(!is.finite(Value)) || any(Value <= 0 | Value >= .Machine$integer.max)) stop("Simulation seed is out of range.", call. = FALSE)
  Value
}

SetSimulationSeed <- function(Seed) {
  set.seed(Seed, kind = "Mersenne-Twister", normal.kind = "Inversion", sample.kind = "Rejection")
}

GetSimulationTruth <- function(Scenario) {
  Truth <- c(BetaR = Scenario$BetaR, GammaR = Scenario$GammaR,
    BetaD = Scenario$BetaD, GammaD = Scenario$GammaD, Alpha = Scenario$Alpha,
    FrailtyVariance = Scenario$FrailtyVariance, FrailtyPrecision = 1/Scenario$FrailtyVariance)
  Truth <- c(Truth, setNames(log(Scenario$RecurrenceRates), paste0("RecurrenceLogRate", seq_along(Scenario$RecurrenceRates))),
    setNames(log(Scenario$DeathRates), paste0("DeathLogRate", seq_along(Scenario$DeathRates))))
  for (Index in seq_along(Scenario$BaselineTimes)) {
    Time <- Scenario$BaselineTimes[Index]
    Exposure <- pmax(0, pmin(Time, tail(Scenario$Cutpoints, -1)) - head(Scenario$Cutpoints, -1))
    Truth[paste0("RecurrenceCumulative", Index)] <- sum(Exposure*Scenario$RecurrenceRates)
    Truth[paste0("DeathCumulative", Index)] <- sum(Exposure*Scenario$DeathRates)
  }
  data.frame(Parameter = names(Truth), Truth = unname(Truth), stringsAsFactors = FALSE)
}

GenerateSimulationData <- function(Scenario, Seed) {
  SetSimulationSeed(Seed)
  N <- Scenario$Participants
  Cutpoints <- Scenario$Cutpoints
  Horizon <- tail(Cutpoints, 1)
  Treatment <- sample(c(rep(1, Scenario$ActiveParticipants), rep(0, N - Scenario$ActiveParticipants)))
  Age60 <- stats::rbinom(N, 1, Scenario$AgeProbability)
  Frailty <- stats::rnorm(N, 0, sqrt(Scenario$FrailtyVariance))
  # Death is generated by cumulative hazard inversion. Beyond Horizon, only
  # survival through Horizon is required. Inf is an internal sentinel.
  DeathMultiplier <- exp(Scenario$BetaD*Treatment + Scenario$GammaD*Age60 + Scenario$Alpha*Frailty)
  Remaining <- stats::rexp(N)
  DeathTime <- rep(Inf, N)
  for (K in seq_along(Scenario$DeathRates)) {
    Rate <- Scenario$DeathRates[K]*DeathMultiplier
    Increment <- Rate*(Cutpoints[K + 1] - Cutpoints[K])
    Alive <- is.infinite(DeathTime)
    Hit <- Alive & Remaining <= Increment
    DeathTime[Hit] <- Cutpoints[K] + Remaining[Hit]/Rate[Hit]
    Remaining[Alive & !Hit] <- Remaining[Alive & !Hit] - Increment[Alive & !Hit]
  }
  Censoring <- if (Scenario$CensoringRate == 0) rep(Inf, N) else stats::rexp(N, Scenario$CensoringRate)
  Stop <- pmin(DeathTime, Censoring, Horizon)
  Death <- as.numeric(DeathTime <= Censoring & DeathTime <= Horizon)
  Exposure <- GetSimulationExposure(rep(0, N), Stop, Cutpoints)
  RateR <- exp(Scenario$BetaR*Treatment + Scenario$GammaR*Age60 + Frailty)
  Means <- sweep(Exposure, 2, Scenario$RecurrenceRates, "*")*RateR
  Counts <- matrix(stats::rpois(length(Means), as.vector(Means)), nrow = N)
  if (any(!is.finite(Counts))) stop("Invalid generated counts.", call. = FALSE)
  Patients <- data.frame(Id = seq_len(N), Treatment = Treatment, Age60 = Age60,
    Start = 0, Stop = Stop, Death = Death, Count = rowSums(Counts))
  Index <- which(Exposure > 0, arr.ind = TRUE)
  Cells <- data.frame(Id = Index[, 1], Interval = Index[, 2], Exposure = Exposure[Index],
    Recurrence = Counts[Index], Death = 0)
  Cells <- Cells[order(Cells$Id, Cells$Interval), ]
  DeathIds <- which(Death == 1)
  if (length(DeathIds)) {
    Bins <- as.integer(cut(Stop[DeathIds], Cutpoints, right = TRUE, include.lowest = TRUE))
    Positions <- match(paste(DeathIds, Bins), paste(Cells$Id, Cells$Interval))
    if (anyNA(Positions)) stop("A generated death has no risk interval.", call. = FALSE)
    Cells$Death[Positions] <- 1
  }
  Cells$Treatment <- Treatment[Cells$Id]
  Cells$Age60 <- Age60[Cells$Id]
  if (any(Cells$Exposure <= 0) || sum(Cells$Death) != sum(Death) ||
      sum(Cells$Recurrence) != sum(Patients$Count) || abs(sum(Cells$Exposure) - sum(Stop)) > 1e-8) {
    stop("Generated exposure and counts are inconsistent.", call. = FALSE)
  }
  # Cell counts are sufficient for these piecewise constant hazards. No event
  # times, outcomes after censoring, or generated frailties are given to the fit.
  Summary <- data.frame(Participants = N, ActiveParticipants = sum(Treatment),
    AgeProportion = mean(Age60), Recurrences = sum(Patients$Count),
    Deaths = sum(Death), PersonYears = sum(Stop),
    CensoredEarly = sum(Death == 0 & Stop < Horizon),
    ReachedEnd = sum(Stop == Horizon), ZeroCounts = sum(Patients$Count == 0),
    MaximumCount = max(Patients$Count))
  list(Patients = Patients, Cells = Cells, Summary = Summary)
}

GetSimulationExposure <- function(Start, Stop, Cutpoints) {
  if (length(Start) != length(Stop) || any(!is.finite(c(Start, Stop))) ||
      any(Start < 0) || any(Stop < Start) || any(Stop > tail(Cutpoints, 1))) {
    stop("Risk interval times are invalid.", call. = FALSE)
  }
  Exposure <- vapply(seq_len(length(Cutpoints) - 1), function(Index) {
    pmax(0, pmin(Stop, Cutpoints[Index + 1]) - pmax(Start, Cutpoints[Index]))
  }, numeric(length(Start)))
  matrix(Exposure, nrow = length(Start), ncol = length(Cutpoints) - 1)
}

SimulationHash <- function(Object) {
  Path <- tempfile("SimulationHash")
  on.exit(unlink(Path), add = TRUE)
  saveRDS(Object, Path, compress = FALSE, version = 2)
  unname(tools::md5sum(Path))
}

SaveSimulationRds <- function(Object, Path) {
  Partial <- paste0(Path, ".part")
  saveRDS(Object, Partial, compress = "gzip", version = 2)
  Backup <- paste0(Path, ".previous")
  if (file.exists(Backup)) unlink(Backup)
  if (file.exists(Path) && !file.rename(Path, Backup)) stop("Cannot replace a checkpoint. Close files using it.")
  if (!file.rename(Partial, Path)) {
    if (file.exists(Backup)) file.rename(Backup, Path)
    stop("Cannot save the checkpoint.")
  }
  if (file.exists(Backup)) unlink(Backup)
  invisible(Path)
}

ReadSavedSimulation <- function(Path) {
  if (!file.exists(Path) && file.exists(paste0(Path, ".previous"))) {
    if (!file.rename(paste0(Path, ".previous"), Path)) stop("Cannot recover a saved checkpoint.")
  }
  readRDS(Path)
}

BuildCustomData <- function(Data, Scenario, Settings = SimulationSettings) {
  K <- length(Scenario$Cutpoints) - 1
  Exposure <- t(vapply(Scenario$BaselineTimes, function(Time) {
    pmax(0, pmin(Time, tail(Scenario$Cutpoints, -1)) - head(Scenario$Cutpoints, -1))
  }, numeric(K)))
  list(Participants = nrow(Data$Patients), Cells = nrow(Data$Cells), Intervals = K,
    Times = length(Scenario$BaselineTimes), Id = as.integer(Data$Cells$Id),
    Bin = as.integer(Data$Cells$Interval), CountR = as.integer(Data$Cells$Recurrence),
    CountD = as.integer(Data$Cells$Death), X = as.matrix(Data$Cells[, c("Treatment", "Age60")]),
    LogExposure = log(Data$Cells$Exposure), BaselineExposure = Exposure,
    BaselineLogMean = Settings$BaselineLogMean, BaselineLogSd = Settings$BaselineLogSd,
    FixedSd = Settings$FixedEffectSd, AlphaSd = Settings$AlphaSd,
    FrailtyShape = Settings$FrailtyShape, FrailtyRate = Settings$FrailtyRate)
}

CustomComponents <- function(P, D) {
  B <- P$FrailtyStandard*exp(-P$LogFrailtyPrecision/2)
  Coefficients <- c(P$BetaR, P$GammaR, P$BetaD, P$GammaD)
  EtaR <- D$LogExposure + P$RecurrenceLogRate[D$Bin] + B[D$Id] +
    as.vector(D$X %*% Coefficients[1:2])
  EtaD <- D$LogExposure + P$DeathLogRate[D$Bin] + P$Alpha*B[D$Id] +
    as.vector(D$X %*% Coefficients[3:4])
  list(R = P$RecurrenceLogRate, D = P$DeathLogRate, B = B,
    EtaR = EtaR, EtaD = EtaD, Coefficients = Coefficients)
}

CustomDensityR <- function(P, D) {
  C <- CustomComponents(P, D)
  LogPrecision <- P$LogFrailtyPrecision
  Value <- sum(stats::dpois(D$CountR, exp(C$EtaR), log = TRUE)) +
    sum(stats::dpois(D$CountD, exp(C$EtaD), log = TRUE)) +
    sum(stats::dnorm(C$Coefficients, 0, D$FixedSd, log = TRUE)) +
    stats::dnorm(P$Alpha, 0, D$AlphaSd, log = TRUE) +
    sum(stats::dnorm(c(C$R, C$D), D$BaselineLogMean, D$BaselineLogSd, log = TRUE))
  # Evaluate the density in precision and actual frailties, then add the
  # Jacobians for log precision and the standardized Gaussian frailties.
  Value + stats::dgamma(exp(LogPrecision), D$FrailtyShape, D$FrailtyRate, log = TRUE) +
    LogPrecision + sum(stats::dnorm(C$B, 0, exp(-LogPrecision/2), log = TRUE)) -
    D$Participants*LogPrecision/2
}

GetCustomInitial <- function(Data, D) {
  RateR <- max(sum(Data$Cells$Recurrence)/sum(Data$Patients$Stop), 0.01)
  RateD <- max(sum(Data$Patients$Death)/sum(Data$Patients$Stop), 0.001)
  list(BetaR = 0, GammaR = 0, BetaD = 0, GammaD = 0, Alpha = 0.3,
    LogFrailtyPrecision = 0, RecurrenceLogRate = rep(log(RateR), D$Intervals),
    DeathLogRate = rep(log(RateD), D$Intervals), FrailtyStandard = rep(0, D$Participants))
}

CustomVariableMap <- function(Scenario) {
  Names <- GetSimulationTruth(Scenario)$Parameter
  Variables <- Names
  for (Base in c("RecurrenceLogRate", "DeathLogRate", "RecurrenceCumulative", "DeathCumulative")) {
    Index <- startsWith(Names, Base)
    Variables[Index] <- paste0(Base, "[", substring(Names[Index], nchar(Base) + 1), "]")
  }
  setNames(Variables, Names)
}

SummarizeCustomMatrix <- function(X) {
  Q <- stats::quantile(as.numeric(X), c(0.025, 0.5, 0.975), names = FALSE)
  Qse <- posterior::mcse_quantile(X, probs = c(0.025, 0.975), names = FALSE)
  c(Mean = mean(X), Sd = stats::sd(as.numeric(X)), Lower = Q[1], Median = Q[2], Upper = Q[3],
    MeanMonteCarloSe = posterior::mcse_mean(X), SdMonteCarloSe = posterior::mcse_sd(X),
    LowerMonteCarloSe = Qse[1], UpperMonteCarloSe = Qse[2],
    Rhat = posterior::rhat(X), BulkEss = posterior::ess_bulk(X), TailEss = posterior::ess_tail(X))
}

BindSimulationRows <- function(Rows) {
  Rows <- Filter(function(X) is.data.frame(X) && nrow(X) > 0, Rows)
  if (!length(Rows)) return(data.frame())
  Columns <- unique(unlist(lapply(Rows, names), use.names = FALSE))
  Rows <- lapply(Rows, function(X) {
    for (Name in setdiff(Columns, names(X))) X[[Name]] <- NA
    X[Columns]
  })
  Output <- do.call(rbind, Rows)
  rownames(Output) <- NULL
  Output
}

SimulationParameterLabel <- function(Name, Scenario) {
  Labels <- c(BetaR = "$\\beta_R$", GammaR = "$\\gamma_R$", BetaD = "$\\beta_D$",
    GammaD = "$\\gamma_D$", Alpha = "$\\alpha$", FrailtyVariance = "$\\sigma^2$",
    FrailtyPrecision = "$\\xi$")
  if (Name %in% names(Labels)) return(unname(Labels[Name]))
  if (grepl("Cumulative", Name)) {
    Index <- as.numeric(sub(".*Cumulative", "", Name))
    Symbol <- if (startsWith(Name, "Recurrence")) "\\Lambda_0" else "H_0"
    return(paste0("$", Symbol, "\\left(", Scenario$BaselineTimes[Index], "\\right)$"))
  }
  Index <- sub(".*LogRate", "", Name)
  paste0("$", if (startsWith(Name, "Recurrence")) "r" else "d", "_{", Index, "}$")
}

SimulationLatexNumber <- function(Value, Digits = 3) {
  if (length(Value) != 1 || !is.finite(Value)) return("{--}")
  if (abs(Value) < 0.5*10^-Digits) Value <- 0
  formatC(Value, format = "f", digits = Digits, decimal.mark = ".")
}

SimulationLatexColumn <- function(Values, Digits = 3) {
  Values <- Values[is.finite(Values)]
  IntegerDigits <- if (length(Values)) max(1, nchar(format(floor(max(abs(round(Values, Digits)))), scientific = FALSE, trim = TRUE))) else 1
  paste0("S[table-format=", if (any(Values < 0)) "-" else "", IntegerDigits, ".", Digits, "]")
}

WriteSimulationResultTable <- function(Data, Design, Parameters, Path, Caption, Label, Long = FALSE) {
  if (!nrow(Data)) {
    writeLines("% No parameter estimates are available.", Path)
    return(invisible(Path))
  }
  Data <- Data[Data$Subset == "AllFinite" & Data$Parameter %in% Parameters, ]
  if (!nrow(Data)) {
    writeLines("% No parameter estimates are available for this table.", Path)
    return(invisible(Path))
  }
  Specification <- paste("@{}l", SimulationLatexColumn(Data$Truth),
    SimulationLatexColumn(Data$Bias), "@{\\, (}", SimulationLatexColumn(Data$BiasMonteCarloSe), "@{)\\hspace{2\\tabcolsep}}",
    SimulationLatexColumn(Data$Rmse), SimulationLatexColumn(Data$EmpiricalSd),
    SimulationLatexColumn(Data$MeanPosteriorSd), SimulationLatexColumn(100*Data$Coverage, 1),
    "@{\\, (}", SimulationLatexColumn(100*Data$CoverageMonteCarloSe, 1), "@{)}")
  Header <- paste0("{Parameter} & {Truth} & \\multicolumn{2}{c}{Bias (MCSE)} & {RMSE} & ",
    "{Emp. SD} & {Post. SD} & \\multicolumn{2}{c}{\\shortstack{Coverage\\\\(MCSE)}} \\\\")
  Note <- paste0("Bias and RMSE use posterior means. Emp. SD is the empirical standard deviation of those means; ",
    "Post. SD is the average posterior standard deviation. Coverage is the percentage of 95\\% credible intervals containing ",
    "the generating value. Parentheses contain Monte Carlo standard errors, in percentage points for coverage. ",
    "Failed fits and unavailable parameters are excluded from each ",
    "parameter's denominator and reported separately; numerical review flags do not exclude estimates. ",
    "A displayed MCSE of zero at 0\\% or 100\\% coverage does not imply zero uncertainty; Wilson intervals are reported separately.")
  if (any(grepl("Cumulative", Parameters))) {
    Note <- paste(Note, "Cumulative baselines are evaluated at zero log frailty and reference covariate values. Their intervals use all retained joint draws.")
  }
  Lines <- c(if (!Long) "\\begin{table}[!htbp]", "\\begingroup", if (!Long) "\\centering",
    "\\small", "\\setlength{\\tabcolsep}{4pt}", "\\renewcommand{\\arraystretch}{1.08}",
    "\\captionsetup{justification=justified,singlelinecheck=false,font=small}")
  if (Long) {
    Lines <- c(Lines, "\\setlength{\\LTleft}{\\fill}", "\\setlength{\\LTright}{\\fill}",
      paste0("\\begin{longtable}{", Specification, "}"),
      paste0("\\caption{", Caption, "}\\label{", Label, "}\\\\"), "\\toprule", Header, "\\midrule", "\\endfirsthead",
      "\\multicolumn{9}{l}{\\tablename~\\thetable\\ (continued)}\\\\", "\\toprule", Header, "\\midrule", "\\endhead",
      "\\midrule", "\\multicolumn{9}{r}{\\footnotesize Continued on the next page}\\\\", "\\endfoot",
      "\\bottomrule", "\\endlastfoot")
  } else {
    Lines <- c(Lines, paste0("\\caption{", Caption, "}"), paste0("\\label{", Label, "}"),
      paste0("\\begin{tabular}{", Specification, "}"), "\\toprule", Header, "\\midrule")
  }
  for (Name in names(Design)) {
    D <- Data[Data$Scenario == Name, ]
    if (!nrow(D)) next
    D <- D[order(match(D$Parameter, Parameters)), ]
    S <- Design[[Name]]$Scenario
    Lines <- c(Lines, paste0("\\multicolumn{9}{@{}l}{\\textbf{\\boldmath$n=", S$Participants,
      "$ and $\\alpha=", formatC(S$Alpha, format = "f", digits = 1), "$}}\\\\*"))
    for (Index in seq_len(nrow(D))) {
      P <- D[Index, ]
      Values <- c(P$Truth, P$Bias, P$BiasMonteCarloSe, P$Rmse, P$EmpiricalSd,
        P$MeanPosteriorSd, 100*P$Coverage, 100*P$CoverageMonteCarloSe)
      Cells <- mapply(SimulationLatexNumber, Values, c(rep(3, 6), 1, 1), USE.NAMES = FALSE)
      Lines <- c(Lines, paste0(paste(c(SimulationParameterLabel(P$Parameter, S), Cells), collapse = " & "), " \\\\"))
    }
    Lines <- c(Lines, "\\addlinespace[4pt]")
  }
  Lines <- c(Lines, if (Long) "\\end{longtable}" else c("\\bottomrule", "\\end{tabular}"),
    "\\par\\vspace{4pt}", "\\noindent\\begin{minipage}{\\linewidth}\\footnotesize\\justifying", Note,
    "\\end{minipage}", "\\endgroup", if (!Long) "\\end{table}")
  writeLines(Lines, Path)
  invisible(Path)
}

WriteSimulationSimpleTable <- function(Path, Caption, Label, Specification, Header, Rows, Note) {
  Lines <- c("\\begin{table}[!htbp]", "\\begingroup", "\\centering", "\\small",
    "\\setlength{\\tabcolsep}{4pt}", "\\renewcommand{\\arraystretch}{1.1}",
    "\\captionsetup{justification=justified,singlelinecheck=false,font=small}",
    paste0("\\caption{", Caption, "}"), paste0("\\label{", Label, "}"),
    paste0("\\begin{tabular}{", Specification, "}"), "\\toprule", Header, "\\midrule", Rows,
    "\\bottomrule", "\\end{tabular}", "\\par\\vspace{4pt}",
    "\\begin{minipage}{\\linewidth}\\footnotesize\\justifying", Note, "\\end{minipage}",
    "\\endgroup", "\\end{table}")
  writeLines(Lines, Path)
}

WriteSimulationCoverageTable <- function(Data, Design, Parameters, Path) {
  if (!nrow(Data)) {
    writeLines("% No coverage estimates are available.", Path)
    return(invisible(Path))
  }
  Data <- Data[Data$Subset == "AllFinite" & Data$Parameter %in% Parameters, ]
  Header <- paste0("{Parameter} & {Coverage (\\%)} & ",
    "\\multicolumn{2}{c}{95\\% Monte Carlo interval} \\\\")
  Lines <- c("\\begingroup", "\\small", "\\setlength{\\tabcolsep}{4pt}",
    "\\captionsetup{justification=justified,singlelinecheck=false,font=small}",
    "\\begin{longtable}{@{}l S[table-format=3.1] S[table-format=3.1] @{\\,to\\,} S[table-format=3.1]@{}}",
    "\\caption{Monte Carlo uncertainty in estimated coverage.}\\label{tab:CoverageMonteCarlo}\\\\",
    "\\toprule", Header, "\\midrule", "\\endfirsthead", "\\toprule", Header, "\\midrule", "\\endhead",
    "\\midrule", "\\multicolumn{4}{r}{\\footnotesize Continued on the next page}\\\\", "\\endfoot",
    "\\bottomrule", "\\endlastfoot")
  for (Name in names(Design)) {
    D <- Data[Data$Scenario == Name, ]
    if (!nrow(D)) next
    D <- D[order(match(D$Parameter, Parameters)), ]
    S <- Design[[Name]]$Scenario
    Lines <- c(Lines, paste0("\\multicolumn{4}{@{}l}{\\textbf{\\boldmath$n=", S$Participants,
      "$ and $\\alpha=", formatC(S$Alpha, format = "f", digits = 1), "$}}\\\\*"))
    for (Index in seq_len(nrow(D))) {
      P <- D[Index, ]
      Values <- c(100*P$Coverage, 100*P$CoverageMonteCarloLower, 100*P$CoverageMonteCarloUpper)
      Cells <- mapply(SimulationLatexNumber, Values, c(1, 1, 1), USE.NAMES = FALSE)
      Lines <- c(Lines, paste0(paste(c(SimulationParameterLabel(P$Parameter, S), Cells), collapse = " & "), " \\\\"))
    }
    Lines <- c(Lines, "\\addlinespace[4pt]")
  }
  Lines <- c(Lines, "\\end{longtable}", "\\noindent\\begin{minipage}{\\linewidth}\\footnotesize\\justifying",
    "Wilson intervals describe uncertainty in the estimated coverage probability across independent replications. They are not credible intervals for the model parameters. Both limits are percentages; each parameter uses its own valid denominator.",
    "\\end{minipage}", "\\endgroup")
  writeLines(Lines, Path)
}

CalculateCustomOperatingCharacteristics <- function(Parameters, Status, Truth, Scenario) {
  Completed <- Status$FitStatus == "Completed"
  Output <- list()
  for (Subset in c("AllFinite", "DiagnosticsPassed")) for (Index in seq_len(nrow(Truth))) {
    Name <- Truth$Parameter[Index]
    Target <- Truth$Truth[Index]
    Eligible <- Completed & if (Subset == "DiagnosticsPassed") Status$DiagnosticsPassed else TRUE
    Ids <- Status$Replication[Eligible]
    P <- if (nrow(Parameters)) Parameters[Parameters$Parameter == Name & Parameters$Replication %in% Ids, ] else data.frame()
    if (nrow(P)) {
      Valid <- is.finite(P$Estimate) & is.finite(P$PosteriorSd) & P$PosteriorSd > 0 &
        is.finite(P$Lower) & is.finite(P$Upper) & P$Lower <= P$Upper
      P <- P[Valid, ]
      if (anyDuplicated(P$Replication)) stop("Duplicate parameter results.")
    }
    N <- nrow(P)
    Error <- if (N) P$Estimate - Target else numeric()
    Covered <- if (N) P$Lower <= Target & P$Upper >= Target else logical()
    Coverage <- if (N) mean(Covered) else NA_real_
    Rmse <- if (N) sqrt(mean(Error^2)) else NA_real_
    Bias <- if (N) mean(Error) else NA_real_
    Average <- function(X) if (length(X)) mean(X) else NA_real_
    Mcse <- function(X) if (length(X) > 1) stats::sd(X)/sqrt(length(X)) else NA_real_
    Z <- stats::qnorm(0.975)
    Centre <- if (N) (Coverage + Z^2/(2*N))/(1 + Z^2/N) else NA_real_
    Half <- if (N) Z*sqrt(Coverage*(1 - Coverage)/N + Z^2/(4*N^2))/(1 + Z^2/N) else NA_real_
    Output[[length(Output) + 1]] <- data.frame(Scenario = Scenario, Subset = Subset, Parameter = Name, Truth = Target,
      Attempted = nrow(Status), FailedFits = sum(!Completed), FlaggedCompletedFits = sum(Completed & !Status$DiagnosticsPassed),
      EligibleFits = sum(Eligible), Valid = N, MissingParameter = sum(Eligible) - N,
      MeanEstimate = if (N) mean(P$Estimate) else NA_real_, Bias = Bias, BiasMonteCarloSe = Mcse(Error),
      RelativeBiasPercent = if (Target != 0) 100*Bias/Target else NA_real_,
      Rmse = Rmse, RmseMonteCarloSe = if (N > 1 && Rmse > 0) Mcse(Error^2)/(2*Rmse) else NA_real_,
      EmpiricalSd = if (N > 1) stats::sd(P$Estimate) else NA_real_,
      MeanPosteriorSd = if (N) mean(P$PosteriorSd) else NA_real_,
      RootMeanPosteriorVariance = if (N) sqrt(mean(P$PosteriorSd^2)) else NA_real_,
      Coverage = Coverage, CoverageMonteCarloSe = if (N) sqrt(Coverage*(1 - Coverage)/N) else NA_real_,
      CoverageMonteCarloLower = Centre - Half, CoverageMonteCarloUpper = Centre + Half,
      MeanIntervalWidth = if (N) mean(P$Upper - P$Lower) else NA_real_,
      WidthMonteCarloSe = if (N) Mcse(P$Upper - P$Lower) else NA_real_,
      MeanEstimateMonteCarloSe = if (N) Average(P$MeanMonteCarloSe) else NA_real_,
      MeanLowerMonteCarloSe = if (N) Average(P$LowerMonteCarloSe) else NA_real_,
      MeanUpperMonteCarloSe = if (N) Average(P$UpperMonteCarloSe) else NA_real_)
  }
  do.call(rbind, Output)
}

CustomSamplerCode <- r"(#include <Rcpp.h>
#include <algorithm>
#include <cmath>
#include <limits>
#include <vector>
using namespace Rcpp;
// [[Rcpp::plugins(cpp17)]]

struct Evaluation {
  double X, H, D;
};

// Log density relative to the current point. It is a Gaussian log density
// plus a linear term minus positive multiples of exponentials.
struct Conditional {
  double Linear, Precision;
  std::vector<double> Means, Slopes;
  Evaluation Eval(double X) const {
    double H = Linear*X - 0.5*Precision*X*X;
    double D = Linear - Precision*X;
    for (size_t J = 0; J < Means.size(); ++J) {
      if (Means[J] == 0 || Slopes[J] == 0) continue;
      double Y = Slopes[J]*X;
      double V = std::exp(std::log(Means[J]) + Y);
      if (!std::isfinite(V)) return {X, R_NegInf, -std::copysign(R_PosInf, Slopes[J])};
      H -= std::abs(Y) < 0.5 ? Means[J]*std::expm1(Y) : V - Means[J];
      D -= Slopes[J]*V;
    }
    return {X, H, D};
  }
  double Curvature() const {
    double Value = Precision;
    for (size_t J = 0; J < Means.size(); ++J) Value += Means[J]*Slopes[J]*Slopes[J];
    return Value;
  }
};

double OpenUniform() {
  double U;
  do { U = R::runif(0, 1); } while (U <= 0 || U >= 1);
  return U;
}

double LogIntegral(const Evaluation &P, double Left, double Right) {
  if (!std::isfinite(Left)) {
    if (P.D <= 0) stop("The left sampler tail is not integrable.");
    return P.H + P.D*(Right - P.X) - std::log(P.D);
  }
  if (!std::isfinite(Right)) {
    if (P.D >= 0) stop("The right sampler tail is not integrable.");
    return P.H + P.D*(Left - P.X) - std::log(-P.D);
  }
  double Width = Right - Left;
  if (Width <= 0) stop("The sampler envelope has an invalid interval.");
  if (P.D > 0) return P.H + P.D*(Right - P.X) + std::log(-std::expm1(-P.D*Width)) - std::log(P.D);
  if (P.D < 0) return P.H + P.D*(Left - P.X) + std::log(-std::expm1(P.D*Width)) - std::log(-P.D);
  return P.H + std::log(Width);
}

double DrawSegment(double Slope, double Left, double Right) {
  double U = OpenUniform();
  if (!std::isfinite(Left)) return Right + std::log(U)/Slope;
  if (!std::isfinite(Right)) return Left + std::log(U)/Slope;
  double Width = Right - Left;
  if (Slope == 0) return Left + U*Width;
  if (std::abs(Slope*Width) < 0.5) return Left + std::log1p(U*std::expm1(Slope*Width))/Slope;
  if (Slope > 0) return Right + std::log(U + (1 - U)*std::exp(-Slope*Width))/Slope;
  return Left + std::log(U + (1 - U)*std::exp(Slope*Width))/Slope;
}

double DrawConditional(const Conditional &F, double &Evaluations) {
  double Scale = 1/std::sqrt(F.Curvature());
  if (!std::isfinite(Scale) || Scale <= 0) stop("Invalid conditional curvature.");
  Evaluation Centre = F.Eval(0);
  Evaluation Left = F.Eval(-Scale), Right = F.Eval(Scale);
  Evaluations += 3;
  // Gaussian priors guarantee integrable tails. The guard aborts; it never
  // truncates the support or accepts a candidate from an invalid envelope.
  double TailSlope = 1/Scale;
  for (int J = 0; Left.D < TailSlope && J < 100; ++J) {
    Left = F.Eval(Left.X*2); ++Evaluations;
  }
  for (int J = 0; Right.D > -TailSlope && J < 100; ++J) {
    Right = F.Eval(Right.X*2); ++Evaluations;
  }
  if (!std::isfinite(Left.H) || !std::isfinite(Right.H) || Left.D <= 0 || Right.D >= 0) {
    stop("Could not construct the conditional envelope.");
  }
  std::vector<Evaluation> Points = {Left, Centre, Right};
  for (int Attempt = 0; Attempt < 1000; ++Attempt) {
    size_t Size = Points.size();
    std::vector<double> Bounds(Size + 1), LogMass(Size), Mass(Size);
    Bounds[0] = R_NegInf; Bounds[Size] = R_PosInf;
    for (size_t J = 1; J < Size; ++J) {
      const auto &A = Points[J - 1]; const auto &B = Points[J];
      double Difference = A.D - B.D;
      if (Difference <= 0 || !std::isfinite(Difference)) stop("Conditional slopes are not decreasing.");
      double Z = A.X + (B.H - A.H - B.D*(B.X - A.X))/Difference;
      double Tolerance = 1e-9*(1 + std::abs(A.X) + std::abs(B.X));
      if (Z < A.X - Tolerance || Z > B.X + Tolerance || !std::isfinite(Z)) stop("Invalid tangent intersection.");
      Bounds[J] = std::max(A.X, std::min(B.X, Z));
    }
    for (size_t J = 0; J < Size; ++J) LogMass[J] = LogIntegral(Points[J], Bounds[J], Bounds[J + 1]);
    double Max = *std::max_element(LogMass.begin(), LogMass.end()), Total = 0;
    for (size_t J = 0; J < Size; ++J) { Mass[J] = std::exp(LogMass[J] - Max); Total += Mass[J]; }
    if (!std::isfinite(Total) || Total <= 0) stop("Invalid sampler envelope mass.");
    double Target = OpenUniform()*Total, Sum = 0;
    size_t Segment = Size - 1;
    for (size_t J = 0; J < Size; ++J) { Sum += Mass[J]; if (Target <= Sum) { Segment = J; break; } }
    double X = DrawSegment(Points[Segment].D, Bounds[Segment], Bounds[Segment + 1]);
    double Upper = Points[Segment].H + Points[Segment].D*(X - Points[Segment].X);
    Evaluation Candidate = F.Eval(X); ++Evaluations;
    if (std::isnan(Candidate.H) || Candidate.H - Upper > 1e-8*(1 + std::abs(Candidate.H))) {
      stop("The conditional density exceeds its sampler envelope.");
    }
    if (std::log(OpenUniform()) <= Candidate.H - Upper) return X;
    if (!std::isfinite(Candidate.H) || !std::isfinite(Candidate.D)) {
      // An overflowing exponential has zero acceptance probability. Refine
      // the envelope at a finite point between this rejection and its knot.
      for (int Refine = 0; Refine < 100 && (!std::isfinite(Candidate.H) || !std::isfinite(Candidate.D)); ++Refine) {
        X = 0.5*(X + Points[Segment].X);
        Candidate = F.Eval(X); ++Evaluations;
      }
      if (!std::isfinite(Candidate.H) || !std::isfinite(Candidate.D)) stop("Nonfinite conditional evaluation.");
    }
    auto At = std::lower_bound(Points.begin(), Points.end(), X,
      [](const Evaluation &P, double Value) { return P.X < Value; });
    Points.insert(At, Candidate);
  }
  stop("Conditional sampling exceeded its iteration guard.");
  return NA_REAL;
}

// [[Rcpp::export]]
NumericVector SampleConditionalCpp(int Number, double Linear, double Precision,
    NumericVector Means, NumericVector Slopes) {
  if (Number < 1 || Precision <= 0 || Means.size() != Slopes.size()) stop("Invalid conditional input.");
  Conditional F{Linear, Precision, as<std::vector<double>>(Means), as<std::vector<double>>(Slopes)};
  for (double X : F.Means) if (!std::isfinite(X) || X < 0) stop("Invalid conditional weight.");
  NumericVector Out(Number); double Evaluations = 0;
  for (int J = 0; J < Number; ++J) {
    if (J%1000 == 0) checkUserInterrupt();
    Out[J] = DrawConditional(F, Evaluations);
  }
  Out.attr("Evaluations") = Evaluations;
  return Out;
}

// [[Rcpp::export]]
NumericMatrix EvaluateConditionalCpp(NumericVector X, double Linear, double Precision,
    NumericVector Means, NumericVector Slopes) {
  Conditional F{Linear, Precision, as<std::vector<double>>(Means), as<std::vector<double>>(Slopes)};
  NumericMatrix Out(X.size(), 2);
  for (int J = 0; J < X.size(); ++J) { Evaluation E = F.Eval(X[J]); Out(J, 0) = E.H; Out(J, 1) = E.D; }
  return Out;
}

// [[Rcpp::export]]
List GibbsChainCpp(List Data, List Initial, int Warmup, int Sampling, bool BlockMoves = true,
    Nullable<List> Continuation = R_NilValue) {
  int N = as<int>(Data["Participants"]), K = as<int>(Data["Intervals"]);
  int Times = as<int>(Data["Times"]), Cells = as<int>(Data["Cells"]);
  if (N < 2 || K < 1 || Warmup < 0 || Sampling < 1) stop("Invalid sampler dimensions.");
  IntegerVector Id = Data["Id"], Bin = Data["Bin"], CountR = Data["CountR"], CountD = Data["CountD"];
  NumericMatrix X = Data["X"], BaseExposure = Data["BaselineExposure"];
  NumericVector LogExposure = Data["LogExposure"];
  double FixedPrecision = 1/std::pow(as<double>(Data["FixedSd"]), 2);
  double AlphaPrecision = 1/std::pow(as<double>(Data["AlphaSd"]), 2);
  double BasePrecision = 1/std::pow(as<double>(Data["BaselineLogSd"]), 2);
  double BaseMean = as<double>(Data["BaselineLogMean"]);
  double Shape = as<double>(Data["FrailtyShape"]), Rate = as<double>(Data["FrailtyRate"]);
  double Alpha = as<double>(Initial["Alpha"]), Precision = std::exp(as<double>(Initial["LogFrailtyPrecision"]));
  std::vector<double> Coefficients = {as<double>(Initial["BetaR"]), as<double>(Initial["GammaR"]),
    as<double>(Initial["BetaD"]), as<double>(Initial["GammaD"])};
  std::vector<double> R = as<std::vector<double>>(Initial["RecurrenceLogRate"]);
  std::vector<double> D = as<std::vector<double>>(Initial["DeathLogRate"]);
  std::vector<double> B = as<std::vector<double>>(Initial["FrailtyStandard"]);
  std::vector<double> A(N, -1), Z(N, -1), Exposure(N*K, 0), MeanR(N*K, 0), MeanD(N*K, 0);
  std::vector<double> NR(N, 0), ND(N, 0), RCount(K, 0), DCount(K, 0);
  for (double &Value : B) Value /= std::sqrt(Precision);
  for (int J = 0; J < Cells; ++J) {
    int I = Id[J] - 1, H = Bin[J] - 1, P = I*K + H;
    if (I < 0 || I >= N || H < 0 || H >= K || Exposure[P] != 0 ||
        (X(J, 0) != 0 && X(J, 0) != 1) || (X(J, 1) != 0 && X(J, 1) != 1)) stop("Invalid risk cells.");
    if (A[I] >= 0 && (A[I] != X(J, 0) || Z[I] != X(J, 1))) stop("Covariates vary within a participant.");
    Exposure[P] = std::exp(LogExposure[J]); A[I] = X(J, 0); Z[I] = X(J, 1);
    NR[I] += CountR[J]; ND[I] += CountD[J]; RCount[H] += CountR[J]; DCount[H] += CountD[J];
  }
  for (int I = 0; I < N; ++I) if (A[I] < 0 || ND[I] > 1) stop("Invalid participant history.");
  auto RefreshMeans = [&]() {
    for (int I = 0; I < N; ++I) for (int H = 0; H < K; ++H) {
      int P = I*K + H;
      MeanR[P] = Exposure[P]*std::exp(R[H] + Coefficients[0]*A[I] + Coefficients[1]*Z[I] + B[I]);
      MeanD[P] = Exposure[P]*std::exp(D[H] + Coefficients[2]*A[I] + Coefficients[3]*Z[I] + Alpha*B[I]);
      if (!std::isfinite(MeanR[P]) || !std::isfinite(MeanD[P])) stop("Nonfinite event intensity.");
    }
  };
  int Offset = 0;
  if (Continuation.isNotNull()) {
    if (Warmup != 0) stop("Continuation must not repeat initial warmup.");
    List State(Continuation);
    Coefficients = as<std::vector<double>>(State["Coefficients"]);
    R = as<std::vector<double>>(State["RecurrenceLogRate"]);
    D = as<std::vector<double>>(State["DeathLogRate"]);
    B = as<std::vector<double>>(State["Frailty"]);
    Alpha = as<double>(State["Alpha"]);
    Precision = as<double>(State["Precision"]);
    MeanR = as<std::vector<double>>(State["MeanR"]);
    MeanD = as<std::vector<double>>(State["MeanD"]);
    Offset = as<int>(State["Iterations"]);
    if (Coefficients.size() != 4 || R.size() != K || D.size() != K || B.size() != N ||
        MeanR.size() != N*K || MeanD.size() != N*K || Offset < 0 || !std::isfinite(Alpha) ||
        !std::isfinite(Precision) || Precision <= 0) stop("Invalid continuation state.");
  } else {
    RefreshMeans();
  }
  std::vector<double> ContinueR, ContinueD;
  int Variables = 8 + 2*K + 2*Times + N + 7;
  NumericMatrix Draws(Sampling, Variables);
  CharacterVector Names(Variables); int Pos = 0;
  for (const auto &Name : {"BetaR", "GammaR", "BetaD", "GammaD", "Alpha", "LogFrailtyPrecision", "FrailtyVariance", "FrailtyPrecision"}) Names[Pos++] = Name;
  for (const auto &Name : {"RecurrenceLogRate", "DeathLogRate"}) for (int H = 0; H < K; ++H) Names[Pos++] = std::string(Name) + "[" + std::to_string(H + 1) + "]";
  for (const auto &Name : {"RecurrenceCumulative", "DeathCumulative"}) for (int H = 0; H < Times; ++H) Names[Pos++] = std::string(Name) + "[" + std::to_string(H + 1) + "]";
  for (int I = 0; I < N; ++I) Names[Pos++] = "B[" + std::to_string(I + 1) + "]";
  for (int J = 0; J < 5; ++J) Names[Pos++] = "Scores[" + std::to_string(J + 1) + "]";
  Names[Pos++] = "ExpectedTotals[1]"; Names[Pos++] = "ExpectedTotals[2]";
  colnames(Draws) = Names;
  double Evaluations = 0, LargestCacheDifference = 0;
  int Total = Warmup + Sampling;
  for (int Iteration = 0; Iteration < Total; ++Iteration) {
    if (Iteration%100 == 0) checkUserInterrupt();
    for (int Process = 0; Process < 2; ++Process) {
      auto &Means = Process == 0 ? MeanR : MeanD;
      auto &Rates = Process == 0 ? R : D;
      auto &Counts = Process == 0 ? RCount : DCount;
      for (int H = 0; H < K; ++H) {
        double Sum = 0; for (int I = 0; I < N; ++I) Sum += Means[I*K + H];
        Conditional F{Counts[H] - BasePrecision*(Rates[H] - BaseMean), BasePrecision, {Sum}, {1}};
        double Delta = DrawConditional(F, Evaluations); Rates[H] += Delta;
        double Multiplier = std::exp(Delta);
        for (int I = 0; I < N; ++I) Means[I*K + H] *= Multiplier;
      }
      for (int Covariate = 0; Covariate < 2; ++Covariate) {
        auto &Cov = Covariate == 0 ? A : Z;
        auto &CountsById = Process == 0 ? NR : ND;
        double Count = 0, Mean = 0; int J = 2*Process + Covariate;
        for (int I = 0; I < N; ++I) if (Cov[I] == 1) {
          Count += CountsById[I]; for (int H = 0; H < K; ++H) Mean += Means[I*K + H];
        }
        Conditional F{Count - FixedPrecision*Coefficients[J], FixedPrecision, {Mean}, {1}};
        double Delta = DrawConditional(F, Evaluations); Coefficients[J] += Delta;
        double Multiplier = std::exp(Delta);
        for (int I = 0; I < N; ++I) if (Cov[I] == 1) for (int H = 0; H < K; ++H) Means[I*K + H] *= Multiplier;
      }
    }
    Conditional FAlpha{-AlphaPrecision*Alpha, AlphaPrecision, std::vector<double>(N, 0), B};
    for (int I = 0; I < N; ++I) {
      FAlpha.Linear += ND[I]*B[I];
      for (int H = 0; H < K; ++H) FAlpha.Means[I] += MeanD[I*K + H];
    }
    double DeltaAlpha = DrawConditional(FAlpha, Evaluations); Alpha += DeltaAlpha;
    for (int I = 0; I < N; ++I) for (int H = 0; H < K; ++H) MeanD[I*K + H] *= std::exp(DeltaAlpha*B[I]);
    for (int I = 0; I < N; ++I) {
      double SumR = 0, SumD = 0;
      for (int H = 0; H < K; ++H) { SumR += MeanR[I*K + H]; SumD += MeanD[I*K + H]; }
      Conditional F{NR[I] + Alpha*ND[I] - Precision*B[I], Precision, {SumR, SumD}, {1, Alpha}};
      double Delta = DrawConditional(F, Evaluations); B[I] += Delta;
      double MR = std::exp(Delta), MD = std::exp(Alpha*Delta);
      for (int H = 0; H < K; ++H) { MeanR[I*K + H] *= MR; MeanD[I*K + H] *= MD; }
    }
    if (BlockMoves) {
      // Exact Gaussian moves along directions that leave both likelihoods
      // unchanged. These are conditional updates in a linear coordinate system.
      for (int Direction = 0; Direction < 3; ++Direction) {
        double P = 0, L = 0;
        for (int I = 0; I < N; ++I) {
          double Cov = Direction == 0 ? 1 : (Direction == 1 ? A[I] : Z[I]);
          P += Precision*Cov*Cov; L -= Precision*Cov*B[I];
        }
        if (Direction == 0) {
          P += K*BasePrecision*(1 + Alpha*Alpha);
          for (int H = 0; H < K; ++H) L += BasePrecision*((R[H] - BaseMean) + Alpha*(D[H] - BaseMean));
        } else {
          P += FixedPrecision*(1 + Alpha*Alpha);
          L += FixedPrecision*(Coefficients[Direction - 1] + Alpha*Coefficients[Direction + 1]);
        }
        double Shift = R::rnorm(L/P, 1/std::sqrt(P));
        for (int I = 0; I < N; ++I) B[I] += Shift*(Direction == 0 ? 1 : (Direction == 1 ? A[I] : Z[I]));
        if (Direction == 0) for (int H = 0; H < K; ++H) { R[H] -= Shift; D[H] -= Alpha*Shift; }
        else { Coefficients[Direction - 1] -= Shift; Coefficients[Direction + 1] -= Alpha*Shift; }
      }
    }
    double SumSquares = 0; for (double Value : B) SumSquares += Value*Value;
    Precision = R::rgamma(Shape + 0.5*N, 1/(Rate + 0.5*SumSquares));
    if (!std::isfinite(Precision) || Precision <= 0) stop("Invalid sampled frailty precision.");
    if (Iteration == Total - 1) {
      ContinueR = MeanR;
      ContinueD = MeanD;
    }
    if ((Offset + Iteration)%100 == 0 || Iteration == Total - 1) {
      std::vector<double> OldR = MeanR, OldD = MeanD;
      RefreshMeans();
      for (int P = 0; P < N*K; ++P) {
        LargestCacheDifference = std::max(LargestCacheDifference, std::abs(OldR[P] - MeanR[P])/(1 + MeanR[P]));
        LargestCacheDifference = std::max(LargestCacheDifference, std::abs(OldD[P] - MeanD[P])/(1 + MeanD[P]));
      }
      if (LargestCacheDifference > 1e-8) stop("Cached intensities disagree with direct reconstruction.");
    }
    if (Iteration == Total - 1 && (Offset + Iteration)%100 == 0) {
      ContinueR = MeanR;
      ContinueD = MeanD;
    }
    if (Iteration >= Warmup) {
      int Row = Iteration - Warmup; Pos = 0;
      for (double Value : Coefficients) Draws(Row, Pos++) = Value;
      Draws(Row, Pos++) = Alpha; Draws(Row, Pos++) = std::log(Precision);
      Draws(Row, Pos++) = 1/Precision; Draws(Row, Pos++) = Precision;
      for (double Value : R) Draws(Row, Pos++) = Value;
      for (double Value : D) Draws(Row, Pos++) = Value;
      for (int Process = 0; Process < 2; ++Process) for (int T = 0; T < Times; ++T) {
        double Sum = 0; for (int H = 0; H < K; ++H) Sum += BaseExposure(T, H)*std::exp(Process == 0 ? R[H] : D[H]);
        Draws(Row, Pos++) = Sum;
      }
      for (double Value : B) Draws(Row, Pos++) = Value;
      double Scores[5] = {0, 0, 0, 0, 0}, Totals[2] = {0, 0};
      for (int I = 0; I < N; ++I) {
        double SR = 0, SD = 0;
        for (int H = 0; H < K; ++H) { SR += MeanR[I*K + H]; SD += MeanD[I*K + H]; }
        Scores[0] += A[I]*(NR[I] - SR); Scores[1] += Z[I]*(NR[I] - SR);
        Scores[2] += A[I]*(ND[I] - SD); Scores[3] += Z[I]*(ND[I] - SD);
        Scores[4] += B[I]*(ND[I] - SD);
        Totals[0] += SR; Totals[1] += SD;
      }
      for (int J = 0; J < 4; ++J) Draws(Row, Pos++) = Scores[J] - FixedPrecision*Coefficients[J];
      Draws(Row, Pos++) = Scores[4] - AlphaPrecision*Alpha;
      for (double Value : Totals) Draws(Row, Pos++) = Value;
    }
  }
  return List::create(_["Draws"] = Draws, _["ConditionalEvaluations"] = Evaluations,
    _["MaximumCacheDifference"] = LargestCacheDifference,
    _["State"] = List::create(_["Coefficients"] = Coefficients,
      _["RecurrenceLogRate"] = R, _["DeathLogRate"] = D, _["Frailty"] = B,
      _["Alpha"] = Alpha, _["Precision"] = Precision,
      _["MeanR"] = ContinueR, _["MeanD"] = ContinueD, _["Iterations"] = Offset + Total));
}
)"

CompileCustomSampler <- function(Directory, Rebuild = FALSE) {
  dir.create(Directory, recursive = TRUE, showWarnings = FALSE)
  # sourceCpp can update its cache even when loading an existing library.
  # Serialize cache access while the parallel workers start.
  Lock <- filelock::lock(file.path(Directory, "Compilation.lock"), timeout = Inf)
  if (is.null(Lock)) stop("Cannot lock the sampler compilation cache.")
  on.exit(filelock::unlock(Lock), add = TRUE)
  Path <- file.path(Directory, "CustomSampler.cpp")
  Text <- paste0(sub("[\r\n]+$", "", CustomSamplerCode), "\n")
  Existing <- if (file.exists(Path)) readChar(Path, file.info(Path)$size, useBytes = TRUE) else ""
  if (!identical(Existing, Text)) {
    Connection <- file(Path, "wb")
    tryCatch(writeChar(Text, Connection, eos = NULL, useBytes = TRUE), finally = close(Connection))
  }
  Rcpp::sourceCpp(Path, cacheDir = file.path(Directory, "Cache"), rebuild = Rebuild,
    showOutput = Rebuild, verbose = FALSE, env = .GlobalEnv)
  invisible(Path)
}

AuditCustomKernels <- function(D, Initial) {
  C <- CustomComponents(Initial, D)
  Precision <- exp(Initial$LogFrailtyPrecision)
  Rows <- list()
  Add <- function(Name, Linear, PriorPrecision, Means, Slopes, Change) {
    Shifts <- c(-0.4, 0.2, 0.7)
    Actual <- EvaluateConditionalCpp(Shifts, Linear, PriorPrecision, Means, Slopes)[, 1]
    Expected <- vapply(Shifts, function(Shift) CustomDensityR(Change(Shift), D) - CustomDensityR(Initial, D), numeric(1))
    Rows[[length(Rows) + 1]] <<- data.frame(Check = Name, MaximumDifference = max(abs(Actual - Expected)))
  }
  for (J in 1:4) {
    Name <- c("BetaR", "GammaR", "BetaD", "GammaD")[J]
    Covariate <- if (J %in% c(1, 3)) 1 else 2
    Keep <- D$X[, Covariate] == 1
    Counts <- if (J <= 2) D$CountR else D$CountD
    Means <- if (J <= 2) exp(C$EtaR) else exp(C$EtaD)
    Add(Name, sum(Counts[Keep]) - Initial[[Name]]/D$FixedSd^2, 1/D$FixedSd^2,
      sum(Means[Keep]), 1, function(Shift) { P <- Initial; P[[Name]] <- P[[Name]] + Shift; P })
  }
  for (Process in c("RecurrenceLogRate", "DeathLogRate")) {
    Counts <- if (Process == "RecurrenceLogRate") D$CountR else D$CountD
    Means <- if (Process == "RecurrenceLogRate") exp(C$EtaR) else exp(C$EtaD)
    for (K in seq_len(D$Intervals)) {
      Keep <- D$Bin == K
      Add(paste0(Process, K), sum(Counts[Keep]) - (Initial[[Process]][K] - D$BaselineLogMean)/D$BaselineLogSd^2,
        1/D$BaselineLogSd^2, sum(Means[Keep]), 1,
        function(Shift) { P <- Initial; P[[Process]][K] <- P[[Process]][K] + Shift; P })
    }
  }
  Add("Alpha", sum(D$CountD*C$B[D$Id]) - Initial$Alpha/D$AlphaSd^2, 1/D$AlphaSd^2,
    exp(C$EtaD), C$B[D$Id], function(Shift) { P <- Initial; P$Alpha <- P$Alpha + Shift; P })
  for (I in unique(c(1, D$Participants))) {
    Keep <- D$Id == I
    Add(paste0("Frailty", I), sum(D$CountR[Keep]) + Initial$Alpha*sum(D$CountD[Keep]) - Precision*C$B[I],
      Precision, c(sum(exp(C$EtaR[Keep])), sum(exp(C$EtaD[Keep]))), c(1, Initial$Alpha),
      function(Shift) { P <- Initial; P$FrailtyStandard[I] <- P$FrailtyStandard[I] + Shift*sqrt(Precision); P })
  }
  GammaShape <- D$FrailtyShape + D$Participants/2
  GammaRate <- D$FrailtyRate + sum(C$B^2)/2
  Differences <- vapply(c(-0.4, 0.2, 0.7), function(Shift) {
    P <- Initial
    P$LogFrailtyPrecision <- P$LogFrailtyPrecision + Shift
    P$FrailtyStandard <- C$B*exp(P$LogFrailtyPrecision/2)
    Actual <- CustomDensityR(P, D) - CustomDensityR(Initial, D) + (D$Participants/2 - 1)*Shift
    Expected <- dgamma(exp(P$LogFrailtyPrecision), GammaShape, rate = GammaRate, log = TRUE) -
      dgamma(Precision, GammaShape, rate = GammaRate, log = TRUE)
    Actual - Expected
  }, numeric(1))
  Rows[[length(Rows) + 1]] <- data.frame(Check = "Gamma precision conditional", MaximumDifference = max(abs(Differences)))
  PatientRows <- match(seq_len(D$Participants), D$Id)
  for (Direction in 0:2) {
    Cov <- if (Direction == 0) rep(1, D$Participants) else D$X[PatientRows, Direction]
    PP <- Precision*sum(Cov^2)
    LL <- -Precision*sum(Cov*C$B)
    if (Direction == 0) {
      PP <- PP + D$Intervals*(1 + Initial$Alpha^2)/D$BaselineLogSd^2
      LL <- LL + sum(C$R - D$BaselineLogMean + Initial$Alpha*(C$D - D$BaselineLogMean))/D$BaselineLogSd^2
    } else {
      PP <- PP + (1 + Initial$Alpha^2)/D$FixedSd^2
      LL <- LL + (C$Coefficients[Direction] + Initial$Alpha*C$Coefficients[Direction + 2])/D$FixedSd^2
    }
    Differences <- vapply(c(-0.4, 0.2, 0.7), function(Shift) {
      P <- Initial
      P$FrailtyStandard <- (C$B + Shift*Cov)*sqrt(Precision)
      if (Direction == 0) {
        P$RecurrenceLogRate <- C$R - Shift
        P$DeathLogRate <- C$D - Initial$Alpha*Shift
      } else {
        NR <- c("BetaR", "GammaR")[Direction]; ND <- c("BetaD", "GammaD")[Direction]
        P[[NR]] <- P[[NR]] - Shift; P[[ND]] <- P[[ND]] - Initial$Alpha*Shift
      }
      CustomDensityR(P, D) - CustomDensityR(Initial, D) - (LL*Shift - PP*Shift^2/2)
    }, numeric(1))
    Rows[[length(Rows) + 1]] <- data.frame(Check = paste("Gaussian direction", Direction), MaximumDifference = max(abs(Differences)))
  }
  Out <- do.call(rbind, Rows)
  if (any(!is.finite(Out$MaximumDifference)) || any(Out$MaximumDifference > 1e-7)) stop("A custom conditional differs from the joint density.")
  Out
}

ValidateCustomSettings <- function(Settings) {
  Expected <- names(SimulationSettings)
  if (!is.list(Settings) || !setequal(names(Settings), Expected)) stop("Simulation settings are missing or unknown.", call. = FALSE)
  for (Name in c("Replications", "Seed", "Chains", "Warmup", "Sampling", "MaximumWarmupBlocks", "MaximumSamplingBlocks")) {
    X <- Settings[[Name]]
    if (!is.numeric(X) || length(X) != 1 || !is.finite(X) || X != floor(X) || X < 1) stop(paste("Invalid setting:", Name), call. = FALSE)
  }
  if (Settings$Chains < 2 || Settings$Chains > 16) stop("Use between two and sixteen chains.", call. = FALSE)
  if (Settings$Warmup < 100 || Settings$Sampling < 100) stop("Use at least 100 warmup and retained draws per chain.", call. = FALSE)
  for (Name in c("FixedEffectSd", "AlphaSd", "BaselineLogSd", "FrailtyShape", "FrailtyRate", "MinimumEss")) {
    X <- Settings[[Name]]
    if (!is.numeric(X) || length(X) != 1 || !is.finite(X) || X <= 0) stop(paste("Invalid setting:", Name), call. = FALSE)
  }
  if (length(Settings$CoreFraction) != 1 || !is.finite(Settings$CoreFraction) ||
      Settings$CoreFraction <= 0 || Settings$CoreFraction > 1) stop("CoreFraction must be greater than zero and at most one.", call. = FALSE)
  X <- Settings$MaxConcurrentFits
  if (length(X) != 1 || is.na(X) || X < 1 || (!is.infinite(X) && X != floor(X))) stop("MaxConcurrentFits must be a positive integer or Inf.", call. = FALSE)
  if (length(Settings$BaselineLogMean) != 1 || !is.finite(Settings$BaselineLogMean) ||
      length(Settings$MaximumRhat) != 1 || !is.finite(Settings$MaximumRhat) || Settings$MaximumRhat <= 1) stop("Invalid baseline mean or Rhat limit.", call. = FALSE)
  if (Settings$Warmup + (Settings$MaximumWarmupBlocks + Settings$MaximumSamplingBlocks - 1)*Settings$Sampling >= .Machine$integer.max) {
    stop("The maximum iteration count is too large.", call. = FALSE)
  }
  for (Name in c("BlockMoves", "InstallMissingPackages")) {
    if (!is.logical(Settings[[Name]]) || length(Settings[[Name]]) != 1 || is.na(Settings[[Name]])) stop(paste("Invalid setting:", Name), call. = FALSE)
  }
  if (length(Settings$OutputFolder) != 1 || !is.character(Settings$OutputFolder) ||
      !grepl("^[A-Za-z][A-Za-z0-9]*$", Settings$OutputFolder)) stop("Use a simple output folder name.", call. = FALSE)
  invisible(Settings)
}

EnsureCustomPackages <- function(Settings) {
  Packages <- c("Rcpp", "posterior", "filelock")
  Missing <- Packages[!vapply(Packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(Missing) && Settings$InstallMissingPackages) {
    message("Installing: ", paste(Missing, collapse = ", "))
    utils::install.packages(Missing, repos = "https://cloud.r-project.org")
  }
  Missing <- Packages[!vapply(Packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(Missing)) stop(paste("Install these packages:", paste(Missing, collapse = ", ")), call. = FALSE)
  list(Versions = c(vapply(Packages, function(P) as.character(utils::packageVersion(P)), character(1)),
    R = as.character(getRversion()), Platform = R.version$platform))
}

GetCustomResources <- function(Settings, LogicalCores = parallel::detectCores(logical = TRUE)) {
  if (length(LogicalCores) != 1 || !is.finite(LogicalCores) || LogicalCores < 1) LogicalCores <- 1
  Budget <- max(1, floor(Settings$CoreFraction*LogicalCores))
  ParallelChains <- min(Settings$Chains, Budget)
  Workers <- min(Settings$MaxConcurrentFits, max(1, floor(Budget/ParallelChains)))
  list(LogicalCores = LogicalCores, CoreFraction = Settings$CoreFraction, Budget = Budget,
    Workers = Workers, ParallelChains = ParallelChains, ActiveCores = Workers*ParallelChains)
}

JitterCustomInitial <- function(P, Seed, Chain) {
  SetSimulationSeed(Seed)
  for (Name in c("BetaR", "GammaR", "BetaD", "GammaD")) P[[Name]] <- stats::rnorm(1, 0, 0.35)
  P$Alpha <- c(-0.5, 1.5)[1 + (Chain - 1)%%2] + stats::rnorm(1, 0, 0.2)
  P$LogFrailtyPrecision <- stats::runif(1, -0.7, 0.7)
  P$RecurrenceLogRate <- P$RecurrenceLogRate + stats::rnorm(length(P$RecurrenceLogRate), 0, 0.35)
  P$DeathLogRate <- P$DeathLogRate + stats::rnorm(length(P$DeathLogRate), 0, 0.35)
  P$FrailtyStandard <- stats::rnorm(length(P$FrailtyStandard), 0, 0.35)
  P
}

GetCustomImplementationHash <- function() {
  Names <- c("GetSimulationScenario", "GetSimulationTruth", "GenerateSimulationData", "GetSimulationExposure",
    "GetSimulationSeed", "SetSimulationSeed", "BuildCustomData", "CustomComponents", "CustomDensityR",
    "GetCustomInitial", "JitterCustomInitial", "AuditCustomKernels", "AuditReturnedStates",
    "RunCustomChain", "RunCustomAutoFit", "GetCustomDiagnostics", "GetCustomDiagnosticStatus",
    "CollectCustomDraws", "AppendCustomDraws", "SummarizeCustomFit", "SummarizeCustomMatrix", "CustomVariableMap")
  Bodies <- lapply(Names, function(Name) deparse(body(get(Name)), width.cutoff = 500))
  names(Bodies) <- Names
  SimulationHash(list(Version = CustomSimulationVersion, Code = CustomSamplerCode, Functions = Bodies))
}

GetCustomDefinition <- function(Index, Settings, Software) {
  Operational <- c("Replications", "CoreFraction", "MaxConcurrentFits", "OutputFolder", "InstallMissingPackages")
  list(Version = CustomSimulationVersion, Scenario = GetSimulationScenario(Index),
    ScenarioSeed = Settings$Seed + 10000*Index, Settings = Settings[setdiff(names(Settings), Operational)],
    Versions = Software$Versions, ModelHash = SimulationHash(CustomSamplerCode),
    ImplementationHash = GetCustomImplementationHash())
}

RunCustomChain <- function(Job) {
  if (is.null(Job$Continuation)) SetSimulationSeed(Job$Seed) else {
    assign(".Random.seed", Job$Continuation$RngState, envir = .GlobalEnv)
  }
  Start <- proc.time()[3]
  Warnings <- character()
  Answer <- tryCatch(withCallingHandlers({
    Result <- GibbsChainCpp(Job$Data, Job$Initial, Job$Warmup, Job$Sampling, Job$BlockMoves,
      if (is.null(Job$Continuation)) NULL else Job$Continuation$State)
    Result$RngState <- get(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
    Result$Succeeded <- TRUE
    Result
  }, warning = function(W) {
    Warnings <<- c(Warnings, conditionMessage(W))
    invokeRestart("muffleWarning")
  }), error = function(E) list(Succeeded = FALSE, Error = conditionMessage(E)))
  Answer$Chain <- Job$Chain
  Answer$Seed <- Job$Seed
  Answer$Seconds <- unname(proc.time()[3] - Start)
  Answer$Warnings <- unique(Warnings)
  Answer$WorkerPid <- Sys.getpid()
  Answer
}

InitializeCustomWorker <- function(ProgramPath, CompiledDirectory, ParallelChains) {
  Sys.setenv(OMP_NUM_THREADS = "1", OPENBLAS_NUM_THREADS = "1", MKL_NUM_THREADS = "1", VECLIB_MAXIMUM_THREADS = "1")
  source(ProgramPath, local = .GlobalEnv)
  State <- new.env(parent = emptyenv())
  State$Cluster <- NULL
  State$ParallelChains <- ParallelChains
  assign("CustomWorkerState", State, envir = .GlobalEnv)
  if (ParallelChains > 1) {
    Cluster <- parallel::makePSOCKcluster(ParallelChains)
    Ready <- FALSE
    on.exit(if (!Ready) parallel::stopCluster(Cluster), add = TRUE)
    parallel::clusterCall(Cluster, function(Path, Directory) {
      Sys.setenv(OMP_NUM_THREADS = "1", OPENBLAS_NUM_THREADS = "1", MKL_NUM_THREADS = "1", VECLIB_MAXIMUM_THREADS = "1")
      source(Path, local = .GlobalEnv)
      CompileCustomSampler(Directory)
      NULL
    }, ProgramPath, CompiledDirectory)
    State$Cluster <- Cluster
    Ready <- TRUE
  } else {
    CompileCustomSampler(CompiledDirectory)
  }
  invisible(NULL)
}

StopCustomWorker <- function() {
  if (exists("CustomWorkerState", envir = .GlobalEnv, inherits = FALSE)) {
    State <- get("CustomWorkerState", envir = .GlobalEnv)
    if (!is.null(State$Cluster)) try(parallel::stopCluster(State$Cluster), silent = TRUE)
    rm("CustomWorkerState", envir = .GlobalEnv)
  }
  invisible(NULL)
}

AuditReturnedStates <- function(Draws, D) {
  Largest <- 0
  for (Chain in seq_len(dim(Draws)[2])) for (Iteration in unique(c(1, dim(Draws)[1]))) {
    X <- Draws[Iteration, Chain, ]
    P <- as.list(X[c("BetaR", "GammaR", "BetaD", "GammaD", "Alpha", "LogFrailtyPrecision")])
    P$RecurrenceLogRate <- X[paste0("RecurrenceLogRate[", seq_len(D$Intervals), "]")]
    P$DeathLogRate <- X[paste0("DeathLogRate[", seq_len(D$Intervals), "]")]
    B <- X[paste0("B[", seq_len(D$Participants), "]")]
    P$FrailtyStandard <- B*exp(P$LogFrailtyPrecision/2)
    C <- CustomComponents(P, D)
    ResidualR <- D$CountR - exp(C$EtaR)
    ResidualD <- D$CountD - exp(C$EtaD)
    Scores <- c(as.vector(crossprod(D$X, ResidualR)) - C$Coefficients[1:2]/D$FixedSd^2,
      as.vector(crossprod(D$X, ResidualD)) - C$Coefficients[3:4]/D$FixedSd^2,
      sum(B[D$Id]*ResidualD) - P$Alpha/D$AlphaSd^2)
    Expected <- c(exp(-P$LogFrailtyPrecision), exp(P$LogFrailtyPrecision),
      as.vector(D$BaselineExposure %*% exp(P$RecurrenceLogRate)),
      as.vector(D$BaselineExposure %*% exp(P$DeathLogRate)), Scores,
      sum(exp(C$EtaR)), sum(exp(C$EtaD)))
    Names <- c("FrailtyVariance", "FrailtyPrecision", paste0("RecurrenceCumulative[", seq_len(D$Times), "]"),
      paste0("DeathCumulative[", seq_len(D$Times), "]"), paste0("Scores[", 1:5, "]"), paste0("ExpectedTotals[", 1:2, "]"))
    Difference <- max(abs(X[Names] - Expected)/(1 + abs(Expected)))
    if (!is.finite(Difference) || Difference > 1e-8) stop("Returned sampler summaries disagree with reconstruction.")
    Largest <- max(Largest, Difference)
  }
  Largest
}

SummarizeCustomFit <- function(Draws, Runs, Scenario, Settings, D, Variables = NULL) {
  if (length(dim(Draws)) != 3 || dim(Draws)[1] < Settings$Sampling || dim(Draws)[2] != Settings$Chains ||
      any(!is.finite(Draws))) stop("MCMC draws are incomplete or nonfinite.")
  Reconstruction <- AuditReturnedStates(Draws, D)
  Map <- CustomVariableMap(Scenario)
  if (!all(Map %in% dimnames(Draws)[[3]])) stop("Some posterior variables are missing.")
  Parameters <- do.call(rbind, lapply(names(Map), function(Name) {
    data.frame(Parameter = Name, as.list(SummarizeCustomMatrix(Draws[, , Map[[Name]]])), row.names = NULL)
  }))
  if (is.null(Variables)) Variables <- GetCustomDiagnostics(Draws, Settings)
  Variables$Review <- !is.finite(Variables$Rhat) | Variables$Rhat > Settings$MaximumRhat |
    !is.finite(Variables$BulkEss) | Variables$BulkEss < Settings$MinimumEss |
    !is.finite(Variables$TailEss) | Variables$TailEss < Settings$MinimumEss
  Scores <- do.call(rbind, lapply(1:5, function(J) {
    X <- Draws[, , paste0("Scores[", J, "]")]
    Se <- posterior::mcse_mean(X)
    data.frame(Parameter = c("BetaR", "GammaR", "BetaD", "GammaD", "Alpha")[J], Mean = mean(X),
      MonteCarloSe = Se, Review = !is.finite(Se) || abs(mean(X)) > 3*Se)
  }))
  Chains <- do.call(rbind, lapply(Runs, function(X) {
    data.frame(Chain = X$Chain, Seed = X$Seed, WorkerPid = X$WorkerPid, Seconds = X$Seconds,
      Retained = dim(Draws)[1], WarmupIterations = X$WarmupIterations, TotalIterations = X$TotalIterations,
      Blocks = X$Blocks, ConditionalEvaluations = X$ConditionalEvaluations,
      MaximumCacheDifference = X$MaximumCacheDifference, ReconstructionDifference = Reconstruction)
  }))
  Chains$Review <- !is.finite(Chains$MaximumCacheDifference) | Chains$MaximumCacheDifference > 1e-8
  list(Parameters = Parameters, VariableDiagnostics = Variables, ChainDiagnostics = Chains, Scores = Scores,
    DiagnosticsPassed = !any(Variables$Review) && !any(Chains$Review),
    ScoreFlag = any(Scores$Review), DrawsPerChain = dim(Draws)[1], Chains = dim(Draws)[2])
}

RunCustomReplication <- function(Replication, Definition, Settings, Directory) {
  Start <- proc.time()[3]
  Seeds <- list(Data = GetSimulationSeed(Definition$ScenarioSeed, Replication, 1),
    Initial = GetSimulationSeed(Definition$ScenarioSeed, Replication, 15000),
    Sampler = GetSimulationSeed(Definition$ScenarioSeed, Replication, 20000))
  Result <- list(Version = CustomSimulationVersion, Replication = Replication,
    DefinitionHash = SimulationHash(Definition), Seeds = Seeds, FitStatus = "Failed", Stage = "Generate",
    DiagnosticsPassed = FALSE, ScoreFlag = FALSE, Review = TRUE, Error = "", Warnings = character(),
    WorkerMessages = character(), Parameters = data.frame(), VariableDiagnostics = data.frame(),
    ChainDiagnostics = data.frame(), BlockDiagnostics = data.frame(), Scores = data.frame(), DataSummary = data.frame(),
    SamplingSeconds = NA_real_, ExtractionSeconds = NA_real_, SummarySeconds = NA_real_, DiagnosticSeconds = NA_real_,
    TotalSeconds = NA_real_, WorkerPid = Sys.getpid(), StartedAt = as.numeric(Sys.time()),
    WarmupEstablished = FALSE, WarmupBlocks = 0, SamplingBlocks = 0,
    TotalBlocks = 0, WarmupIterations = NA_real_, DrawsPerChain = 0,
    StopReason = "Error", RhatPassed = FALSE, EssPassed = FALSE)
  Warnings <- character()
  Result <- tryCatch(withCallingHandlers({
    Scenario <- Definition$Scenario
    Data <- GenerateSimulationData(Scenario, Seeds$Data)
    Result$DataSummary <- Data$Summary
    Result$DataHash <- SimulationHash(Data)
    Result$Stage <- "Build"
    D <- BuildCustomData(Data, Scenario, Settings)
    Initial <- GetCustomInitial(Data, D)
    Jobs <- lapply(seq_len(Settings$Chains), function(J) list(Data = D,
      Initial = JitterCustomInitial(Initial, Seeds$Initial + J, J), Seed = Seeds$Sampler + J,
      Chain = J, Warmup = Settings$Warmup, Sampling = Settings$Sampling, BlockMoves = Settings$BlockMoves))
    Result$Stage <- "Sampling"
    Auto <- RunCustomAutoFit(Jobs, Settings)
    for (Name in setdiff(names(Auto), c("Draws", "Runs", "VariableDiagnostics"))) Result[[Name]] <- Auto[[Name]]
    Result$Stage <- "Summary"
    Timer <- proc.time()[3]
    Fit <- SummarizeCustomFit(Auto$Draws, Auto$Runs, Scenario, Settings, D, Auto$VariableDiagnostics)
    Parameters <- Fit$Parameters
    names(Parameters)[names(Parameters) == "Mean"] <- "Estimate"
    names(Parameters)[names(Parameters) == "Sd"] <- "PosteriorSd"
    Truth <- GetSimulationTruth(Scenario)
    Parameters$Truth <- Truth$Truth[match(Parameters$Parameter, Truth$Parameter)]
    Parameters$Source <- if (Auto$WarmupEstablished) "Custom Gibbs MCMC; all retained draws" else "Custom Gibbs MCMC; final provisional block, Rhat not met"
    Fit$Parameters <- Parameters
    for (Name in names(Fit)) Result[[Name]] <- Fit[[Name]]
    Result$DiagnosticsPassed <- Result$WarmupEstablished && Result$DiagnosticsPassed
    Result$SummarySeconds <- unname(proc.time()[3] - Timer)
    Result$FitStatus <- "Completed"
    Result$Stage <- "Saved"
    Result
  }, warning = function(W) {
    Warnings <<- c(Warnings, conditionMessage(W))
    invokeRestart("muffleWarning")
  }), error = function(E) {
    Result$Error <- conditionMessage(E)
    Result$WorkerMessages <- tail(conditionMessage(E), 1)
    Result
  })
  Result$Warnings <- unique(Warnings)
  Result$Review <- Result$FitStatus != "Completed" || !Result$DiagnosticsPassed || Result$ScoreFlag || length(Result$Warnings) > 0
  Result$TotalSeconds <- unname(proc.time()[3] - Start)
  Result$FinishedAt <- as.numeric(Sys.time())
  SaveSimulationRds(Result, file.path(Directory, sprintf("Replication%05d.rds", Replication)))
  Result[c("Replication", "FitStatus", "DiagnosticsPassed", "ScoreFlag", "Warnings", "Error", "TotalSeconds",
    "WarmupBlocks", "SamplingBlocks", "DrawsPerChain", "StopReason")]
}

PrepareCustomScenario <- function(Index, Settings, Software, Resources, Root) {
  Definition <- GetCustomDefinition(Index, Settings, Software)
  Directory <- file.path(Root, Definition$Scenario$Name)
  dir.create(Directory, recursive = TRUE, showWarnings = FALSE)
  ManifestPath <- file.path(Directory, "Settings.rds")
  Requested <- Settings$Replications
  if (file.exists(ManifestPath) || file.exists(paste0(ManifestPath, ".previous"))) {
    Saved <- ReadSavedSimulation(ManifestPath)
    if (!identical(Saved$Definition, Definition)) stop(paste0(Definition$Scenario$Name,
      " has different model, sampler or software settings. Use a new OutputFolder."), call. = FALSE)
    Requested <- max(Requested, Saved$Requested)
  }
  GetSimulationSeed(Definition$ScenarioSeed, Requested, 20000 + Settings$Chains)
  Backup <- list.files(Directory, pattern = "^Replication[0-9]+\\.rds\\.previous$", full.names = TRUE)
  for (Path in Backup) ReadSavedSimulation(sub("\\.previous$", "", Path))
  Files <- list.files(Directory, pattern = "^Replication[0-9]+\\.rds$", full.names = TRUE)
  Results <- lapply(Files, ReadSavedSimulation)
  if (length(Results) && any(!vapply(Results, function(X) identical(X$DefinitionHash, SimulationHash(Definition)), logical(1)))) stop("Saved replications have different settings.")
  Done <- vapply(Results, function(X) X$Replication, numeric(1))
  if (anyDuplicated(Done) || any(Done < 1 | Done > Requested)) stop("Invalid saved replication numbers.")
  SaveSimulationRds(list(Definition = Definition, Requested = Requested, Resources = Resources), ManifestPath)
  list(Definition = Definition, Directory = Directory, Requested = Requested, Done = Done,
    Remaining = setdiff(seq_len(Requested), Done))
}

RunCustomScenario <- function(Prepared, Settings, Resources, FitCluster) {
  Definition <- Prepared$Definition
  Scenario <- Definition$Scenario
  Directory <- Prepared$Directory
  Remaining <- Prepared$Remaining
  Done <- Prepared$Done
  message("\n", Scenario$Name, ": N = ", Scenario$Participants, "; alpha = ", Scenario$Alpha,
    "; ", length(Remaining), "/", Prepared$Requested, " replications remaining.")
  message(Resources$Workers, " simultaneous fits, ", Resources$ParallelChains,
    " parallel chains per fit; ", Resources$ActiveCores, " active cores within budget ", Resources$Budget, "/", Resources$LogicalCores, ".")
  if (!length(Remaining)) return(invisible(TRUE))
  AuditPath <- file.path(Directory, "ConditionalAudit.rds")
  if (file.exists(AuditPath)) {
    if (!identical(ReadSavedSimulation(AuditPath)$DefinitionHash, SimulationHash(Definition))) stop("The saved conditional audit has different settings.")
  } else {
    Data <- GenerateSimulationData(Scenario, GetSimulationSeed(Definition$ScenarioSeed, Remaining[1], 1))
    D <- BuildCustomData(Data, Scenario, Settings)
    Audit <- AuditCustomKernels(D, JitterCustomInitial(GetCustomInitial(Data, D), 104729, 1))
    SaveSimulationRds(list(DefinitionHash = SimulationHash(Definition), Checks = Audit), AuditPath)
  }
  Start <- proc.time()[3]
  New <- 0
  Report <- function(Batch) {
    New <<- New + length(Batch)
    Done <<- c(Done, vapply(Batch, function(X) X$Replication, numeric(1)))
    message(length(Done), "/", Prepared$Requested, " saved; this batch: ",
      sum(vapply(Batch, function(X) X$FitStatus != "Completed", logical(1))), " failed, ",
      sum(vapply(Batch, function(X) X$FitStatus == "Completed" && !X$DiagnosticsPassed, logical(1))), " with MCMC flags; ",
      sum(vapply(Batch, function(X) isTRUE(X$WarmupBlocks > 1) || isTRUE(X$SamplingBlocks > 1), logical(1))),
      " extended; elapsed ",
      round((proc.time()[3] - Start)/60, 1), " minutes.")
  }
  TimingPath <- file.path(Directory, "Execution.rds")
  on.exit({
    Previous <- if (file.exists(TimingPath)) ReadSavedSimulation(TimingPath) else list()
    SaveSimulationRds(c(Previous, list(list(CompletedThisInvocation = New, ElapsedSeconds = unname(proc.time()[3] - Start),
      Workers = Resources$Workers, ParallelChains = Resources$ParallelChains, CoreBudget = Resources$Budget))), TimingPath)
  }, add = TRUE)
  message("Checking the first remaining fit before starting the concurrent batch...")
  First <- parallel::parLapply(FitCluster, Remaining[1], RunCustomReplication, Definition, Settings, Directory)
  Report(First)
  if (First[[1]]$FitStatus != "Completed") {
    message("The first fit failed: ", First[[1]]$Error, "\nExecution stopped; the failed result is saved.")
    return(invisible(FALSE))
  }
  Remaining <- Remaining[-1]
  if (!length(Remaining)) return(invisible(TRUE))
  Batches <- split(Remaining, ceiling(seq_along(Remaining)/Resources$Workers))
  for (Ids in Batches) {
    Batch <- parallel::parLapplyLB(FitCluster, Ids, RunCustomReplication, Definition, Settings, Directory)
    Report(Batch)
    if (all(vapply(Batch, function(X) X$FitStatus != "Completed", logical(1)))) {
      message("Every fit in this batch failed. Execution stopped.")
      return(invisible(FALSE))
    }
  }
  invisible(TRUE)
}

RunCustomScenarios <- function(Indices = 1:4, Settings = SimulationSettings) {
  ValidateCustomSettings(Settings)
  if (!length(Indices) || any(!Indices %in% 1:4) || anyDuplicated(Indices)) stop("Choose distinct scenarios from 1 to 4.")
  if (!nzchar(CustomProgramPath)) stop("Run a scenario script with source() or Rscript.")
  Software <- EnsureCustomPackages(Settings)
  Resources <- GetCustomResources(Settings)
  Root <- file.path(dirname(CustomProgramPath), Settings$OutputFolder)
  dir.create(Root, recursive = TRUE, showWarnings = FALSE)
  Lock <- filelock::lock(file.path(Root, "Running.lock"), timeout = 0)
  if (is.null(Lock)) stop("A simulation is already running in this output folder. Wait for it; do not delete the lock.")
  on.exit(filelock::unlock(Lock), add = TRUE)
  Names <- c("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")
  Previous <- Sys.getenv(Names, unset = NA_character_)
  on.exit({ for (J in seq_along(Names)) {
    if (is.na(Previous[J])) Sys.unsetenv(Names[J]) else do.call(Sys.setenv, setNames(list(Previous[J]), Names[J]))
  } }, add = TRUE)
  Sys.setenv(OMP_NUM_THREADS = "1", OPENBLAS_NUM_THREADS = "1", MKL_NUM_THREADS = "1", VECLIB_MAXIMUM_THREADS = "1")
  Prepared <- lapply(Indices, PrepareCustomScenario, Settings, Software, Resources, Root)
  if (all(vapply(Prepared, function(X) !length(X$Remaining), logical(1)))) return(invisible(SummarizeCustomSimulation(Root)))
  message("Parameter recovery: custom Gibbs sampler with automatic extension.")
  message(Settings$Sampling, " draws per chain per block; at most ", Settings$MaximumWarmupBlocks,
    " warmup assessment blocks and ", Settings$MaximumSamplingBlocks, " retained blocks.")
  message("Rhat <= ", Settings$MaximumRhat, "; bulk and tail ESS >= ", Settings$MinimumEss,
    ". All retained draws are used.")
  message("Output: ", normalizePath(Root, winslash = "/"))
  Start <- proc.time()[3]
  CompiledDirectory <- file.path(Root, "CompiledSampler")
  message("Preparing the compiled sampler and workers...")
  CompileCustomSampler(CompiledDirectory)
  CompilationSeconds <- unname(proc.time()[3] - Start)
  FitCluster <- parallel::makePSOCKcluster(Resources$Workers)
  on.exit({
    try(parallel::clusterCall(FitCluster, StopCustomWorker), silent = TRUE)
    try(parallel::stopCluster(FitCluster), silent = TRUE)
  }, add = TRUE)
  Start <- proc.time()[3]
  parallel::clusterCall(FitCluster, InitializeCustomWorker, CustomProgramPath, CompiledDirectory, Resources$ParallelChains)
  SaveSimulationRds(list(CompilationSeconds = CompilationSeconds, WorkerSetupSeconds = unname(proc.time()[3] - Start),
    Versions = Software$Versions, Resources = Resources), file.path(Root, "Setup.rds"))
  Problem <- NULL
  tryCatch({
    for (Item in Prepared) {
      Continue <- RunCustomScenario(Item, Settings, Resources, FitCluster)
      if (!Continue) break
    }
  }, interrupt = function(E) {
    Problem <<- "Interrupted. Completed fits are saved. Workers may finish their current fits before closing."
    message(Problem)
  }, error = function(E) {
    Problem <<- conditionMessage(E)
    message("Stopped: ", Problem)
  })
  # Wait for active workers to close before assembling a consistent summary.
  try(parallel::clusterCall(FitCluster, StopCustomWorker), silent = TRUE)
  Answer <- SummarizeCustomSimulation(Root)
  if (!is.null(Problem)) message("Completed replications are retained when the scenario is rerun.")
  invisible(Answer)
}


GetCustomDiagnostics <- function(Draws, Settings) {
  if (length(dim(Draws)) != 3 || dim(Draws)[2] != Settings$Chains ||
      any(!is.finite(Draws))) stop("MCMC draws are incomplete or nonfinite.")
  Variables <- do.call(rbind, lapply(dimnames(Draws)[[3]], function(Name) {
    X <- Draws[, , Name]
    data.frame(Variable = Name, Rhat = posterior::rhat(X),
      BulkEss = posterior::ess_bulk(X), TailEss = posterior::ess_tail(X))
  }))
  Variables$Review <- !is.finite(Variables$Rhat) | Variables$Rhat > Settings$MaximumRhat |
    !is.finite(Variables$BulkEss) | Variables$BulkEss < Settings$MinimumEss |
    !is.finite(Variables$TailEss) | Variables$TailEss < Settings$MinimumEss
  Variables
}

GetCustomDiagnosticStatus <- function(Variables, Settings) {
  RhatPassed <- nrow(Variables) > 0 && all(is.finite(Variables$Rhat) & Variables$Rhat <= Settings$MaximumRhat)
  EssPassed <- nrow(Variables) > 0 && all(is.finite(Variables$BulkEss) & Variables$BulkEss >= Settings$MinimumEss &
    is.finite(Variables$TailEss) & Variables$TailEss >= Settings$MinimumEss)
  list(RhatPassed = RhatPassed, EssPassed = EssPassed)
}

GetCustomBlockRecord <- function(Variables, Settings, Block, Stage, StageBlock, DrawsAssessed) {
  Status <- GetCustomDiagnosticStatus(Variables, Settings)
  FiniteMax <- function(X) if (any(is.finite(X))) max(X[is.finite(X)]) else NA_real_
  FiniteMin <- function(X) if (any(is.finite(X))) min(X[is.finite(X)]) else NA_real_
  data.frame(Block = Block, Stage = Stage, StageBlock = StageBlock,
    AddedPerChain = Settings$Sampling, AssessedPerChain = DrawsAssessed,
    MaximumRhat = FiniteMax(Variables$Rhat), MinimumBulkEss = FiniteMin(Variables$BulkEss),
    MinimumTailEss = FiniteMin(Variables$TailEss), RhatPassed = Status$RhatPassed,
    EssPassed = Status$EssPassed, Unavailable = sum(!is.finite(Variables$Rhat) |
      !is.finite(Variables$BulkEss) | !is.finite(Variables$TailEss)), UsedInSummary = FALSE)
}

CollectCustomDraws <- function(Runs, Settings) {
  Failed <- !vapply(Runs, function(X) isTRUE(X$Succeeded), logical(1))
  if (any(Failed)) stop(paste("Chain", Runs[[which(Failed)[1]]]$Chain, "failed:", Runs[[which(Failed)[1]]]$Error))
  if (length(Runs) != Settings$Chains) stop("Some chains are missing.")
  Names <- colnames(Runs[[1]]$Draws)
  Draws <- array(NA_real_, c(Settings$Sampling, Settings$Chains, length(Names)),
    dimnames = list(NULL, NULL, Names))
  for (J in seq_len(Settings$Chains)) {
    if (nrow(Runs[[J]]$Draws) != Settings$Sampling || !identical(colnames(Runs[[J]]$Draws), Names)) {
      stop("A chain returned incomplete draws.")
    }
    Draws[, J, ] <- Runs[[J]]$Draws
  }
  if (any(!is.finite(Draws))) stop("A chain returned nonfinite draws.")
  Draws
}

AppendCustomDraws <- function(Previous, Additional) {
  N <- dim(Previous)[1]
  Added <- dim(Additional)[1]
  if (!identical(dim(Previous)[2:3], dim(Additional)[2:3]) ||
      !identical(dimnames(Previous)[[3]], dimnames(Additional)[[3]])) stop("Continuation variables differ.")
  Out <- array(NA_real_, c(N + Added, dim(Previous)[2:3]),
    dimnames = list(NULL, NULL, dimnames(Previous)[[3]]))
  Out[seq_len(N), , ] <- Previous
  Out[N + seq_len(Added), , ] <- Additional
  Out
}

RunCustomAutoFit <- function(Jobs, Settings) {
  State <- get("CustomWorkerState", envir = .GlobalEnv)
  History <- list()
  Totals <- lapply(Jobs, function(Job) list(Chain = Job$Chain, Seed = Job$Seed,
    Seconds = 0, ConditionalEvaluations = 0, MaximumCacheDifference = 0,
    WorkerPid = NA_real_))
  SamplingSeconds <- 0
  DiagnosticSeconds <- 0
  ExtractionSeconds <- 0
  Block <- 0
  Retained <- NULL
  FinalVariables <- NULL
  WarmupEstablished <- FALSE
  WarmupBlocks <- 0
  SamplingBlocks <- 0
  NextBlock <- function() {
    Start <- proc.time()[3]
    Runs <- if (is.null(State$Cluster)) lapply(Jobs, RunCustomChain) else parallel::parLapply(State$Cluster, Jobs, RunCustomChain)
    SamplingSeconds <<- SamplingSeconds + unname(proc.time()[3] - Start)
    for (Run in Runs) for (Message in Run$Warnings) warning(Message, call. = FALSE)
    Start <- proc.time()[3]
    Draws <- CollectCustomDraws(Runs, Settings)
    for (J in seq_along(Jobs)) {
      Jobs[[J]]$Continuation <<- list(State = Runs[[J]]$State, RngState = Runs[[J]]$RngState)
      Jobs[[J]]$Warmup <<- 0
      Totals[[J]]$Seconds <<- Totals[[J]]$Seconds + Runs[[J]]$Seconds
      Totals[[J]]$ConditionalEvaluations <<- Totals[[J]]$ConditionalEvaluations + Runs[[J]]$ConditionalEvaluations
      Totals[[J]]$MaximumCacheDifference <<- max(Totals[[J]]$MaximumCacheDifference, Runs[[J]]$MaximumCacheDifference)
      Totals[[J]]$WorkerPid <<- Runs[[J]]$WorkerPid
      Totals[[J]]$TotalIterations <<- Runs[[J]]$State$Iterations
    }
    Block <<- Block + 1
    ExtractionSeconds <<- ExtractionSeconds + unname(proc.time()[3] - Start)
    Draws
  }
  Diagnose <- function(Draws) {
    Start <- proc.time()[3]
    Out <- GetCustomDiagnostics(Draws, Settings)
    DiagnosticSeconds <<- DiagnosticSeconds + unname(proc.time()[3] - Start)
    Out
  }
  for (Attempt in seq_len(Settings$MaximumWarmupBlocks)) {
    Latest <- NextBlock()
    Variables <- Diagnose(Latest)
    History[[Block]] <- GetCustomBlockRecord(Variables, Settings, Block,
      "WarmupAssessment", Attempt, dim(Latest)[1])
    WarmupBlocks <- Attempt
    Status <- GetCustomDiagnosticStatus(Variables, Settings)
    if (Status$RhatPassed) {
      WarmupEstablished <- TRUE
      Retained <- Latest
      FinalVariables <- Variables
      SamplingBlocks <- 1
      break
    }
    # Provisional blocks are replaced only before a warmup boundary is established.
    Retained <- Latest
    FinalVariables <- Variables
  }
  FirstRetainedBlock <- Block
  if (WarmupEstablished) {
    Status <- GetCustomDiagnosticStatus(FinalVariables, Settings)
    while (!(Status$RhatPassed && Status$EssPassed) && SamplingBlocks < Settings$MaximumSamplingBlocks) {
      Additional <- NextBlock()
      Start <- proc.time()[3]
      Retained <- AppendCustomDraws(Retained, Additional)
      ExtractionSeconds <- ExtractionSeconds + unname(proc.time()[3] - Start)
      SamplingBlocks <- SamplingBlocks + 1
      FinalVariables <- Diagnose(Retained)
      History[[Block]] <- GetCustomBlockRecord(FinalVariables, Settings, Block,
        "RetainedSampling", SamplingBlocks, dim(Retained)[1])
      Status <- GetCustomDiagnosticStatus(FinalVariables, Settings)
    }
  } else {
    SamplingBlocks <- 1
  }
  Status <- GetCustomDiagnosticStatus(FinalVariables, Settings)
  StopReason <- if (!WarmupEstablished) "WarmupLimit" else if (Status$RhatPassed && Status$EssPassed) "CriteriaMet" else "SamplingLimit"
  History <- do.call(rbind, History)
  History$UsedInSummary <- History$Block >= FirstRetainedBlock
  SummaryWarmup <- Settings$Warmup + (FirstRetainedBlock - 1)*Settings$Sampling
  for (J in seq_along(Totals)) {
    Totals[[J]]$Retained <- dim(Retained)[1]
    Totals[[J]]$WarmupIterations <- SummaryWarmup
    Totals[[J]]$Blocks <- Block
  }
  list(Draws = Retained, Runs = Totals, VariableDiagnostics = FinalVariables,
    BlockDiagnostics = History, WarmupEstablished = WarmupEstablished,
    WarmupBlocks = WarmupBlocks, SamplingBlocks = SamplingBlocks,
    WarmupIterations = SummaryWarmup, DrawsPerChain = dim(Retained)[1],
    TotalBlocks = Block, StopReason = StopReason, RhatPassed = Status$RhatPassed,
    EssPassed = Status$EssPassed, SamplingSeconds = SamplingSeconds,
    ExtractionSeconds = ExtractionSeconds, DiagnosticSeconds = DiagnosticSeconds)
}

SummarizeCustomSimulation <- function(OutputDir) {
  Paths <- file.path(OutputDir, sprintf("Scenario%02d", 1:4), "Settings.rds")
  Paths <- Paths[file.exists(Paths)]
  if (!length(Paths)) {
    message("No saved scenarios found in: ", OutputDir)
    return(invisible(NULL))
  }
  SummaryDirectory <- file.path(OutputDir, "Summary")
  dir.create(SummaryDirectory, recursive = TRUE, showWarnings = FALSE)
  Design <- list()
  Parts <- setNames(vector("list", 14), c("Design", "Truth", "Status", "ParameterEstimates", "OperatingCharacteristics",
    "VariableDiagnostics", "ChainDiagnostics", "Scores", "DataSummaries", "Warnings", "WorkerMessages", "DiagnosticCounts", "BlockDiagnostics", "AutoRunCounts"))
  for (Path in Paths) {
    Manifest <- ReadSavedSimulation(Path)
    Definition <- Manifest$Definition
    Scenario <- Definition$Scenario
    Name <- Scenario$Name
    Design[[Name]] <- c(Definition, list(Requested = Manifest$Requested, Resources = Manifest$Resources))
    Files <- list.files(dirname(Path), pattern = "^Replication[0-9]+\\.rds$", full.names = TRUE)
    Results <- lapply(Files, function(P) {
      X <- tryCatch(readRDS(P), error = function(E) stop(paste("Cannot read", basename(P), ":", conditionMessage(E))))
      if (!identical(X$DefinitionHash, SimulationHash(Definition))) stop(paste("Settings differ in", basename(P)))
      X
    })
    if (length(Results)) Results <- Results[order(vapply(Results, function(X) X$Replication, numeric(1)))]
    Ids <- vapply(Results, function(X) X$Replication, numeric(1))
    if (anyDuplicated(Ids) || any(Ids < 1 | Ids > Manifest$Requested)) stop("Invalid saved replication identifiers.")
    AddIds <- function(X, Id) {
      if (!nrow(X)) return(data.frame())
      cbind(Scenario = Name, Replication = Id, X)
    }
    Status <- BindSimulationRows(lapply(Results, function(X) data.frame(
      Scenario = Name, Replication = X$Replication, DataSeed = X$Seeds$Data, SamplerSeed = X$Seeds$Sampler,
      FitStatus = X$FitStatus, Stage = X$Stage, DiagnosticsPassed = X$DiagnosticsPassed,
      ScoreFlag = X$ScoreFlag, Warnings = length(X$Warnings), Review = X$Review,
      WarmupEstablished = X$WarmupEstablished, WarmupBlocks = X$WarmupBlocks,
      SamplingBlocks = X$SamplingBlocks, TotalBlocks = X$TotalBlocks,
      WarmupIterations = X$WarmupIterations, DrawsPerChain = X$DrawsPerChain,
      StopReason = X$StopReason, RhatPassed = X$RhatPassed, EssPassed = X$EssPassed,
      DiagnosticSeconds = X$DiagnosticSeconds,
      SamplingSeconds = X$SamplingSeconds, TotalSeconds = X$TotalSeconds, Error = X$Error)))
    if (!nrow(Status)) Status <- data.frame(Scenario = character(), Replication = numeric(), FitStatus = character(),
      DiagnosticsPassed = logical(), ScoreFlag = logical(), Warnings = numeric(), Review = logical(),
      WarmupEstablished = logical(), WarmupBlocks = numeric(), SamplingBlocks = numeric(),
      TotalBlocks = numeric(), WarmupIterations = numeric(), DrawsPerChain = numeric(),
      StopReason = character(), RhatPassed = logical(), EssPassed = logical(), DiagnosticSeconds = numeric(),
      SamplingSeconds = numeric(), TotalSeconds = numeric())
    Parameters <- BindSimulationRows(lapply(Results, function(X) AddIds(X$Parameters, X$Replication)))
    Truth <- GetSimulationTruth(Scenario)
    Parts$Status[[Name]] <- Status
    Parts$Truth[[Name]] <- cbind(Scenario = Name, Truth)
    Parts$ParameterEstimates[[Name]] <- Parameters
    Parts$OperatingCharacteristics[[Name]] <- CalculateCustomOperatingCharacteristics(Parameters, Status, Truth, Name)
    for (Field in c("VariableDiagnostics", "ChainDiagnostics", "Scores", "BlockDiagnostics")) {
      Parts[[Field]][[Name]] <- BindSimulationRows(lapply(Results, function(X) AddIds(X[[Field]], X$Replication)))
    }
    Parts$DataSummaries[[Name]] <- BindSimulationRows(lapply(Results, function(X) AddIds(X$DataSummary, X$Replication)))
    Parts$Warnings[[Name]] <- BindSimulationRows(lapply(Results, function(X) {
      if (length(X$Warnings)) data.frame(Scenario = Name, Replication = X$Replication, Warning = X$Warnings) else data.frame()
    }))
    Parts$WorkerMessages[[Name]] <- BindSimulationRows(lapply(Results, function(X) {
      if (length(X$WorkerMessages)) data.frame(Scenario = Name, Replication = X$Replication,
        Line = seq_along(X$WorkerMessages), Text = X$WorkerMessages) else data.frame()
    }))
    S <- Definition$Settings
    Completed <- Status$FitStatus == "Completed"
    Parts$Design[[Name]] <- data.frame(Scenario = Name, Participants = Scenario$Participants,
      ActiveParticipants = Scenario$ActiveParticipants, Alpha = Scenario$Alpha,
      Requested = Manifest$Requested, Attempted = nrow(Status), NotRun = Manifest$Requested - nrow(Status),
      Intervals = length(Scenario$RecurrenceRates), BaselineLogMean = S$BaselineLogMean,
      BaselineLogSd = S$BaselineLogSd, FixedEffectSd = S$FixedEffectSd, AlphaSd = S$AlphaSd,
      FrailtyShape = S$FrailtyShape, FrailtyRate = S$FrailtyRate,
      Chains = S$Chains, Warmup = S$Warmup, Sampling = S$Sampling,
      MaximumWarmupBlocks = S$MaximumWarmupBlocks, MaximumSamplingBlocks = S$MaximumSamplingBlocks, MinimumEss = S$MinimumEss, MaximumRhat = S$MaximumRhat,
      ModelHash = Definition$ModelHash, ImplementationHash = Definition$ImplementationHash,
      Rcpp = unname(Definition$Versions[["Rcpp"]]),
      CoreFraction = Manifest$Resources$CoreFraction, CoreBudget = Manifest$Resources$Budget,
      ConcurrentFits = Manifest$Resources$Workers, ParallelChains = Manifest$Resources$ParallelChains)
    Parts$DiagnosticCounts[[Name]] <- data.frame(Scenario = Name, Attempted = nrow(Status),
      Completed = sum(Completed), FailedFits = sum(!Completed), McmcFlags = sum(Completed & !Status$DiagnosticsPassed),
      ScoreFlags = sum(Status$ScoreFlag), Warnings = sum(Status$Warnings > 0), AnyReview = sum(Status$Review))
    Kept <- Status[Completed, ]
    Parts$AutoRunCounts[[Name]] <- data.frame(Scenario = Name, Completed = nrow(Kept),
      WarmupExtended = sum(Kept$WarmupBlocks > 1), SamplingExtended = sum(Kept$SamplingBlocks > 1),
      CriteriaMet = sum(Kept$StopReason == "CriteriaMet"),
      WarmupLimit = sum(Kept$StopReason == "WarmupLimit"), SamplingLimit = sum(Kept$StopReason == "SamplingLimit"),
      RhatUnmet = sum(!Kept$RhatPassed), EssUnmet = sum(!Kept$EssPassed),
      MeanRetainedPerChain = if (nrow(Kept)) mean(Kept$DrawsPerChain) else NA_real_,
      MaximumRetainedPerChain = if (nrow(Kept)) max(Kept$DrawsPerChain) else NA_real_,
      MeanWarmupPerChain = if (nrow(Kept)) mean(Kept$WarmupIterations) else NA_real_)
  }
  Tables <- lapply(Parts, BindSimulationRows)
  Tables$FrailtyPrior <- BindSimulationRows(lapply(names(Design), function(Name) {
    S <- Design[[Name]]$Settings
    cbind(Scenario = Name, GetFrailtyPriorSummary(S$FrailtyShape, S$FrailtyRate))
  }))

  Tables$BaselineDesign <- BindSimulationRows(lapply(names(Design), function(Name) {
    S <- Design[[Name]]$Scenario
    data.frame(Scenario = Name, Interval = seq_along(S$RecurrenceRates),
      Start = head(S$Cutpoints, -1), End = tail(S$Cutpoints, -1),
      RecurrenceRate = S$RecurrenceRates, DeathRate = S$DeathRates)
  }))
  for (Name in names(Tables)) utils::write.csv(Tables[[Name]], file.path(SummaryDirectory, paste0(Name, ".csv")), row.names = FALSE, na = "")
  Lines <- c("Parameter recovery simulation", "",
    "AllFinite includes finite parameter summaries from completed fits, including diagnostic flags.",
    "Coverage uses the Valid denominator and refers to 95% parameter credible intervals.",
    "DiagnosticsPassed is reported separately in OperatingCharacteristics.csv.",
    "Detailed settings and diagnostics are saved in the accompanying CSV files.", "")
  Core <- c("BetaR", "GammaR", "BetaD", "GammaD", "Alpha", "FrailtyVariance")
  for (Name in names(Design)) {
    S <- Tables$Status[Tables$Status$Scenario == Name, ]
    D <- Tables$Design[Tables$Design$Scenario == Name, ]
    G <- Tables$DiagnosticCounts[Tables$DiagnosticCounts$Scenario == Name, ]
    A <- Tables$AutoRunCounts[Tables$AutoRunCounts$Scenario == Name, ]
    P <- Tables$OperatingCharacteristics
    P <- P[P$Scenario == Name & P$Subset == "AllFinite" & P$Parameter %in% Core, ]
    MeanFinite <- function(X) if (any(is.finite(X))) mean(X[is.finite(X)]) else NA_real_
    Lines <- c(Lines, paste("Scenario:", Name, "N:", D$Participants, "Alpha:", D$Alpha),
      paste("Requested:", D$Requested, "Attempted:", D$Attempted, "Remaining:", D$NotRun),
      paste("Completed:", G$Completed, "Failed:", G$FailedFits, "MCMC flags:", G$McmcFlags,
        "Score flags:", G$ScoreFlags, "Warnings:", G$Warnings),
      paste("Chains:", D$Chains, "Initial warmup per chain:", D$Warmup, "Block size per chain:", D$Sampling),
      paste("Maximum warmup assessment blocks:", D$MaximumWarmupBlocks, "Maximum retained blocks:", D$MaximumSamplingBlocks),
      paste("Warmup extended:", A$WarmupExtended, "Retained sampling extended:", A$SamplingExtended,
        "Criteria met:", A$CriteriaMet, "Warmup limit:", A$WarmupLimit, "Sampling limit:", A$SamplingLimit),
      paste("Retained per chain, mean:", round(A$MeanRetainedPerChain, 1), "maximum:", A$MaximumRetainedPerChain),
      paste("Concurrent fits:", D$ConcurrentFits, "Parallel chains per fit:", D$ParallelChains, "Core budget:", D$CoreBudget),
      paste("Mean sampling seconds:", round(MeanFinite(S$SamplingSeconds), 2)),
      paste("Mean total seconds per replication:", round(MeanFinite(S$TotalSeconds), 2)),
      capture.output(print(P[, c("Parameter", "Truth", "Valid", "Bias", "BiasMonteCarloSe", "Rmse",
        "EmpiricalSd", "MeanPosteriorSd", "Coverage", "CoverageMonteCarloSe")], row.names = FALSE)), "")
  }
  writeLines(Lines, file.path(SummaryDirectory, "Summary.txt"))
  WriteCustomTables(Tables, Design, SummaryDirectory)
  message("Results: ", normalizePath(SummaryDirectory, winslash = "/"))
  invisible(list(Design = Design, Tables = Tables))
}

WriteCustomTables <- function(Tables, Design, SummaryDirectory) {
  Directory <- file.path(SummaryDirectory, "Tables")
  dir.create(Directory, showWarnings = FALSE)
  Core <- c("BetaR", "GammaR", "BetaD", "GammaD", "Alpha", "FrailtyVariance")
  OC <- Tables$OperatingCharacteristics
  Cumulative <- unique(Tables$Truth$Parameter[grepl("Cumulative", Tables$Truth$Parameter)])
  WriteSimulationResultTable(OC, Design, Core, file.path(Directory, "ParameterRecovery.tex"),
    "Recovery of regression coefficients, association and frailty variance using the custom Gibbs sampler.", "tab:ParameterRecovery")
  WriteSimulationResultTable(OC, Design, Cumulative, file.path(Directory, "CumulativeBaselineRecovery.tex"),
    "Recovery of cumulative baseline intensity and hazard using the custom Gibbs sampler.", "tab:CumulativeBaselineRecovery")
  IntervalParameters <- unique(Tables$Truth$Parameter[grepl("LogRate", Tables$Truth$Parameter)])
  WriteSimulationResultTable(OC, Design, IntervalParameters,
    file.path(Directory, "IntervalBaselineRecovery.tex"), "Recovery of baseline log rates using the custom Gibbs sampler.", "tab:IntervalBaselineRecovery", Long = TRUE)
  WriteSimulationCoverageTable(OC, Design, c(Core, Cumulative), file.path(Directory, "CoverageMonteCarloIntervals.tex"))
  D <- Tables$Design
  Rows <- vapply(seq_len(nrow(D)), function(J) {
    X <- D[J, ]
    paste0(paste(c(X$Participants, X$ActiveParticipants, SimulationLatexNumber(X$Alpha, 1)), collapse = " & "), " \\\\")
  }, character(1))
  WriteSimulationSimpleTable(file.path(Directory, "SimulationDesign.tex"),
    "Simulation settings.", "tab:SimulationDesign",
    "@{}S[table-format=3.0] S[table-format=3.0] S[table-format=1.1]@{}",
    "{$n$} & {Active arm} & {$\\alpha$} \\\\", Rows,
    paste0("Allocation is balanced and the generating frailty variance is one. Baseline rates and other generating parameters ",
      "are fixed across scenarios. Increasing the association coefficient also changes marginal mortality and recurrence exposure. ",
      "All model parameters are estimated; prior and sampling settings are recorded in Design.csv and Settings.rds."))
  G <- Tables$DiagnosticCounts
  Rows <- vapply(seq_len(nrow(G)), function(J) {
    X <- G[J, ]
    S <- Design[[X$Scenario]]$Scenario
    paste0(paste(c(S$Participants, SimulationLatexNumber(S$Alpha, 1), X$FailedFits, X$McmcFlags, X$ScoreFlags, X$Warnings), collapse = " & "), " \\\\")
  }, character(1))
  WriteSimulationSimpleTable(file.path(Directory, "SimulationDiagnostics.tex"),
    "Fit failures and numerical diagnostic flags.", "tab:SimulationDiagnostics",
    "@{}S[table-format=3.0] S[table-format=1.1] *{4}{S[table-format=5.0]}@{}",
    "{$n$} & {$\\alpha$} & {Failed} & {MCMC flags} & {Score flags} & {Warnings} \\\\", Rows,
    paste0("Entries count replications, and categories can overlap. MCMC flags identify an unavailable diagnostic, ",
      "Rhat above its saved limit, bulk or tail ESS below its saved threshold, or an unmet warmup assessment criterion. ",
      "The main recovery tables retain every finite summary from completed fits, including flagged fits. ",
      "Unresolved flags must be reviewed before interpreting the final performance estimates. ",
      "A separate summary restricted to fits passing MCMC diagnostics is supplied in OperatingCharacteristics.csv."))

  A <- Tables$AutoRunCounts
  Rows <- vapply(seq_len(nrow(A)), function(J) {
    X <- A[J, ]
    S <- Design[[X$Scenario]]$Scenario
    paste0(paste(c(S$Participants, SimulationLatexNumber(S$Alpha, 1), X$WarmupExtended, X$SamplingExtended, X$WarmupLimit,
      X$SamplingLimit, SimulationLatexNumber(X$MeanRetainedPerChain, 0),
      SimulationLatexNumber(X$MaximumRetainedPerChain, 0)), collapse = " & "), " \\\\")
  }, character(1))
  WriteSimulationSimpleTable(file.path(Directory, "AutomaticSampling.tex"),
    "Automatic extension of sampling and the number of draws used.", "tab:AutomaticSampling",
    "@{}S[table-format=3.0] S[table-format=1.1] *{6}{S[table-format=5.0]}@{}",
    paste0("{$n$} & {$\\alpha$} & {Warmup} & {Sampling} & {Warmup} & {Sampling} & {Mean draws} & {Max. draws} \\\\", "\n",
      " & & {extended} & {extended} & {limit} & {limit} & {per chain} & {per chain} \\\\"), Rows,
    paste0("Extension and limit entries count completed fits. Warmup assessment uses the latest block alone; ",
      "earlier unsuccessful blocks are discarded. After the first block passes Rhat, all subsequent draws are retained. ",
      "Sampling then continues until Rhat and both ESS criteria pass or the retained block limit is reached. ",
      "A fit that never passes warmup assessment contributes its final provisional block and is flagged. ",
      "Fits reaching the retained sampling limit contribute all retained draws. Actual settings are in Design.csv; ",
      "unresolved fits remain in the primary recovery summaries. Categories can overlap."))

  Baselines <- unique(Tables$BaselineDesign[, setdiff(names(Tables$BaselineDesign), "Scenario")])
  SameBaselines <- all(vapply(Design, function(X) {
    First <- Design[[1]]$Scenario
    identical(X$Scenario$Cutpoints, First$Cutpoints) &&
      identical(X$Scenario$RecurrenceRates, First$RecurrenceRates) &&
      identical(X$Scenario$DeathRates, First$DeathRates)
  }, logical(1)))
  if (SameBaselines) {
    Rows <- vapply(seq_len(nrow(Baselines)), function(J) {
      X <- Baselines[J, ]
      Values <- mapply(SimulationLatexNumber, as.numeric(X), c(0, 3, 3, 3, 4), USE.NAMES = FALSE)
      paste0(paste(Values, collapse = " & "), " \\\\")
    }, character(1))
    WriteSimulationSimpleTable(file.path(Directory, "GeneratingBaselines.tex"),
      "Baseline rates used to generate the four simulation scenarios.", "tab:GeneratingBaselines",
      "@{}S[table-format=1.0] *{2}{S[table-format=1.3]} S[table-format=1.3] S[table-format=1.4]@{}",
      "{Interval} & {Start (years)} & {End (years)} & {Recurrence rate} & {Death hazard} \\\\", Rows,
      paste0("Rates are per year at zero log frailty, in the reference arm and with the baseline covariate equal to zero. ",
        "The first interval starts at time zero; intervals include their right endpoint. ",
        "Generation and fitting use these same cutpoints. Each log rate is estimated separately, ",
        "with no smoothing prior and without supplying the generating rates to the likelihood. ",
        "The priors are recorded in Design.csv; the rates remain fixed across replications."))
  } else {
    writeLines("% Scenario-specific generating rates are in BaselineDesign.csv.",
      file.path(Directory, "GeneratingBaselines.tex"))
  }
  Files <- c("SimulationDesign", "GeneratingBaselines", "ParameterRecovery", "CumulativeBaselineRecovery", "IntervalBaselineRecovery",
    "CoverageMonteCarloIntervals", "SimulationDiagnostics", "AutomaticSampling")
  Preamble <- c("\\documentclass[11pt,a4paper]{article}", "\\usepackage[margin=20mm]{geometry}",
    "\\usepackage[T1]{fontenc}", "\\usepackage{amsmath,booktabs,longtable,siunitx,caption,ragged2e}",
    "\\usepackage{charter}", "\\sisetup{group-digits=false}", "\\begin{document}")
  Body <- unlist(lapply(Files, function(Name) c(paste0("\\input{Tables/", Name, ".tex}"), "\\clearpage")))
  writeLines(c(Preamble, Body, "\\end{document}"), file.path(SummaryDirectory, "SimulationTables.tex"))
  # zip is optional: all TeX files remain usable if the system zip tool is absent.
  Previous <- getwd()
  on.exit(setwd(Previous), add = TRUE)
  setwd(SummaryDirectory)
  tryCatch({
    Status <- suppressWarnings(utils::zip("SimulationTables.zip", c("SimulationTables.tex", paste0("Tables/", Files, ".tex")), flags = "-q"))
    if (length(Status) != 1 || is.na(Status) || Status != 0) message("TeX files are ready; automatic ZIP creation was unavailable.")
  }, error = function(E) message("TeX files are ready; automatic ZIP creation was unavailable."))
  invisible(Directory)
}