# Completion and interval performance for recurrent events and mortality.

CompletionSettings <- list(
  Replications = 500,  # Total simulated trials.
  Seed = 20261011,
  CoreFraction = 0.60,
  MaxConcurrentFits = Inf,
  Chains = 2,
  Warmup = 2000,
  Sampling = 8000,  # Iterations per chain in each assessment or sampling block.
  MaximumWarmupBlocks = 5,
  MaximumSamplingBlocks = 5,
  FixedEffectSd = 5,
  AlphaSd = 5,
  FrailtyShape = 0.5,
  FrailtyRate = 0.05,
  BaselineLogMean = 0,
  BaselineLogSd = 5,
  BlockMoves = TRUE,
  MinimumEss = 400,
  MaximumRhat = 1.05,
  ImputationBatchSize = 1000,
  ConfidenceLevel = 0.95,
  TruthNodes = 64,
  TruthCheckNodes = 128,
  TruthTolerance = 0.000001,
  RetryFailed = FALSE,
  OutputFolder = "CompletionSimulationResults",
  InstallMissingPackages = TRUE
)

CompletionSimulationVersion <- 1
CompletionProgramPath <- local({
  Paths <- unlist(lapply(sys.frames(), function(Frame) Frame$ofile), use.names = FALSE)
  Arguments <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (length(Paths)) normalizePath(tail(Paths, 1), winslash = "/", mustWork = TRUE)
  else if (length(Arguments)) normalizePath(sub("^--file=", "", Arguments[1]), winslash = "/", mustWork = TRUE)
  else ""
})

GetCompletionScenario <- function(Index = 1) {
  if (length(Index) != 1 || !is.numeric(Index) || is.na(Index) || Index != 1) {
    stop("Scenario index must be 1.", call. = FALSE)
  }
  CheckSimulationScenario(list(
    Name = "Scenario01",
    Participants = 200,
    ActiveParticipants = 100,
    AgeProbability = 0.50,
    Cutpoints = seq(0, 4.5, length.out = 5),
    RecurrenceRates = c(0.510, 0.565, 0.610, 0.650),
    DeathRates = c(0.0575, 0.0675, 0.0775, 0.0875),
    BetaR = log(0.75), GammaR = log(1.25),
    BetaD = log(0.70), GammaD = log(1.50),
    Alpha = 0.50,
    FrailtyVariance = 1.00,
    CensoringRate = 0.17,
    BaselineTimes = c(2, 4.5)
  ))
}

GetCompletionRules <- function() {
  data.frame(Scenario = c("MAR", "J2RBoth"), RecurrenceBorrowing = c(0, 1),
    DeathBorrowing = c(0, 1), Description = c("Assigned treatment", "Both components switch"))
}

CheckSimulationScenario <- function(Scenario) {
  Required <- c("Name", "Participants", "ActiveParticipants", "AgeProbability", "Cutpoints",
    "RecurrenceRates", "DeathRates", "BetaR", "GammaR", "BetaD", "GammaD",
    "Alpha", "FrailtyVariance", "CensoringRate", "BaselineTimes")
  if (!is.list(Scenario) || !setequal(names(Scenario), Required)) {
    stop("The scenario has missing or unknown settings.", call. = FALSE)
  }
  if (!is.character(Scenario$Name) || length(Scenario$Name) != 1 ||
      !grepl("^[A-Za-z][A-Za-z0-9]*$", Scenario$Name)) stop("Use a simple scenario name.", call. = FALSE)
  Numeric <- unlist(Scenario[setdiff(Required, "Name")], use.names = FALSE)
  if (!is.numeric(Numeric) || any(!is.finite(Numeric))) stop("Scenario values must be finite numbers.", call. = FALSE)
  Scalars <- setdiff(Required, c("Name", "Cutpoints", "RecurrenceRates", "DeathRates", "BaselineTimes"))
  if (any(lengths(Scenario[Scalars]) != 1)) stop("A scenario setting must be a single number.", call. = FALSE)
  N <- Scenario$Participants
  A <- Scenario$ActiveParticipants
  if (N < 20 || N != floor(N) || A < 2 || A > N - 2 || A != floor(A)) stop("Invalid arm sizes.", call. = FALSE)
  if (Scenario$AgeProbability <= 0 || Scenario$AgeProbability >= 1 || Scenario$FrailtyVariance <= 0 ||
      Scenario$CensoringRate < 0) stop("Invalid covariate, frailty or censoring setting.", call. = FALSE)
  Cutpoints <- Scenario$Cutpoints
  K <- length(Cutpoints) - 1
  if (K < 1 || Cutpoints[1] != 0 || any(diff(Cutpoints) <= 0)) {
    stop("Cutpoints must start at zero and increase strictly.", call. = FALSE)
  }
  if (length(Scenario$RecurrenceRates) != K || length(Scenario$DeathRates) != K ||
      any(c(Scenario$RecurrenceRates, Scenario$DeathRates) <= 0)) stop("Supply one positive rate per interval for each process.", call. = FALSE)
  if (!length(Scenario$BaselineTimes) || anyDuplicated(Scenario$BaselineTimes) ||
      any(Scenario$BaselineTimes <= 0 | Scenario$BaselineTimes > tail(Cutpoints, 1))) {
    stop("Baseline assessment times must lie within follow-up.", call. = FALSE)
  }
  Scenario[Required]
}

GetSimulationSeed <- function(Seed, Replication, Stream) {
  Value <- Seed + 100000*Replication + Stream
  if (any(!is.finite(Value)) || any(Value <= 0 | Value >= .Machine$integer.max)) stop("Simulation seed is out of range.", call. = FALSE)
  Value
}

SetSimulationSeed <- function(Seed) {
  set.seed(Seed, kind = "Mersenne-Twister", normal.kind = "Inversion", sample.kind = "Rejection")
}

GetSimulationTruth <- function(Scenario) {
  Truth <- c(BetaR = Scenario$BetaR, GammaR = Scenario$GammaR,
    BetaD = Scenario$BetaD, GammaD = Scenario$GammaD, Alpha = Scenario$Alpha,
    FrailtyVariance = Scenario$FrailtyVariance, FrailtyPrecision = 1/Scenario$FrailtyVariance)
  Truth <- c(Truth, setNames(log(Scenario$RecurrenceRates), paste0("RecurrenceLogRate", seq_along(Scenario$RecurrenceRates))),
    setNames(log(Scenario$DeathRates), paste0("DeathLogRate", seq_along(Scenario$DeathRates))))
  for (Index in seq_along(Scenario$BaselineTimes)) {
    Time <- Scenario$BaselineTimes[Index]
    Exposure <- pmax(0, pmin(Time, tail(Scenario$Cutpoints, -1)) - head(Scenario$Cutpoints, -1))
    Truth[paste0("RecurrenceCumulative", Index)] <- sum(Exposure*Scenario$RecurrenceRates)
    Truth[paste0("DeathCumulative", Index)] <- sum(Exposure*Scenario$DeathRates)
  }
  data.frame(Parameter = names(Truth), Truth = unname(Truth), stringsAsFactors = FALSE)
}

GenerateSimulationData <- function(Scenario, Seed) {
  SetSimulationSeed(Seed)
  N <- Scenario$Participants
  Cutpoints <- Scenario$Cutpoints
  Horizon <- tail(Cutpoints, 1)
  Treatment <- sample(c(rep(1, Scenario$ActiveParticipants), rep(0, N - Scenario$ActiveParticipants)))
  Age60 <- stats::rbinom(N, 1, Scenario$AgeProbability)
  Frailty <- stats::rnorm(N, 0, sqrt(Scenario$FrailtyVariance))
  # Death is generated by cumulative hazard inversion. Beyond Horizon, only
  # survival through Horizon is required. Inf is an internal sentinel.
  DeathMultiplier <- exp(Scenario$BetaD*Treatment + Scenario$GammaD*Age60 + Scenario$Alpha*Frailty)
  Remaining <- stats::rexp(N)
  DeathTime <- rep(Inf, N)
  for (K in seq_along(Scenario$DeathRates)) {
    Rate <- Scenario$DeathRates[K]*DeathMultiplier
    Increment <- Rate*(Cutpoints[K + 1] - Cutpoints[K])
    Alive <- is.infinite(DeathTime)
    Hit <- Alive & Remaining <= Increment
    DeathTime[Hit] <- Cutpoints[K] + Remaining[Hit]/Rate[Hit]
    Remaining[Alive & !Hit] <- Remaining[Alive & !Hit] - Increment[Alive & !Hit]
  }
  Censoring <- if (Scenario$CensoringRate == 0) rep(Inf, N) else stats::rexp(N, Scenario$CensoringRate)
  Stop <- pmin(DeathTime, Censoring, Horizon)
  Death <- as.numeric(DeathTime <= Censoring & DeathTime <= Horizon)
  Exposure <- GetSimulationExposure(rep(0, N), Stop, Cutpoints)
  RateR <- exp(Scenario$BetaR*Treatment + Scenario$GammaR*Age60 + Frailty)
  Means <- sweep(Exposure, 2, Scenario$RecurrenceRates, "*")*RateR
  Counts <- matrix(stats::rpois(length(Means), as.vector(Means)), nrow = N)
  if (any(!is.finite(Counts))) stop("Invalid generated counts.", call. = FALSE)
  Patients <- data.frame(Id = seq_len(N), Treatment = Treatment, Age60 = Age60,
    Start = 0, Stop = Stop, Death = Death, Count = rowSums(Counts))
  Index <- which(Exposure > 0, arr.ind = TRUE)
  Cells <- data.frame(Id = Index[, 1], Interval = Index[, 2], Exposure = Exposure[Index],
    Recurrence = Counts[Index], Death = 0)
  Cells <- Cells[order(Cells$Id, Cells$Interval), ]
  DeathIds <- which(Death == 1)
  if (length(DeathIds)) {
    Bins <- as.integer(cut(Stop[DeathIds], Cutpoints, right = TRUE, include.lowest = TRUE))
    Positions <- match(paste(DeathIds, Bins), paste(Cells$Id, Cells$Interval))
    if (anyNA(Positions)) stop("A generated death has no risk interval.", call. = FALSE)
    Cells$Death[Positions] <- 1
  }
  Cells$Treatment <- Treatment[Cells$Id]
  Cells$Age60 <- Age60[Cells$Id]
  if (any(Cells$Exposure <= 0) || sum(Cells$Death) != sum(Death) ||
      sum(Cells$Recurrence) != sum(Patients$Count) || abs(sum(Cells$Exposure) - sum(Stop)) > 1e-8) {
    stop("Generated exposure and counts are inconsistent.", call. = FALSE)
  }
  # Cell counts are sufficient for these piecewise constant hazards. No event
  # times, outcomes after censoring, or generated frailties are given to the fit.
  Summary <- data.frame(Participants = N, ActiveParticipants = sum(Treatment),
    AgeProportion = mean(Age60), Recurrences = sum(Patients$Count),
    Deaths = sum(Death), PersonYears = sum(Stop),
    CensoredEarly = sum(Death == 0 & Stop < Horizon),
    ReachedEnd = sum(Stop == Horizon), ZeroCounts = sum(Patients$Count == 0),
    MaximumCount = max(Patients$Count))
  list(Patients = Patients, Cells = Cells, Summary = Summary,
    Latent = list(Frailty = Frailty, PotentialCensoring = Censoring))
}

GetSimulationExposure <- function(Start, Stop, Cutpoints) {
  if (length(Start) != length(Stop) || any(!is.finite(c(Start, Stop))) ||
      any(Start < 0) || any(Stop < Start) || any(Stop > tail(Cutpoints, 1))) {
    stop("Risk interval times are invalid.", call. = FALSE)
  }
  Exposure <- vapply(seq_len(length(Cutpoints) - 1), function(Index) {
    pmax(0, pmin(Stop, Cutpoints[Index + 1]) - pmax(Start, Cutpoints[Index]))
  }, numeric(length(Start)))
  matrix(Exposure, nrow = length(Start), ncol = length(Cutpoints) - 1)
}

SimulationHash <- function(Object) {
  Path <- tempfile("SimulationHash")
  on.exit(unlink(Path), add = TRUE)
  saveRDS(Object, Path, compress = FALSE, version = 2)
  unname(tools::md5sum(Path))
}

SaveSimulationRds <- function(Object, Path) {
  Partial <- paste0(Path, ".part")
  saveRDS(Object, Partial, compress = "gzip", version = 2)
  Backup <- paste0(Path, ".previous")
  if (file.exists(Backup)) unlink(Backup)
  if (file.exists(Path) && !file.rename(Path, Backup)) stop("Cannot replace a checkpoint. Close files using it.")
  if (!file.rename(Partial, Path)) {
    if (file.exists(Backup)) file.rename(Backup, Path)
    stop("Cannot save the checkpoint.")
  }
  if (file.exists(Backup)) unlink(Backup)
  invisible(Path)
}

ReadSavedSimulation <- function(Path) {
  if (!file.exists(Path) && file.exists(paste0(Path, ".previous"))) {
    if (!file.rename(paste0(Path, ".previous"), Path)) stop("Cannot recover a saved checkpoint.")
  }
  readRDS(Path)
}

BuildCustomData <- function(Data, Scenario, Settings = CompletionSettings) {
  K <- length(Scenario$Cutpoints) - 1
  Exposure <- t(vapply(Scenario$BaselineTimes, function(Time) {
    pmax(0, pmin(Time, tail(Scenario$Cutpoints, -1)) - head(Scenario$Cutpoints, -1))
  }, numeric(K)))
  list(Participants = nrow(Data$Patients), Cells = nrow(Data$Cells), Intervals = K,
    Times = length(Scenario$BaselineTimes), Id = as.integer(Data$Cells$Id),
    Bin = as.integer(Data$Cells$Interval), CountR = as.integer(Data$Cells$Recurrence),
    CountD = as.integer(Data$Cells$Death), X = as.matrix(Data$Cells[, c("Treatment", "Age60")]),
    LogExposure = log(Data$Cells$Exposure), BaselineExposure = Exposure,
    BaselineLogMean = Settings$BaselineLogMean, BaselineLogSd = Settings$BaselineLogSd,
    FixedSd = Settings$FixedEffectSd, AlphaSd = Settings$AlphaSd,
    FrailtyShape = Settings$FrailtyShape, FrailtyRate = Settings$FrailtyRate)
}

CustomComponents <- function(P, D) {
  B <- P$FrailtyStandard*exp(-P$LogFrailtyPrecision/2)
  Coefficients <- c(P$BetaR, P$GammaR, P$BetaD, P$GammaD)
  EtaR <- D$LogExposure + P$RecurrenceLogRate[D$Bin] + B[D$Id] +
    as.vector(D$X %*% Coefficients[1:2])
  EtaD <- D$LogExposure + P$DeathLogRate[D$Bin] + P$Alpha*B[D$Id] +
    as.vector(D$X %*% Coefficients[3:4])
  list(R = P$RecurrenceLogRate, D = P$DeathLogRate, B = B,
    EtaR = EtaR, EtaD = EtaD, Coefficients = Coefficients)
}

CustomDensityR <- function(P, D) {
  C <- CustomComponents(P, D)
  LogPrecision <- P$LogFrailtyPrecision
  Value <- sum(stats::dpois(D$CountR, exp(C$EtaR), log = TRUE)) +
    sum(stats::dpois(D$CountD, exp(C$EtaD), log = TRUE)) +
    sum(stats::dnorm(C$Coefficients, 0, D$FixedSd, log = TRUE)) +
    stats::dnorm(P$Alpha, 0, D$AlphaSd, log = TRUE) +
    sum(stats::dnorm(c(C$R, C$D), D$BaselineLogMean, D$BaselineLogSd, log = TRUE))
  # Evaluate the density in precision and actual frailties, then add the
  # Jacobians for log precision and the standardized Gaussian frailties.
  Value + stats::dgamma(exp(LogPrecision), D$FrailtyShape, D$FrailtyRate, log = TRUE) +
    LogPrecision + sum(stats::dnorm(C$B, 0, exp(-LogPrecision/2), log = TRUE)) -
    D$Participants*LogPrecision/2
}

GetCustomInitial <- function(Data, D) {
  RateR <- max(sum(Data$Cells$Recurrence)/sum(Data$Patients$Stop), 0.01)
  RateD <- max(sum(Data$Patients$Death)/sum(Data$Patients$Stop), 0.001)
  list(BetaR = 0, GammaR = 0, BetaD = 0, GammaD = 0, Alpha = 0.3,
    LogFrailtyPrecision = 0, RecurrenceLogRate = rep(log(RateR), D$Intervals),
    DeathLogRate = rep(log(RateD), D$Intervals), FrailtyStandard = rep(0, D$Participants))
}

SummarizeCustomMatrix <- function(X) {
  Q <- stats::quantile(as.numeric(X), c(0.025, 0.5, 0.975), names = FALSE)
  Qse <- posterior::mcse_quantile(X, probs = c(0.025, 0.975), names = FALSE)
  c(Mean = mean(X), Sd = stats::sd(as.numeric(X)), Lower = Q[1], Median = Q[2], Upper = Q[3],
    MeanMonteCarloSe = posterior::mcse_mean(X), SdMonteCarloSe = posterior::mcse_sd(X),
    LowerMonteCarloSe = Qse[1], UpperMonteCarloSe = Qse[2],
    Rhat = posterior::rhat(X), BulkEss = posterior::ess_bulk(X), TailEss = posterior::ess_tail(X))
}

BindSimulationRows <- function(Rows) {
  Rows <- Filter(function(X) is.data.frame(X) && nrow(X) > 0, Rows)
  if (!length(Rows)) return(data.frame())
  Columns <- unique(unlist(lapply(Rows, names), use.names = FALSE))
  Rows <- lapply(Rows, function(X) {
    for (Name in setdiff(Columns, names(X))) X[[Name]] <- NA
    X[Columns]
  })
  Output <- do.call(rbind, Rows)
  rownames(Output) <- NULL
  Output
}

CustomSamplerCode <- r"(#include <Rcpp.h>
#include <algorithm>
#include <cmath>
#include <limits>
#include <vector>
using namespace Rcpp;
// [[Rcpp::plugins(cpp17)]]

struct Evaluation {
  double X, H, D;
};

// Log density relative to the current point. It is a Gaussian log density
// plus a linear term minus positive multiples of exponentials.
struct Conditional {
  double Linear, Precision;
  std::vector<double> Means, Slopes;
  Evaluation Eval(double X) const {
    double H = Linear*X - 0.5*Precision*X*X;
    double D = Linear - Precision*X;
    for (size_t J = 0; J < Means.size(); ++J) {
      if (Means[J] == 0 || Slopes[J] == 0) continue;
      double Y = Slopes[J]*X;
      double V = std::exp(std::log(Means[J]) + Y);
      if (!std::isfinite(V)) return {X, R_NegInf, -std::copysign(R_PosInf, Slopes[J])};
      H -= std::abs(Y) < 0.5 ? Means[J]*std::expm1(Y) : V - Means[J];
      D -= Slopes[J]*V;
    }
    return {X, H, D};
  }
  double Curvature() const {
    double Value = Precision;
    for (size_t J = 0; J < Means.size(); ++J) Value += Means[J]*Slopes[J]*Slopes[J];
    return Value;
  }
};

double OpenUniform() {
  double U;
  do { U = R::runif(0, 1); } while (U <= 0 || U >= 1);
  return U;
}

double LogIntegral(const Evaluation &P, double Left, double Right) {
  if (!std::isfinite(Left)) {
    if (P.D <= 0) stop("The left sampler tail is not integrable.");
    return P.H + P.D*(Right - P.X) - std::log(P.D);
  }
  if (!std::isfinite(Right)) {
    if (P.D >= 0) stop("The right sampler tail is not integrable.");
    return P.H + P.D*(Left - P.X) - std::log(-P.D);
  }
  double Width = Right - Left;
  if (Width <= 0) stop("The sampler envelope has an invalid interval.");
  if (P.D > 0) return P.H + P.D*(Right - P.X) + std::log(-std::expm1(-P.D*Width)) - std::log(P.D);
  if (P.D < 0) return P.H + P.D*(Left - P.X) + std::log(-std::expm1(P.D*Width)) - std::log(-P.D);
  return P.H + std::log(Width);
}

double DrawSegment(double Slope, double Left, double Right) {
  double U = OpenUniform();
  if (!std::isfinite(Left)) return Right + std::log(U)/Slope;
  if (!std::isfinite(Right)) return Left + std::log(U)/Slope;
  double Width = Right - Left;
  if (Slope == 0) return Left + U*Width;
  if (std::abs(Slope*Width) < 0.5) return Left + std::log1p(U*std::expm1(Slope*Width))/Slope;
  if (Slope > 0) return Right + std::log(U + (1 - U)*std::exp(-Slope*Width))/Slope;
  return Left + std::log(U + (1 - U)*std::exp(Slope*Width))/Slope;
}

double DrawConditional(const Conditional &F, double &Evaluations) {
  double Scale = 1/std::sqrt(F.Curvature());
  if (!std::isfinite(Scale) || Scale <= 0) stop("Invalid conditional curvature.");
  Evaluation Centre = F.Eval(0);
  Evaluation Left = F.Eval(-Scale), Right = F.Eval(Scale);
  Evaluations += 3;
  // Gaussian priors guarantee integrable tails. The guard aborts; it never
  // truncates the support or accepts a candidate from an invalid envelope.
  double TailSlope = 1/Scale;
  for (int J = 0; Left.D < TailSlope && J < 100; ++J) {
    Left = F.Eval(Left.X*2); ++Evaluations;
  }
  for (int J = 0; Right.D > -TailSlope && J < 100; ++J) {
    Right = F.Eval(Right.X*2); ++Evaluations;
  }
  if (!std::isfinite(Left.H) || !std::isfinite(Right.H) || Left.D <= 0 || Right.D >= 0) {
    stop("Could not construct the conditional envelope.");
  }
  std::vector<Evaluation> Points = {Left, Centre, Right};
  for (int Attempt = 0; Attempt < 1000; ++Attempt) {
    size_t Size = Points.size();
    std::vector<double> Bounds(Size + 1), LogMass(Size), Mass(Size);
    Bounds[0] = R_NegInf; Bounds[Size] = R_PosInf;
    for (size_t J = 1; J < Size; ++J) {
      const auto &A = Points[J - 1]; const auto &B = Points[J];
      double Difference = A.D - B.D;
      if (Difference <= 0 || !std::isfinite(Difference)) stop("Conditional slopes are not decreasing.");
      double Z = A.X + (B.H - A.H - B.D*(B.X - A.X))/Difference;
      double Tolerance = 1e-9*(1 + std::abs(A.X) + std::abs(B.X));
      if (Z < A.X - Tolerance || Z > B.X + Tolerance || !std::isfinite(Z)) stop("Invalid tangent intersection.");
      Bounds[J] = std::max(A.X, std::min(B.X, Z));
    }
    for (size_t J = 0; J < Size; ++J) LogMass[J] = LogIntegral(Points[J], Bounds[J], Bounds[J + 1]);
    double Max = *std::max_element(LogMass.begin(), LogMass.end()), Total = 0;
    for (size_t J = 0; J < Size; ++J) { Mass[J] = std::exp(LogMass[J] - Max); Total += Mass[J]; }
    if (!std::isfinite(Total) || Total <= 0) stop("Invalid sampler envelope mass.");
    double Target = OpenUniform()*Total, Sum = 0;
    size_t Segment = Size - 1;
    for (size_t J = 0; J < Size; ++J) { Sum += Mass[J]; if (Target <= Sum) { Segment = J; break; } }
    double X = DrawSegment(Points[Segment].D, Bounds[Segment], Bounds[Segment + 1]);
    double Upper = Points[Segment].H + Points[Segment].D*(X - Points[Segment].X);
    Evaluation Candidate = F.Eval(X); ++Evaluations;
    if (std::isnan(Candidate.H) || Candidate.H - Upper > 1e-8*(1 + std::abs(Candidate.H))) {
      stop("The conditional density exceeds its sampler envelope.");
    }
    if (std::log(OpenUniform()) <= Candidate.H - Upper) return X;
    if (!std::isfinite(Candidate.H) || !std::isfinite(Candidate.D)) {
      // An overflowing exponential has zero acceptance probability. Refine
      // the envelope at a finite point between this rejection and its knot.
      for (int Refine = 0; Refine < 100 && (!std::isfinite(Candidate.H) || !std::isfinite(Candidate.D)); ++Refine) {
        X = 0.5*(X + Points[Segment].X);
        Candidate = F.Eval(X); ++Evaluations;
      }
      if (!std::isfinite(Candidate.H) || !std::isfinite(Candidate.D)) stop("Nonfinite conditional evaluation.");
    }
    auto At = std::lower_bound(Points.begin(), Points.end(), X,
      [](const Evaluation &P, double Value) { return P.X < Value; });
    Points.insert(At, Candidate);
  }
  stop("Conditional sampling exceeded its iteration guard.");
  return NA_REAL;
}

// [[Rcpp::export]]
NumericVector SampleConditionalCpp(int Number, double Linear, double Precision,
    NumericVector Means, NumericVector Slopes) {
  if (Number < 1 || Precision <= 0 || Means.size() != Slopes.size()) stop("Invalid conditional input.");
  Conditional F{Linear, Precision, as<std::vector<double>>(Means), as<std::vector<double>>(Slopes)};
  for (double X : F.Means) if (!std::isfinite(X) || X < 0) stop("Invalid conditional weight.");
  NumericVector Out(Number); double Evaluations = 0;
  for (int J = 0; J < Number; ++J) {
    if (J%1000 == 0) checkUserInterrupt();
    Out[J] = DrawConditional(F, Evaluations);
  }
  Out.attr("Evaluations") = Evaluations;
  return Out;
}

// [[Rcpp::export]]
NumericMatrix EvaluateConditionalCpp(NumericVector X, double Linear, double Precision,
    NumericVector Means, NumericVector Slopes) {
  Conditional F{Linear, Precision, as<std::vector<double>>(Means), as<std::vector<double>>(Slopes)};
  NumericMatrix Out(X.size(), 2);
  for (int J = 0; J < X.size(); ++J) { Evaluation E = F.Eval(X[J]); Out(J, 0) = E.H; Out(J, 1) = E.D; }
  return Out;
}

// [[Rcpp::export]]
List GibbsChainCpp(List Data, List Initial, int Warmup, int Sampling, bool BlockMoves = true,
    Nullable<List> Continuation = R_NilValue) {
  int N = as<int>(Data["Participants"]), K = as<int>(Data["Intervals"]);
  int Times = as<int>(Data["Times"]), Cells = as<int>(Data["Cells"]);
  if (N < 2 || K < 1 || Warmup < 0 || Sampling < 1) stop("Invalid sampler dimensions.");
  IntegerVector Id = Data["Id"], Bin = Data["Bin"], CountR = Data["CountR"], CountD = Data["CountD"];
  NumericMatrix X = Data["X"], BaseExposure = Data["BaselineExposure"];
  NumericVector LogExposure = Data["LogExposure"];
  double FixedPrecision = 1/std::pow(as<double>(Data["FixedSd"]), 2);
  double AlphaPrecision = 1/std::pow(as<double>(Data["AlphaSd"]), 2);
  double BasePrecision = 1/std::pow(as<double>(Data["BaselineLogSd"]), 2);
  double BaseMean = as<double>(Data["BaselineLogMean"]);
  double Shape = as<double>(Data["FrailtyShape"]), Rate = as<double>(Data["FrailtyRate"]);
  double Alpha = as<double>(Initial["Alpha"]), Precision = std::exp(as<double>(Initial["LogFrailtyPrecision"]));
  std::vector<double> Coefficients = {as<double>(Initial["BetaR"]), as<double>(Initial["GammaR"]),
    as<double>(Initial["BetaD"]), as<double>(Initial["GammaD"])};
  std::vector<double> R = as<std::vector<double>>(Initial["RecurrenceLogRate"]);
  std::vector<double> D = as<std::vector<double>>(Initial["DeathLogRate"]);
  std::vector<double> B = as<std::vector<double>>(Initial["FrailtyStandard"]);
  std::vector<double> A(N, -1), Z(N, -1), Exposure(N*K, 0), MeanR(N*K, 0), MeanD(N*K, 0);
  std::vector<double> NR(N, 0), ND(N, 0), RCount(K, 0), DCount(K, 0);
  for (double &Value : B) Value /= std::sqrt(Precision);
  for (int J = 0; J < Cells; ++J) {
    int I = Id[J] - 1, H = Bin[J] - 1, P = I*K + H;
    if (I < 0 || I >= N || H < 0 || H >= K || Exposure[P] != 0 ||
        (X(J, 0) != 0 && X(J, 0) != 1) || (X(J, 1) != 0 && X(J, 1) != 1)) stop("Invalid risk cells.");
    if (A[I] >= 0 && (A[I] != X(J, 0) || Z[I] != X(J, 1))) stop("Covariates vary within a participant.");
    Exposure[P] = std::exp(LogExposure[J]); A[I] = X(J, 0); Z[I] = X(J, 1);
    NR[I] += CountR[J]; ND[I] += CountD[J]; RCount[H] += CountR[J]; DCount[H] += CountD[J];
  }
  for (int I = 0; I < N; ++I) if (A[I] < 0 || ND[I] > 1) stop("Invalid participant history.");
  auto RefreshMeans = [&]() {
    for (int I = 0; I < N; ++I) for (int H = 0; H < K; ++H) {
      int P = I*K + H;
      MeanR[P] = Exposure[P]*std::exp(R[H] + Coefficients[0]*A[I] + Coefficients[1]*Z[I] + B[I]);
      MeanD[P] = Exposure[P]*std::exp(D[H] + Coefficients[2]*A[I] + Coefficients[3]*Z[I] + Alpha*B[I]);
      if (!std::isfinite(MeanR[P]) || !std::isfinite(MeanD[P])) stop("Nonfinite event intensity.");
    }
  };
  int Offset = 0;
  if (Continuation.isNotNull()) {
    if (Warmup != 0) stop("Continuation must not repeat initial warmup.");
    List State(Continuation);
    Coefficients = as<std::vector<double>>(State["Coefficients"]);
    R = as<std::vector<double>>(State["RecurrenceLogRate"]);
    D = as<std::vector<double>>(State["DeathLogRate"]);
    B = as<std::vector<double>>(State["Frailty"]);
    Alpha = as<double>(State["Alpha"]);
    Precision = as<double>(State["Precision"]);
    MeanR = as<std::vector<double>>(State["MeanR"]);
    MeanD = as<std::vector<double>>(State["MeanD"]);
    Offset = as<int>(State["Iterations"]);
    if (Coefficients.size() != 4 || R.size() != K || D.size() != K || B.size() != N ||
        MeanR.size() != N*K || MeanD.size() != N*K || Offset < 0 || !std::isfinite(Alpha) ||
        !std::isfinite(Precision) || Precision <= 0) stop("Invalid continuation state.");
  } else {
    RefreshMeans();
  }
  std::vector<double> ContinueR, ContinueD;
  int Variables = 8 + 2*K + 2*Times + N + 7;
  NumericMatrix Draws(Sampling, Variables);
  CharacterVector Names(Variables); int Pos = 0;
  for (const auto &Name : {"BetaR", "GammaR", "BetaD", "GammaD", "Alpha", "LogFrailtyPrecision", "FrailtyVariance", "FrailtyPrecision"}) Names[Pos++] = Name;
  for (const auto &Name : {"RecurrenceLogRate", "DeathLogRate"}) for (int H = 0; H < K; ++H) Names[Pos++] = std::string(Name) + "[" + std::to_string(H + 1) + "]";
  for (const auto &Name : {"RecurrenceCumulative", "DeathCumulative"}) for (int H = 0; H < Times; ++H) Names[Pos++] = std::string(Name) + "[" + std::to_string(H + 1) + "]";
  for (int I = 0; I < N; ++I) Names[Pos++] = "B[" + std::to_string(I + 1) + "]";
  for (int J = 0; J < 5; ++J) Names[Pos++] = "Scores[" + std::to_string(J + 1) + "]";
  Names[Pos++] = "ExpectedTotals[1]"; Names[Pos++] = "ExpectedTotals[2]";
  colnames(Draws) = Names;
  double Evaluations = 0, LargestCacheDifference = 0;
  int Total = Warmup + Sampling;
  for (int Iteration = 0; Iteration < Total; ++Iteration) {
    if (Iteration%100 == 0) checkUserInterrupt();
    for (int Process = 0; Process < 2; ++Process) {
      auto &Means = Process == 0 ? MeanR : MeanD;
      auto &Rates = Process == 0 ? R : D;
      auto &Counts = Process == 0 ? RCount : DCount;
      for (int H = 0; H < K; ++H) {
        double Sum = 0; for (int I = 0; I < N; ++I) Sum += Means[I*K + H];
        Conditional F{Counts[H] - BasePrecision*(Rates[H] - BaseMean), BasePrecision, {Sum}, {1}};
        double Delta = DrawConditional(F, Evaluations); Rates[H] += Delta;
        double Multiplier = std::exp(Delta);
        for (int I = 0; I < N; ++I) Means[I*K + H] *= Multiplier;
      }
      for (int Covariate = 0; Covariate < 2; ++Covariate) {
        auto &Cov = Covariate == 0 ? A : Z;
        auto &CountsById = Process == 0 ? NR : ND;
        double Count = 0, Mean = 0; int J = 2*Process + Covariate;
        for (int I = 0; I < N; ++I) if (Cov[I] == 1) {
          Count += CountsById[I]; for (int H = 0; H < K; ++H) Mean += Means[I*K + H];
        }
        Conditional F{Count - FixedPrecision*Coefficients[J], FixedPrecision, {Mean}, {1}};
        double Delta = DrawConditional(F, Evaluations); Coefficients[J] += Delta;
        double Multiplier = std::exp(Delta);
        for (int I = 0; I < N; ++I) if (Cov[I] == 1) for (int H = 0; H < K; ++H) Means[I*K + H] *= Multiplier;
      }
    }
    Conditional FAlpha{-AlphaPrecision*Alpha, AlphaPrecision, std::vector<double>(N, 0), B};
    for (int I = 0; I < N; ++I) {
      FAlpha.Linear += ND[I]*B[I];
      for (int H = 0; H < K; ++H) FAlpha.Means[I] += MeanD[I*K + H];
    }
    double DeltaAlpha = DrawConditional(FAlpha, Evaluations); Alpha += DeltaAlpha;
    for (int I = 0; I < N; ++I) for (int H = 0; H < K; ++H) MeanD[I*K + H] *= std::exp(DeltaAlpha*B[I]);
    for (int I = 0; I < N; ++I) {
      double SumR = 0, SumD = 0;
      for (int H = 0; H < K; ++H) { SumR += MeanR[I*K + H]; SumD += MeanD[I*K + H]; }
      Conditional F{NR[I] + Alpha*ND[I] - Precision*B[I], Precision, {SumR, SumD}, {1, Alpha}};
      double Delta = DrawConditional(F, Evaluations); B[I] += Delta;
      double MR = std::exp(Delta), MD = std::exp(Alpha*Delta);
      for (int H = 0; H < K; ++H) { MeanR[I*K + H] *= MR; MeanD[I*K + H] *= MD; }
    }
    if (BlockMoves) {
      // Exact Gaussian moves along directions that leave both likelihoods
      // unchanged. These are conditional updates in a linear coordinate system.
      for (int Direction = 0; Direction < 3; ++Direction) {
        double P = 0, L = 0;
        for (int I = 0; I < N; ++I) {
          double Cov = Direction == 0 ? 1 : (Direction == 1 ? A[I] : Z[I]);
          P += Precision*Cov*Cov; L -= Precision*Cov*B[I];
        }
        if (Direction == 0) {
          P += K*BasePrecision*(1 + Alpha*Alpha);
          for (int H = 0; H < K; ++H) L += BasePrecision*((R[H] - BaseMean) + Alpha*(D[H] - BaseMean));
        } else {
          P += FixedPrecision*(1 + Alpha*Alpha);
          L += FixedPrecision*(Coefficients[Direction - 1] + Alpha*Coefficients[Direction + 1]);
        }
        double Shift = R::rnorm(L/P, 1/std::sqrt(P));
        for (int I = 0; I < N; ++I) B[I] += Shift*(Direction == 0 ? 1 : (Direction == 1 ? A[I] : Z[I]));
        if (Direction == 0) for (int H = 0; H < K; ++H) { R[H] -= Shift; D[H] -= Alpha*Shift; }
        else { Coefficients[Direction - 1] -= Shift; Coefficients[Direction + 1] -= Alpha*Shift; }
      }
    }
    double SumSquares = 0; for (double Value : B) SumSquares += Value*Value;
    Precision = R::rgamma(Shape + 0.5*N, 1/(Rate + 0.5*SumSquares));
    if (!std::isfinite(Precision) || Precision <= 0) stop("Invalid sampled frailty precision.");
    if (Iteration == Total - 1) {
      ContinueR = MeanR;
      ContinueD = MeanD;
    }
    if ((Offset + Iteration)%100 == 0 || Iteration == Total - 1) {
      std::vector<double> OldR = MeanR, OldD = MeanD;
      RefreshMeans();
      for (int P = 0; P < N*K; ++P) {
        LargestCacheDifference = std::max(LargestCacheDifference, std::abs(OldR[P] - MeanR[P])/(1 + MeanR[P]));
        LargestCacheDifference = std::max(LargestCacheDifference, std::abs(OldD[P] - MeanD[P])/(1 + MeanD[P]));
      }
      if (LargestCacheDifference > 1e-8) stop("Cached intensities disagree with direct reconstruction.");
    }
    if (Iteration == Total - 1 && (Offset + Iteration)%100 == 0) {
      ContinueR = MeanR;
      ContinueD = MeanD;
    }
    if (Iteration >= Warmup) {
      int Row = Iteration - Warmup; Pos = 0;
      for (double Value : Coefficients) Draws(Row, Pos++) = Value;
      Draws(Row, Pos++) = Alpha; Draws(Row, Pos++) = std::log(Precision);
      Draws(Row, Pos++) = 1/Precision; Draws(Row, Pos++) = Precision;
      for (double Value : R) Draws(Row, Pos++) = Value;
      for (double Value : D) Draws(Row, Pos++) = Value;
      for (int Process = 0; Process < 2; ++Process) for (int T = 0; T < Times; ++T) {
        double Sum = 0; for (int H = 0; H < K; ++H) Sum += BaseExposure(T, H)*std::exp(Process == 0 ? R[H] : D[H]);
        Draws(Row, Pos++) = Sum;
      }
      for (double Value : B) Draws(Row, Pos++) = Value;
      double Scores[5] = {0, 0, 0, 0, 0}, Totals[2] = {0, 0};
      for (int I = 0; I < N; ++I) {
        double SR = 0, SD = 0;
        for (int H = 0; H < K; ++H) { SR += MeanR[I*K + H]; SD += MeanD[I*K + H]; }
        Scores[0] += A[I]*(NR[I] - SR); Scores[1] += Z[I]*(NR[I] - SR);
        Scores[2] += A[I]*(ND[I] - SD); Scores[3] += Z[I]*(ND[I] - SD);
        Scores[4] += B[I]*(ND[I] - SD);
        Totals[0] += SR; Totals[1] += SD;
      }
      for (int J = 0; J < 4; ++J) Draws(Row, Pos++) = Scores[J] - FixedPrecision*Coefficients[J];
      Draws(Row, Pos++) = Scores[4] - AlphaPrecision*Alpha;
      for (double Value : Totals) Draws(Row, Pos++) = Value;
    }
  }
  return List::create(_["Draws"] = Draws, _["ConditionalEvaluations"] = Evaluations,
    _["MaximumCacheDifference"] = LargestCacheDifference,
    _["State"] = List::create(_["Coefficients"] = Coefficients,
      _["RecurrenceLogRate"] = R, _["DeathLogRate"] = D, _["Frailty"] = B,
      _["Alpha"] = Alpha, _["Precision"] = Precision,
      _["MeanR"] = ContinueR, _["MeanD"] = ContinueD, _["Iterations"] = Offset + Total));
}
)"

CompileCustomSampler <- function(Directory, Rebuild = FALSE) {
  dir.create(Directory, recursive = TRUE, showWarnings = FALSE)
  # sourceCpp can update its cache even when loading an existing library.
  # Serialize cache access while the parallel workers start.
  Lock <- filelock::lock(file.path(Directory, "Compilation.lock"), timeout = Inf)
  if (is.null(Lock)) stop("Cannot lock the sampler compilation cache.")
  on.exit(filelock::unlock(Lock), add = TRUE)
  Path <- file.path(Directory, "CustomSampler.cpp")
  Text <- paste0(sub("[\r\n]+$", "", paste(CustomSamplerCode, CompletionCode, sep = "\n")), "\n")
  Existing <- if (file.exists(Path)) readChar(Path, file.info(Path)$size, useBytes = TRUE) else ""
  if (!identical(Existing, Text)) {
    Connection <- file(Path, "wb")
    tryCatch(writeChar(Text, Connection, eos = NULL, useBytes = TRUE), finally = close(Connection))
  }
  Rcpp::sourceCpp(Path, cacheDir = file.path(Directory, "Cache"), rebuild = Rebuild,
    showOutput = Rebuild, verbose = FALSE, env = .GlobalEnv)
  invisible(Path)
}

AuditCustomKernels <- function(D, Initial) {
  C <- CustomComponents(Initial, D)
  Precision <- exp(Initial$LogFrailtyPrecision)
  Rows <- list()
  Add <- function(Name, Linear, PriorPrecision, Means, Slopes, Change) {
    Shifts <- c(-0.4, 0.2, 0.7)
    Actual <- EvaluateConditionalCpp(Shifts, Linear, PriorPrecision, Means, Slopes)[, 1]
    Expected <- vapply(Shifts, function(Shift) CustomDensityR(Change(Shift), D) - CustomDensityR(Initial, D), numeric(1))
    Rows[[length(Rows) + 1]] <<- data.frame(Check = Name, MaximumDifference = max(abs(Actual - Expected)))
  }
  for (J in 1:4) {
    Name <- c("BetaR", "GammaR", "BetaD", "GammaD")[J]
    Covariate <- if (J %in% c(1, 3)) 1 else 2
    Keep <- D$X[, Covariate] == 1
    Counts <- if (J <= 2) D$CountR else D$CountD
    Means <- if (J <= 2) exp(C$EtaR) else exp(C$EtaD)
    Add(Name, sum(Counts[Keep]) - Initial[[Name]]/D$FixedSd^2, 1/D$FixedSd^2,
      sum(Means[Keep]), 1, function(Shift) { P <- Initial; P[[Name]] <- P[[Name]] + Shift; P })
  }
  for (Process in c("RecurrenceLogRate", "DeathLogRate")) {
    Counts <- if (Process == "RecurrenceLogRate") D$CountR else D$CountD
    Means <- if (Process == "RecurrenceLogRate") exp(C$EtaR) else exp(C$EtaD)
    for (K in seq_len(D$Intervals)) {
      Keep <- D$Bin == K
      Add(paste0(Process, K), sum(Counts[Keep]) - (Initial[[Process]][K] - D$BaselineLogMean)/D$BaselineLogSd^2,
        1/D$BaselineLogSd^2, sum(Means[Keep]), 1,
        function(Shift) { P <- Initial; P[[Process]][K] <- P[[Process]][K] + Shift; P })
    }
  }
  Add("Alpha", sum(D$CountD*C$B[D$Id]) - Initial$Alpha/D$AlphaSd^2, 1/D$AlphaSd^2,
    exp(C$EtaD), C$B[D$Id], function(Shift) { P <- Initial; P$Alpha <- P$Alpha + Shift; P })
  for (I in unique(c(1, D$Participants))) {
    Keep <- D$Id == I
    Add(paste0("Frailty", I), sum(D$CountR[Keep]) + Initial$Alpha*sum(D$CountD[Keep]) - Precision*C$B[I],
      Precision, c(sum(exp(C$EtaR[Keep])), sum(exp(C$EtaD[Keep]))), c(1, Initial$Alpha),
      function(Shift) { P <- Initial; P$FrailtyStandard[I] <- P$FrailtyStandard[I] + Shift*sqrt(Precision); P })
  }
  GammaShape <- D$FrailtyShape + D$Participants/2
  GammaRate <- D$FrailtyRate + sum(C$B^2)/2
  Differences <- vapply(c(-0.4, 0.2, 0.7), function(Shift) {
    P <- Initial
    P$LogFrailtyPrecision <- P$LogFrailtyPrecision + Shift
    P$FrailtyStandard <- C$B*exp(P$LogFrailtyPrecision/2)
    Actual <- CustomDensityR(P, D) - CustomDensityR(Initial, D) + (D$Participants/2 - 1)*Shift
    Expected <- dgamma(exp(P$LogFrailtyPrecision), GammaShape, rate = GammaRate, log = TRUE) -
      dgamma(Precision, GammaShape, rate = GammaRate, log = TRUE)
    Actual - Expected
  }, numeric(1))
  Rows[[length(Rows) + 1]] <- data.frame(Check = "Gamma precision conditional", MaximumDifference = max(abs(Differences)))
  PatientRows <- match(seq_len(D$Participants), D$Id)
  for (Direction in 0:2) {
    Cov <- if (Direction == 0) rep(1, D$Participants) else D$X[PatientRows, Direction]
    PP <- Precision*sum(Cov^2)
    LL <- -Precision*sum(Cov*C$B)
    if (Direction == 0) {
      PP <- PP + D$Intervals*(1 + Initial$Alpha^2)/D$BaselineLogSd^2
      LL <- LL + sum(C$R - D$BaselineLogMean + Initial$Alpha*(C$D - D$BaselineLogMean))/D$BaselineLogSd^2
    } else {
      PP <- PP + (1 + Initial$Alpha^2)/D$FixedSd^2
      LL <- LL + (C$Coefficients[Direction] + Initial$Alpha*C$Coefficients[Direction + 2])/D$FixedSd^2
    }
    Differences <- vapply(c(-0.4, 0.2, 0.7), function(Shift) {
      P <- Initial
      P$FrailtyStandard <- (C$B + Shift*Cov)*sqrt(Precision)
      if (Direction == 0) {
        P$RecurrenceLogRate <- C$R - Shift
        P$DeathLogRate <- C$D - Initial$Alpha*Shift
      } else {
        NR <- c("BetaR", "GammaR")[Direction]; ND <- c("BetaD", "GammaD")[Direction]
        P[[NR]] <- P[[NR]] - Shift; P[[ND]] <- P[[ND]] - Initial$Alpha*Shift
      }
      CustomDensityR(P, D) - CustomDensityR(Initial, D) - (LL*Shift - PP*Shift^2/2)
    }, numeric(1))
    Rows[[length(Rows) + 1]] <- data.frame(Check = paste("Gaussian direction", Direction), MaximumDifference = max(abs(Differences)))
  }
  Out <- do.call(rbind, Rows)
  if (any(!is.finite(Out$MaximumDifference)) || any(Out$MaximumDifference > 1e-7)) stop("A custom conditional differs from the joint density.")
  Out
}

ValidateCustomSettings <- function(Settings) {
  Expected <- names(CompletionSettings)
  if (!is.list(Settings) || !setequal(names(Settings), Expected)) stop("Simulation settings are missing or unknown.", call. = FALSE)
  for (Name in c("Replications", "Seed", "Chains", "Warmup", "Sampling", "MaximumWarmupBlocks", "MaximumSamplingBlocks")) {
    X <- Settings[[Name]]
    if (!is.numeric(X) || length(X) != 1 || !is.finite(X) || X != floor(X) || X < 1) stop(paste("Invalid setting:", Name), call. = FALSE)
  }
  if (Settings$Chains < 2 || Settings$Chains > 16) stop("Use between two and sixteen chains.", call. = FALSE)
  if (Settings$Warmup < 100 || Settings$Sampling < 100) stop("Use at least 100 warmup and retained draws per chain.", call. = FALSE)
  for (Name in c("FixedEffectSd", "AlphaSd", "BaselineLogSd", "FrailtyShape", "FrailtyRate", "MinimumEss")) {
    X <- Settings[[Name]]
    if (!is.numeric(X) || length(X) != 1 || !is.finite(X) || X <= 0) stop(paste("Invalid setting:", Name), call. = FALSE)
  }
  if (length(Settings$CoreFraction) != 1 || !is.finite(Settings$CoreFraction) ||
      Settings$CoreFraction <= 0 || Settings$CoreFraction > 1) stop("CoreFraction must be greater than zero and at most one.", call. = FALSE)
  X <- Settings$MaxConcurrentFits
  if (length(X) != 1 || is.na(X) || X < 1 || (!is.infinite(X) && X != floor(X))) stop("MaxConcurrentFits must be a positive integer or Inf.", call. = FALSE)
  if (length(Settings$BaselineLogMean) != 1 || !is.finite(Settings$BaselineLogMean) ||
      length(Settings$MaximumRhat) != 1 || !is.finite(Settings$MaximumRhat) || Settings$MaximumRhat <= 1) stop("Invalid baseline mean or Rhat limit.", call. = FALSE)
  if (Settings$Warmup + (Settings$MaximumWarmupBlocks + Settings$MaximumSamplingBlocks - 1)*Settings$Sampling >= .Machine$integer.max) {
    stop("The maximum iteration count is too large.", call. = FALSE)
  }
  for (Name in c("BlockMoves", "InstallMissingPackages")) {
    if (!is.logical(Settings[[Name]]) || length(Settings[[Name]]) != 1 || is.na(Settings[[Name]])) stop(paste("Invalid setting:", Name), call. = FALSE)
  }
  if (length(Settings$OutputFolder) != 1 || !is.character(Settings$OutputFolder) ||
      !grepl("^[A-Za-z][A-Za-z0-9]*$", Settings$OutputFolder)) stop("Use a simple output folder name.", call. = FALSE)
  invisible(Settings)
}

EnsureCustomPackages <- function(Settings) {
  Packages <- c("Rcpp", "posterior", "filelock")
  Missing <- Packages[!vapply(Packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(Missing) && Settings$InstallMissingPackages) {
    message("Installing: ", paste(Missing, collapse = ", "))
    utils::install.packages(Missing, repos = "https://cloud.r-project.org")
  }
  Missing <- Packages[!vapply(Packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(Missing)) stop(paste("Install these packages:", paste(Missing, collapse = ", ")), call. = FALSE)
  list(Versions = c(vapply(Packages, function(P) as.character(utils::packageVersion(P)), character(1)),
    R = as.character(getRversion()), Platform = R.version$platform))
}

GetCustomResources <- function(Settings, LogicalCores = parallel::detectCores(logical = TRUE)) {
  if (length(LogicalCores) != 1 || !is.finite(LogicalCores) || LogicalCores < 1) LogicalCores <- 1
  Budget <- max(1, floor(Settings$CoreFraction*LogicalCores))
  ParallelChains <- min(Settings$Chains, Budget)
  Workers <- min(Settings$MaxConcurrentFits, max(1, floor(Budget/ParallelChains)))
  list(LogicalCores = LogicalCores, CoreFraction = Settings$CoreFraction, Budget = Budget,
    Workers = Workers, ParallelChains = ParallelChains, ActiveCores = Workers*ParallelChains)
}

JitterCustomInitial <- function(P, Seed, Chain) {
  SetSimulationSeed(Seed)
  for (Name in c("BetaR", "GammaR", "BetaD", "GammaD")) P[[Name]] <- stats::rnorm(1, 0, 0.35)
  P$Alpha <- c(-0.5, 1.5)[1 + (Chain - 1)%%2] + stats::rnorm(1, 0, 0.2)
  P$LogFrailtyPrecision <- stats::runif(1, -0.7, 0.7)
  P$RecurrenceLogRate <- P$RecurrenceLogRate + stats::rnorm(length(P$RecurrenceLogRate), 0, 0.35)
  P$DeathLogRate <- P$DeathLogRate + stats::rnorm(length(P$DeathLogRate), 0, 0.35)
  P$FrailtyStandard <- stats::rnorm(length(P$FrailtyStandard), 0, 0.35)
  P
}

RunCustomChain <- function(Job) {
  if (is.null(Job$Continuation)) SetSimulationSeed(Job$Seed) else {
    assign(".Random.seed", Job$Continuation$RngState, envir = .GlobalEnv)
  }
  Start <- proc.time()[3]
  Warnings <- character()
  Answer <- tryCatch(withCallingHandlers({
    Result <- GibbsChainCpp(Job$Data, Job$Initial, Job$Warmup, Job$Sampling, Job$BlockMoves,
      if (is.null(Job$Continuation)) NULL else Job$Continuation$State)
    Result$RngState <- get(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
    Result$Succeeded <- TRUE
    Result
  }, warning = function(W) {
    Warnings <<- c(Warnings, conditionMessage(W))
    invokeRestart("muffleWarning")
  }), error = function(E) list(Succeeded = FALSE, Error = conditionMessage(E)))
  Answer$Chain <- Job$Chain
  Answer$Seed <- Job$Seed
  Answer$Seconds <- unname(proc.time()[3] - Start)
  Answer$Warnings <- unique(Warnings)
  Answer$WorkerPid <- Sys.getpid()
  Answer
}

InitializeCustomWorker <- function(ProgramPath, CompiledDirectory, ParallelChains) {
  Sys.setenv(OMP_NUM_THREADS = "1", OPENBLAS_NUM_THREADS = "1", MKL_NUM_THREADS = "1", VECLIB_MAXIMUM_THREADS = "1")
  source(ProgramPath, local = .GlobalEnv)
  State <- new.env(parent = emptyenv())
  State$Cluster <- NULL
  State$ParallelChains <- ParallelChains
  assign("CustomWorkerState", State, envir = .GlobalEnv)
  CompileCustomSampler(CompiledDirectory)
  if (ParallelChains > 1) {
    Cluster <- parallel::makePSOCKcluster(ParallelChains)
    Ready <- FALSE
    on.exit(if (!Ready) parallel::stopCluster(Cluster), add = TRUE)
    parallel::clusterCall(Cluster, function(Path, Directory) {
      Sys.setenv(OMP_NUM_THREADS = "1", OPENBLAS_NUM_THREADS = "1", MKL_NUM_THREADS = "1", VECLIB_MAXIMUM_THREADS = "1")
      source(Path, local = .GlobalEnv)
      CompileCustomSampler(Directory)
      NULL
    }, ProgramPath, CompiledDirectory)
    State$Cluster <- Cluster
    Ready <- TRUE
  } else {
    CompileCustomSampler(CompiledDirectory)
  }
  invisible(NULL)
}

StopCustomWorker <- function() {
  if (exists("CustomWorkerState", envir = .GlobalEnv, inherits = FALSE)) {
    State <- get("CustomWorkerState", envir = .GlobalEnv)
    if (!is.null(State$Cluster)) try(parallel::stopCluster(State$Cluster), silent = TRUE)
    rm("CustomWorkerState", envir = .GlobalEnv)
  }
  invisible(NULL)
}

AuditReturnedStates <- function(Draws, D) {
  Largest <- 0
  for (Chain in seq_len(dim(Draws)[2])) for (Iteration in unique(c(1, dim(Draws)[1]))) {
    X <- Draws[Iteration, Chain, ]
    P <- as.list(X[c("BetaR", "GammaR", "BetaD", "GammaD", "Alpha", "LogFrailtyPrecision")])
    P$RecurrenceLogRate <- X[paste0("RecurrenceLogRate[", seq_len(D$Intervals), "]")]
    P$DeathLogRate <- X[paste0("DeathLogRate[", seq_len(D$Intervals), "]")]
    B <- X[paste0("B[", seq_len(D$Participants), "]")]
    P$FrailtyStandard <- B*exp(P$LogFrailtyPrecision/2)
    C <- CustomComponents(P, D)
    ResidualR <- D$CountR - exp(C$EtaR)
    ResidualD <- D$CountD - exp(C$EtaD)
    Scores <- c(as.vector(crossprod(D$X, ResidualR)) - C$Coefficients[1:2]/D$FixedSd^2,
      as.vector(crossprod(D$X, ResidualD)) - C$Coefficients[3:4]/D$FixedSd^2,
      sum(B[D$Id]*ResidualD) - P$Alpha/D$AlphaSd^2)
    Expected <- c(exp(-P$LogFrailtyPrecision), exp(P$LogFrailtyPrecision),
      as.vector(D$BaselineExposure %*% exp(P$RecurrenceLogRate)),
      as.vector(D$BaselineExposure %*% exp(P$DeathLogRate)), Scores,
      sum(exp(C$EtaR)), sum(exp(C$EtaD)))
    Names <- c("FrailtyVariance", "FrailtyPrecision", paste0("RecurrenceCumulative[", seq_len(D$Times), "]"),
      paste0("DeathCumulative[", seq_len(D$Times), "]"), paste0("Scores[", 1:5, "]"), paste0("ExpectedTotals[", 1:2, "]"))
    Difference <- max(abs(X[Names] - Expected)/(1 + abs(Expected)))
    if (!is.finite(Difference) || Difference > 1e-8) stop("Returned sampler summaries disagree with reconstruction.")
    Largest <- max(Largest, Difference)
  }
  Largest
}

GetCustomDiagnostics <- function(Draws, Settings) {
  if (length(dim(Draws)) != 3 || dim(Draws)[2] != Settings$Chains ||
      any(!is.finite(Draws))) stop("MCMC draws are incomplete or nonfinite.")
  Variables <- do.call(rbind, lapply(dimnames(Draws)[[3]], function(Name) {
    X <- Draws[, , Name]
    data.frame(Variable = Name, Rhat = posterior::rhat(X),
      BulkEss = posterior::ess_bulk(X), TailEss = posterior::ess_tail(X))
  }))
  Variables$Review <- !is.finite(Variables$Rhat) | Variables$Rhat > Settings$MaximumRhat |
    !is.finite(Variables$BulkEss) | Variables$BulkEss < Settings$MinimumEss |
    !is.finite(Variables$TailEss) | Variables$TailEss < Settings$MinimumEss
  Variables
}

GetCustomDiagnosticStatus <- function(Variables, Settings) {
  RhatPassed <- nrow(Variables) > 0 && all(is.finite(Variables$Rhat) & Variables$Rhat <= Settings$MaximumRhat)
  EssPassed <- nrow(Variables) > 0 && all(is.finite(Variables$BulkEss) & Variables$BulkEss >= Settings$MinimumEss &
    is.finite(Variables$TailEss) & Variables$TailEss >= Settings$MinimumEss)
  list(RhatPassed = RhatPassed, EssPassed = EssPassed)
}

GetCustomBlockRecord <- function(Variables, Settings, Block, Stage, StageBlock, DrawsAssessed) {
  Status <- GetCustomDiagnosticStatus(Variables, Settings)
  FiniteMax <- function(X) if (any(is.finite(X))) max(X[is.finite(X)]) else NA_real_
  FiniteMin <- function(X) if (any(is.finite(X))) min(X[is.finite(X)]) else NA_real_
  data.frame(Block = Block, Stage = Stage, StageBlock = StageBlock,
    AddedPerChain = Settings$Sampling, AssessedPerChain = DrawsAssessed,
    MaximumRhat = FiniteMax(Variables$Rhat), MinimumBulkEss = FiniteMin(Variables$BulkEss),
    MinimumTailEss = FiniteMin(Variables$TailEss), RhatPassed = Status$RhatPassed,
    EssPassed = Status$EssPassed, Unavailable = sum(!is.finite(Variables$Rhat) |
      !is.finite(Variables$BulkEss) | !is.finite(Variables$TailEss)), UsedInSummary = FALSE)
}

CollectCustomDraws <- function(Runs, Settings) {
  Failed <- !vapply(Runs, function(X) isTRUE(X$Succeeded), logical(1))
  if (any(Failed)) stop(paste("Chain", Runs[[which(Failed)[1]]]$Chain, "failed:", Runs[[which(Failed)[1]]]$Error))
  if (length(Runs) != Settings$Chains) stop("Some chains are missing.")
  Names <- colnames(Runs[[1]]$Draws)
  Draws <- array(NA_real_, c(Settings$Sampling, Settings$Chains, length(Names)),
    dimnames = list(NULL, NULL, Names))
  for (J in seq_len(Settings$Chains)) {
    if (nrow(Runs[[J]]$Draws) != Settings$Sampling || !identical(colnames(Runs[[J]]$Draws), Names)) {
      stop("A chain returned incomplete draws.")
    }
    Draws[, J, ] <- Runs[[J]]$Draws
  }
  if (any(!is.finite(Draws))) stop("A chain returned nonfinite draws.")
  Draws
}

AppendCustomDraws <- function(Previous, Additional) {
  N <- dim(Previous)[1]
  Added <- dim(Additional)[1]
  if (!identical(dim(Previous)[2:3], dim(Additional)[2:3]) ||
      !identical(dimnames(Previous)[[3]], dimnames(Additional)[[3]])) stop("Continuation variables differ.")
  Out <- array(NA_real_, c(N + Added, dim(Previous)[2:3]),
    dimnames = list(NULL, NULL, dimnames(Previous)[[3]]))
  Out[seq_len(N), , ] <- Previous
  Out[N + seq_len(Added), , ] <- Additional
  Out
}

RunCustomAutoFit <- function(Jobs, Settings) {
  State <- get("CustomWorkerState", envir = .GlobalEnv)
  History <- list()
  Totals <- lapply(Jobs, function(Job) list(Chain = Job$Chain, Seed = Job$Seed,
    Seconds = 0, ConditionalEvaluations = 0, MaximumCacheDifference = 0,
    WorkerPid = NA_real_))
  SamplingSeconds <- 0
  DiagnosticSeconds <- 0
  ExtractionSeconds <- 0
  Block <- 0
  Retained <- NULL
  FinalVariables <- NULL
  WarmupEstablished <- FALSE
  WarmupBlocks <- 0
  SamplingBlocks <- 0
  NextBlock <- function() {
    Start <- proc.time()[3]
    Runs <- if (is.null(State$Cluster)) lapply(Jobs, RunCustomChain) else parallel::parLapply(State$Cluster, Jobs, RunCustomChain)
    SamplingSeconds <<- SamplingSeconds + unname(proc.time()[3] - Start)
    for (Run in Runs) for (Message in Run$Warnings) warning(Message, call. = FALSE)
    Start <- proc.time()[3]
    Draws <- CollectCustomDraws(Runs, Settings)
    for (J in seq_along(Jobs)) {
      Jobs[[J]]$Continuation <<- list(State = Runs[[J]]$State, RngState = Runs[[J]]$RngState)
      Jobs[[J]]$Warmup <<- 0
      Totals[[J]]$Seconds <<- Totals[[J]]$Seconds + Runs[[J]]$Seconds
      Totals[[J]]$ConditionalEvaluations <<- Totals[[J]]$ConditionalEvaluations + Runs[[J]]$ConditionalEvaluations
      Totals[[J]]$MaximumCacheDifference <<- max(Totals[[J]]$MaximumCacheDifference, Runs[[J]]$MaximumCacheDifference)
      Totals[[J]]$WorkerPid <<- Runs[[J]]$WorkerPid
      Totals[[J]]$TotalIterations <<- Runs[[J]]$State$Iterations
    }
    Block <<- Block + 1
    ExtractionSeconds <<- ExtractionSeconds + unname(proc.time()[3] - Start)
    Draws
  }
  Diagnose <- function(Draws) {
    Start <- proc.time()[3]
    Out <- GetCustomDiagnostics(Draws, Settings)
    DiagnosticSeconds <<- DiagnosticSeconds + unname(proc.time()[3] - Start)
    Out
  }
  for (Attempt in seq_len(Settings$MaximumWarmupBlocks)) {
    Latest <- NextBlock()
    Variables <- Diagnose(Latest)
    History[[Block]] <- GetCustomBlockRecord(Variables, Settings, Block,
      "WarmupAssessment", Attempt, dim(Latest)[1])
    WarmupBlocks <- Attempt
    Status <- GetCustomDiagnosticStatus(Variables, Settings)
    if (Status$RhatPassed) {
      WarmupEstablished <- TRUE
      Retained <- Latest
      FinalVariables <- Variables
      SamplingBlocks <- 1
      break
    }
    # Provisional blocks are replaced only before a warmup boundary is established.
    Retained <- Latest
    FinalVariables <- Variables
  }
  FirstRetainedBlock <- Block
  if (WarmupEstablished) {
    Status <- GetCustomDiagnosticStatus(FinalVariables, Settings)
    while (!(Status$RhatPassed && Status$EssPassed) && SamplingBlocks < Settings$MaximumSamplingBlocks) {
      Additional <- NextBlock()
      Start <- proc.time()[3]
      Retained <- AppendCustomDraws(Retained, Additional)
      ExtractionSeconds <- ExtractionSeconds + unname(proc.time()[3] - Start)
      SamplingBlocks <- SamplingBlocks + 1
      FinalVariables <- Diagnose(Retained)
      History[[Block]] <- GetCustomBlockRecord(FinalVariables, Settings, Block,
        "RetainedSampling", SamplingBlocks, dim(Retained)[1])
      Status <- GetCustomDiagnosticStatus(FinalVariables, Settings)
    }
  } else {
    SamplingBlocks <- 1
  }
  Status <- GetCustomDiagnosticStatus(FinalVariables, Settings)
  StopReason <- if (!WarmupEstablished) "WarmupLimit" else if (Status$RhatPassed && Status$EssPassed) "CriteriaMet" else "SamplingLimit"
  History <- do.call(rbind, History)
  History$UsedInSummary <- History$Block >= FirstRetainedBlock
  SummaryWarmup <- Settings$Warmup + (FirstRetainedBlock - 1)*Settings$Sampling
  for (J in seq_along(Totals)) {
    Totals[[J]]$Retained <- dim(Retained)[1]
    Totals[[J]]$WarmupIterations <- SummaryWarmup
    Totals[[J]]$Blocks <- Block
  }
  list(Draws = Retained, Runs = Totals, VariableDiagnostics = FinalVariables,
    BlockDiagnostics = History, WarmupEstablished = WarmupEstablished,
    WarmupBlocks = WarmupBlocks, SamplingBlocks = SamplingBlocks,
    WarmupIterations = SummaryWarmup, DrawsPerChain = dim(Retained)[1],
    TotalBlocks = Block, StopReason = StopReason, RhatPassed = Status$RhatPassed,
    EssPassed = Status$EssPassed, SamplingSeconds = SamplingSeconds,
    ExtractionSeconds = ExtractionSeconds, DiagnosticSeconds = DiagnosticSeconds)
}

CheckMiScenarios <- function(Scenarios) {
  if (!is.data.frame(Scenarios) || nrow(Scenarios) < 1 ||
      !all(c("Scenario", "RecurrenceBorrowing") %in% names(Scenarios))) stop("Invalid sensitivity scenarios.")
  if (!"DeathBorrowing" %in% names(Scenarios)) stop("Specify both borrowing weights.")
  if (anyNA(Scenarios) || anyDuplicated(Scenarios$Scenario) ||
      any(!grepl("^[A-Za-z][A-Za-z0-9]*$", Scenarios$Scenario))) stop("Invalid scenario names.")
  for (Name in c("RecurrenceBorrowing", "DeathBorrowing")) {
    X <- Scenarios[[Name]]
    if (!is.numeric(X) || any(!is.finite(X)) || any(X < 0 | X > 1)) {
      stop("Borrowing weights must be between zero and one.")
    }
  }
  if (sum(Scenarios$Scenario == "MAR" & Scenarios$RecurrenceBorrowing == 0 &
          Scenarios$DeathBorrowing == 0) != 1) stop("Include MAR with both borrowing weights zero.")
  Scenarios
}

DrawTerminalFollowup <- function(Start, Horizon, Rate, Cutpoints, Uniform) {
  # Invert the conditional cumulative hazard starting at the censoring time.
  N <- length(Start)
  if (!is.matrix(Rate) || nrow(Rate) != N || ncol(Rate) != length(Cutpoints) - 1 ||
      any(!is.finite(Rate)) || any(Rate < 0) || length(Uniform) != N ||
      any(Uniform <= 0 | Uniform >= 1)) stop("Invalid terminal-event sampling inputs.")
  End <- rep(Horizon, N)
  Event <- rep(0, N)
  Remaining <- -log1p(-Uniform)
  for (K in seq_len(ncol(Rate))) {
    Left <- pmax(Start, Cutpoints[K])
    Width <- pmax(0, pmin(Horizon, Cutpoints[K + 1]) - Left)
    Increment <- Rate[, K]*Width
    Hit <- Event == 0 & Width > 0 & Rate[, K] > 0 & Remaining <= Increment
    End[Hit] <- Left[Hit] + Remaining[Hit]/Rate[Hit, K]
    Event[Hit] <- 1
    Alive <- Event == 0
    Remaining[Alive] <- Remaining[Alive] - Increment[Alive]
  }
  if (any(End < Start | End > Horizon)) stop("An imputed death is outside its risk window.")
  list(End = End, Death = Event)
}

GetFutureMoments <- function(Start, Horizon, RecurrenceRate, DeathRate, Cutpoints) {
  # Integrate recurrence intensity times conditional survival, interval by interval.
  Survival <- rep(1, length(Start))
  Count <- Life <- rep(0, length(Start))
  for (K in seq_len(ncol(DeathRate))) {
    Width <- pmax(0, pmin(Horizon, Cutpoints[K + 1]) - pmax(Start, Cutpoints[K]))
    D <- DeathRate[, K]
    AliveTime <- Width
    Positive <- D > 0
    AliveTime[Positive] <- -expm1(-D[Positive]*Width[Positive])/D[Positive]
    AliveTime <- Survival*AliveTime
    Count <- Count + RecurrenceRate[, K]*AliveTime
    Life <- Life + AliveTime
    Survival <- Survival*exp(-D*Width)
  }
  list(Count = Count, RemainingLife = Life, Death = 1 - Survival)
}

GetCompletedAnalyses <- function(Values, Expected, Target, Scenario, Outcome, Meta) {
  Active <- Target$Treatment == 1
  N1 <- sum(Active)
  N0 <- sum(!Active)
  Mean1 <- colMeans(Values[Active, , drop = FALSE])
  Mean0 <- colMeans(Values[!Active, , drop = FALSE])
  V1 <- colSums(sweep(Values[Active, , drop = FALSE], 2, Mean1)^2)/(N1*(N1 - 1))
  V0 <- colSums(sweep(Values[!Active, , drop = FALSE], 2, Mean0)^2)/(N0*(N0 - 1))
  data.frame(Scenario = Scenario, Outcome = Outcome, Imputation = Meta$Imputation, Chain = Meta$Chain, Iteration = Meta$Iteration,
             Estimate = Mean1 - Mean0, WithinVariance = V1 + V0,
             ActiveMean = Mean1, ControlMean = Mean0, ActiveVariance = V1, ControlVariance = V0,
             ActiveParticipants = N1, ControlParticipants = N0, NoMissing = !any(Target$NeedsImputation),
             ExpectedEstimate = colMeans(Expected[Active, , drop = FALSE]) - colMeans(Expected[!Active, , drop = FALSE]))
}

PoolMiScalar <- function(Data, ConfidenceLevel = 0.95) {
  M <- nrow(Data)
  Required <- c("Estimate", "WithinVariance", "ActiveVariance", "ControlVariance", "ExpectedEstimate")
  if (M < 2 || any(!is.finite(as.matrix(Data[, Required]))) ||
      any(Data$ActiveVariance < 0 | Data$ControlVariance < 0) ||
      any(abs(Data$WithinVariance - Data$ActiveVariance - Data$ControlVariance) > 1e-10) ||
      length(unique(Data$Scenario)) != 1 || length(unique(Data$Outcome)) != 1 ||
      anyDuplicated(Data$Imputation)) stop("Invalid completed-data analyses.")
  Q <- mean(Data$Estimate)
  U <- mean(Data$WithinVariance)
  B <- stats::var(Data$Estimate)
  T <- U + (1 + 1/M)*B
  V1 <- mean(Data$ActiveVariance)
  V0 <- mean(Data$ControlVariance)
  N1 <- Data$ActiveParticipants[1]
  N0 <- Data$ControlParticipants[1]
  CompleteDf <- if (U > 0) U^2/(V1^2/(N1 - 1) + V0^2/(N0 - 1)) else NA_real_
  Lambda <- if (T > 0) (1 + 1/M)*B/T else NA_real_
  OldDf <- if (is.finite(Lambda) && Lambda > 0) (M - 1)/Lambda^2 else Inf
  ObservedDf <- if (is.finite(CompleteDf) && is.finite(Lambda)) {
    CompleteDf*(CompleteDf + 1)/(CompleteDf + 3)*(1 - Lambda)
  } else NA_real_
  Df <- if (isTRUE(Data$NoMissing[1])) CompleteDf else 1/(1/OldDf + 1/ObservedDf)
  if (isTRUE(Data$NoMissing[1]) && B > 1e-20) stop("Complete outcomes have nonzero imputation variance.")
  Valid <- is.finite(T) && T > 0 && U > 0 && is.finite(Df) && Df > 0
  Se <- sqrt(T)
  Critical <- if (Valid) stats::qt((1 + ConfidenceLevel)/2, Df) else NA_real_
  Residual <- Data$Estimate - Data$ExpectedEstimate
  data.frame(Scenario = Data$Scenario[1], Outcome = Data$Outcome[1], Imputations = M,
             ActiveMean = mean(Data$ActiveMean), ControlMean = mean(Data$ControlMean), Estimate = Q,
             RubinSe = Se, Lower = Q - Critical*Se, Upper = Q + Critical*Se,
             WithinVariance = U, BetweenVariance = B, TotalVariance = T,
             CompleteDf = CompleteDf, OldDf = OldDf, ObservedDf = ObservedDf, Df = Df,
             Lambda = Lambda, PoolingValid = Valid,
             NumericalMcse = GetChainMcse(Data$Estimate, Data),
             NumericalVarianceFraction = if (T > 0) GetChainMcse(Data$Estimate, Data)^2/T else NA_real_,
             ExpectedEstimate = mean(Data$ExpectedEstimate), ExpectedMcse = GetChainMcse(Data$ExpectedEstimate, Data),
             PredictiveSamplingDifference = mean(Residual), PredictiveSamplingMcse = GetChainMcse(Residual, Data),
             ConfidenceLevel = ConfidenceLevel, NoMissing = Data$NoMissing[1], row.names = NULL)
}

PoolMiAnalyses <- function(Analyses, ConfidenceLevel) {
  Groups <- unique(Analyses[, c("Scenario", "Outcome")])
  do.call(rbind, lapply(seq_len(nrow(Groups)), function(I) {
    Keep <- Analyses$Scenario == Groups$Scenario[I] & Analyses$Outcome == Groups$Outcome[I]
    PoolMiScalar(Analyses[Keep, ], ConfidenceLevel)
  }))
}

GetChainMcse <- function(Values, Meta) {
  if (length(Values) != nrow(Meta) || any(!is.finite(Values))) return(NA_real_)
  if (length(unique(Values)) == 1) return(0)
  ChainSizes <- table(Meta$Chain)
  if (length(ChainSizes) < 2 || length(unique(ChainSizes)) != 1 || min(ChainSizes) < 4 ||
      anyDuplicated(Meta[, c("Chain", "Iteration")])) stop("Monte Carlo errors require equal lengths and unique iterations in each chain.")
  Ordered <- order(Meta$Chain, Meta$Iteration)
  X <- matrix(Values[Ordered], nrow = ChainSizes[1])
  as.numeric(posterior::mcse_mean(X))
}


CompletionCode <- r"(
// Completion follows the application formulas; uniforms are supplied by R.
// [[Rcpp::export]]
List CompleteTrialBatchCpp(NumericMatrix Draws, IntegerVector Treatment,
    IntegerVector Age, NumericVector ObservedCount, NumericVector Start,
    NumericVector KnownDeath, LogicalVector Need, NumericVector Cutpoints,
    NumericVector BorrowR, NumericVector BorrowD, NumericMatrix UniformDeath,
    NumericMatrix UniformCount) {
  const int N = Treatment.size(), M = Draws.nrow(), K = Cutpoints.size() - 1;
  const int S = BorrowR.size();
  const double Horizon = Cutpoints[K];
  if (K < 1 || Draws.ncol() != 5 + 2*K + N || BorrowD.size() != S ||
      ObservedCount.size() != N || Start.size() != N || KnownDeath.size() != N ||
      Need.size() != N || Age.size() != N || UniformDeath.ncol() != M ||
      UniformCount.ncol() != M) stop("Completion dimensions are inconsistent.");
  int Missing = 0, ArmSize[2] = {0, 0};
  std::vector<int> MissingIndex(N, -1);
  for (int I = 0; I < N; ++I) {
    if ((Treatment[I] != 0 && Treatment[I] != 1) ||
        (Age[I] != 0 && Age[I] != 1) || !(Start[I] > 0 && Start[I] <= Horizon) ||
        ObservedCount[I] < 0 || ObservedCount[I] != std::floor(ObservedCount[I]) ||
        (KnownDeath[I] != 0 && KnownDeath[I] != 1) ||
        (Need[I] && (KnownDeath[I] != 0 || Start[I] >= Horizon))) stop("Invalid completion target.");
    ++ArmSize[Treatment[I]];
    if (Need[I]) MissingIndex[I] = Missing++;
  }
  if (ArmSize[0] < 2 || ArmSize[1] < 2 || UniformDeath.nrow() != Missing ||
      UniformCount.nrow() != Missing) stop("Invalid arm sizes or uniform dimensions.");
  NumericMatrix Out(M*S*3, 8), Burden(S*2, 4);
  colnames(Out) = CharacterVector::create("Estimate", "WithinVariance", "ActiveMean",
    "ControlMean", "ActiveVariance", "ControlVariance", "ExpectedEstimate",
    "ConditionalCountEstimate");
  colnames(Burden) = CharacterVector::create("AddedCount", "AddedDeaths", "AddedLife", "CompletedCount");
  for (int J = 0; J < M; ++J) {
    if (J%128 == 0) checkUserInterrupt();
    for (int Rule = 0; Rule < S; ++Rule) {
      double Mean[2][3] = {}, M2[2][3] = {}, Expected[2][3] = {}, Conditional[2] = {};
      int Seen[2] = {0, 0};
      for (int I = 0; I < N; ++I) {
        const int Arm = Treatment[I];
        double Values[3] = {ObservedCount[I], KnownDeath[I], Start[I]};
        double Moments[3] = {ObservedCount[I], KnownDeath[I], Start[I]};
        double ConditionalCount = ObservedCount[I];
        if (Need[I]) {
          const double Ud = UniformDeath(MissingIndex[I], J), Ur = UniformCount(MissingIndex[I], J);
          if (!(Ud > 0 && Ud < 1 && Ur > 0 && Ur < 1)) stop("Invalid predictive uniform.");
          const double B = Draws(J, 5 + 2*K + I);
          const double EtaR = (1 - BorrowR[Rule])*Draws(J, 0)*Arm + Draws(J, 1)*Age[I] + B;
          const double EtaD = (1 - BorrowD[Rule])*Draws(J, 2)*Arm + Draws(J, 3)*Age[I] + Draws(J, 4)*B;
          std::vector<double> RateR(K), RateD(K);
          for (int Bin = 0; Bin < K; ++Bin) {
            RateR[Bin] = std::exp(Draws(J, 5 + Bin) + EtaR);
            RateD[Bin] = std::exp(Draws(J, 5 + K + Bin) + EtaD);
            if (!R_finite(RateR[Bin]) || !R_finite(RateD[Bin])) stop("A sampled future rate is nonfinite.");
          }
          double End = Horizon, Event = 0, Remaining = -std::log1p(-Ud);
          for (int Bin = 0; Bin < K; ++Bin) {
            const double Left = std::max(Start[I], Cutpoints[Bin]);
            const double Width = std::max(0.0, std::min(Horizon, Cutpoints[Bin + 1]) - Left);
            const double Increment = RateD[Bin]*Width;
            if (Event == 0 && Width > 0 && RateD[Bin] > 0 && Remaining <= Increment) {
              End = Left + Remaining/RateD[Bin]; Event = 1;
            }
            if (Event == 0) Remaining -= Increment;
          }
          double Intensity = 0, CountMean = 0, Life = 0, Survival = 1;
          for (int Bin = 0; Bin < K; ++Bin) {
            const double Left = std::max(Start[I], Cutpoints[Bin]);
            const double Width = std::max(0.0, std::min(Horizon, Cutpoints[Bin + 1]) - Left);
            const double Exposure = std::max(0.0, std::min(End, Cutpoints[Bin + 1]) - Left);
            Intensity += RateR[Bin]*Exposure;
            const double Integral = RateD[Bin] > 0 ? -std::expm1(-RateD[Bin]*Width)/RateD[Bin] : Width;
            CountMean += RateR[Bin]*Survival*Integral;
            Life += Survival*Integral;
            Survival *= std::exp(-RateD[Bin]*Width);
          }
          const double Count = R::qpois(Ur, Intensity, true, false);
          if (!R_finite(Count) || !R_finite(CountMean) || !R_finite(Intensity) || Count < 0 ||
              Count != std::floor(Count) || End < Start[I] || End > Horizon ||
              (End == Start[I] && Count != 0)) stop("A predictive outcome is invalid.");
          Values[0] += Count; Values[1] = Event; Values[2] = End;
          Moments[0] += CountMean; Moments[1] = 1 - Survival; Moments[2] += Life;
          ConditionalCount += Intensity;
        }
        ++Seen[Arm];
        for (int O = 0; O < 3; ++O) {
          const double Difference = Values[O] - Mean[Arm][O];
          Mean[Arm][O] += Difference/Seen[Arm];
          M2[Arm][O] += Difference*(Values[O] - Mean[Arm][O]);
          Expected[Arm][O] += Moments[O];
        }
        Conditional[Arm] += ConditionalCount;
        const int Row = 2*Rule + Arm;
        Burden(Row, 0) += Values[0] - ObservedCount[I];
        Burden(Row, 1) += Values[1] - KnownDeath[I];
        Burden(Row, 2) += Values[2] - Start[I];
        Burden(Row, 3) += Values[0];
      }
      for (int O = 0; O < 3; ++O) {
        const int Row = (3*Rule + O)*M + J;
        const double V1 = M2[1][O]/(ArmSize[1]*(ArmSize[1] - 1.0));
        const double V0 = M2[0][O]/(ArmSize[0]*(ArmSize[0] - 1.0));
        Out(Row, 0) = Mean[1][O] - Mean[0][O];
        Out(Row, 1) = V1 + V0; Out(Row, 2) = Mean[1][O]; Out(Row, 3) = Mean[0][O];
        Out(Row, 4) = V1; Out(Row, 5) = V0;
        Out(Row, 6) = Expected[1][O]/ArmSize[1] - Expected[0][O]/ArmSize[0];
        Out(Row, 7) = O == 0 ? Conditional[1]/ArmSize[1] - Conditional[0]/ArmSize[0] : NA_REAL;
      }
    }
  }
  return List::create(_["Analyses"] = Out, _["Burden"] = Burden);
}
)"


ValidateCompletionSettings <- function(Settings) {
  ValidateCustomSettings(Settings)
  for (Name in c("ImputationBatchSize", "TruthNodes", "TruthCheckNodes")) {
    X <- Settings[[Name]]
    if (length(X) != 1 || !is.finite(X) || X < 2 || X != floor(X)) stop(paste("Invalid setting:", Name))
  }
  if (Settings$TruthCheckNodes <= Settings$TruthNodes || Settings$TruthTolerance <= 0 ||
      !is.finite(Settings$TruthTolerance)) stop("Use a finer checking grid and a positive truth tolerance.")
  if (length(Settings$ConfidenceLevel) != 1 || !is.finite(Settings$ConfidenceLevel) ||
      Settings$ConfidenceLevel <= 0 || Settings$ConfidenceLevel >= 1) stop("Invalid confidence level.")
  if (!is.logical(Settings$RetryFailed) || length(Settings$RetryFailed) != 1 || is.na(Settings$RetryFailed)) stop("RetryFailed must be TRUE or FALSE.")
  invisible(Settings)
}

GetNormalQuadrature <- function(Nodes) {
  J <- matrix(0, Nodes, Nodes)
  At <- seq_len(Nodes - 1)
  J[cbind(At, At + 1)] <- sqrt(At)
  J[cbind(At + 1, At)] <- sqrt(At)
  E <- eigen(J, symmetric = TRUE)
  data.frame(Node = E$values, Weight = E$vectors[1, ]^2)
}

IntegratedExponential <- function(Rate, Width) {
  Out <- rep(Width, length(Rate))
  Positive <- Rate > 0
  Out[Positive] <- -expm1(-Rate[Positive]*Width)/Rate[Positive]
  Out
}

IntegrateStateOccupancy <- function(FirstRate, SecondRate, Width) {
  Difference <- FirstRate - SecondRate
  if (abs(Difference)*Width > 0.0001) {
    return((IntegratedExponential(SecondRate, Width) - IntegratedExponential(FirstRate, Width))/Difference)
  }
  # The equal-rate limit is evaluated without subtracting nearly equal terms.
  stats::integrate(function(Time) {
    Gap <- abs(Difference)
    A <- if (Gap == 0) Time else -expm1(-Gap*Time)/Gap
    exp(-min(FirstRate, SecondRate)*Time)*A
  }, 0, Width, rel.tol = 1e-11, abs.tol = 1e-12)$value
}

ConditionalPopulationMoments <- function(Scenario, Arm, Age, Frailty, Rule) {
  # Alive participants have two states: before potential censoring and after it.
  # Censoring moves between states; death removes participants from either state.
  Before <- 1
  After <- Count <- Life <- 0
  Censor <- Scenario$CensoringRate
  for (K in seq_along(Scenario$RecurrenceRates)) {
    Width <- diff(Scenario$Cutpoints)[K]
    R0 <- Scenario$RecurrenceRates[K]*exp(Scenario$BetaR*Arm + Scenario$GammaR*Age + Frailty)
    D0 <- Scenario$DeathRates[K]*exp(Scenario$BetaD*Arm + Scenario$GammaD*Age + Scenario$Alpha*Frailty)
    R1 <- R0*exp(-Rule$RecurrenceBorrowing*Scenario$BetaR*Arm)
    D1 <- D0*exp(-Rule$DeathBorrowing*Scenario$BetaD*Arm)
    X <- D0 + Censor
    BeforeTime <- Before*IntegratedExponential(X, Width)
    AfterTime <- After*IntegratedExponential(D1, Width) +
      Censor*Before*IntegrateStateOccupancy(X, D1, Width)
    Count <- Count + R0*BeforeTime + R1*AfterTime
    Life <- Life + BeforeTime + AfterTime
    Transfer <- exp(-min(X, D1)*Width)*IntegratedExponential(abs(X - D1), Width)
    After <- After*exp(-D1*Width) + Censor*Before*Transfer
    Before <- Before*exp(-X*Width)
  }
  c(RecurrentCount = Count, DeathRisk = 1 - Before - After, RestrictedMeanSurvival = Life)
}

ComputePopulationTruth <- function(Scenario, Rules, Nodes) {
  Grid <- GetNormalQuadrature(Nodes)
  Grid$Node <- Grid$Node*sqrt(Scenario$FrailtyVariance)
  Rows <- list()
  for (S in seq_len(nrow(Rules))) {
    Means <- matrix(0, 3, 2, dimnames = list(c("RecurrentCount", "DeathRisk", "RestrictedMeanSurvival"), c("Control", "Active")))
    for (Arm in 0:1) for (Age in 0:1) {
      Probability <- if (Age == 1) Scenario$AgeProbability else 1 - Scenario$AgeProbability
      for (G in seq_len(nrow(Grid))) {
        Means[, Arm + 1] <- Means[, Arm + 1] + Probability*Grid$Weight[G]*
          ConditionalPopulationMoments(Scenario, Arm, Age, Grid$Node[G], Rules[S, ])
      }
    }
    Rows[[S]] <- data.frame(Rule = Rules$Scenario[S], Outcome = rownames(Means),
      ControlMean = Means[, 1], ActiveMean = Means[, 2], Truth = Means[, 2] - Means[, 1], row.names = NULL)
  }
  do.call(rbind, Rows)
}

GetVerifiedPopulationTruth <- function(Scenario, Rules, Settings) {
  A <- ComputePopulationTruth(Scenario, Rules, Settings$TruthNodes)
  B <- ComputePopulationTruth(Scenario, Rules, Settings$TruthCheckNodes)
  Fields <- c("ControlMean", "ActiveMean", "Truth")
  B$MaximumRefinementDifference <- apply(abs(as.matrix(A[, Fields]) - as.matrix(B[, Fields])), 1, max)
  if (any(!is.finite(as.matrix(B[, c(Fields, "MaximumRefinementDifference")])))) stop("Population integration returned nonfinite values.")
  if (max(B$MaximumRefinementDifference) > Settings$TruthTolerance) stop("Population integration needs more quadrature nodes.")
  B$Nodes <- Settings$TruthCheckNodes
  B
}

MakeCompletionTarget <- function(Data, Scenario) {
  P <- Data$Patients
  P$ObservedCount <- P$Count
  P$ObservedEnd <- P$Stop
  P$KnownDeath <- P$Death
  P$NeedsImputation <- P$Death == 0 & P$Stop < tail(Scenario$Cutpoints, 1)
  P$Horizon <- tail(Scenario$Cutpoints, 1)
  P
}

GenerateCompleteOutcomes <- function(Data, Target, Scenario, Rules, Seed) {
  SetSimulationSeed(Seed)
  Need <- which(Target$NeedsImputation)
  Ud <- pmax(.Machine$double.eps, stats::runif(length(Need)))
  Ur <- pmax(.Machine$double.eps, stats::runif(length(Need)))
  Out <- list()
  for (S in seq_len(nrow(Rules))) {
    C <- Target$ObservedCount
    D <- Target$KnownDeath
    T <- Target$ObservedEnd
    if (length(Need)) {
      P <- Target[Need, ]
      B <- Data$Latent$Frailty[Need]
      RateR <- outer(exp((1 - Rules$RecurrenceBorrowing[S])*Scenario$BetaR*P$Treatment +
        Scenario$GammaR*P$Age60 + B), Scenario$RecurrenceRates)
      RateD <- outer(exp((1 - Rules$DeathBorrowing[S])*Scenario$BetaD*P$Treatment +
        Scenario$GammaD*P$Age60 + Scenario$Alpha*B), Scenario$DeathRates)
      Terminal <- DrawTerminalFollowup(P$ObservedEnd, P$Horizon[1], RateD, Scenario$Cutpoints, Ud)
      Exposure <- GetSimulationExposure(P$ObservedEnd, Terminal$End, Scenario$Cutpoints)
      C[Need] <- C[Need] + stats::qpois(Ur, rowSums(Exposure*RateR))
      D[Need] <- Terminal$Death
      T[Need] <- Terminal$End
    }
    Out[[Rules$Scenario[S]]] <- cbind(RecurrentCount = C, DeathRisk = D, RestrictedMeanSurvival = T)
  }
  # Generated frailties are used only to generate truth, never for imputation.
  Out
}

AnalyzeCompleteOutcomes <- function(Outcomes, Target, ConfidenceLevel) {
  Rows <- list()
  for (Rule in names(Outcomes)) for (Outcome in colnames(Outcomes[[Rule]])) {
    X <- Outcomes[[Rule]][, Outcome]
    Active <- Target$Treatment == 1
    W1 <- stats::var(X[Active])/sum(Active)
    W0 <- stats::var(X[!Active])/sum(!Active)
    Variance <- W1 + W0
    Df <- if (Variance > 0) Variance^2/(W1^2/(sum(Active) - 1) + W0^2/(sum(!Active) - 1)) else NA_real_
    Valid <- is.finite(Variance) && Variance > 0 && is.finite(Df) && Df > 0
    Critical <- if (Valid) stats::qt((1 + ConfidenceLevel)/2, Df) else NA_real_
    Q <- mean(X[Active]) - mean(X[!Active])
    Rows[[length(Rows) + 1]] <- data.frame(Rule = Rule, Outcome = Outcome, Method = "Complete",
      ActiveMean = mean(X[Active]), ControlMean = mean(X[!Active]), Estimate = Q,
      EstimatedSe = sqrt(Variance), Lower = Q - Critical*sqrt(Variance), Upper = Q + Critical*sqrt(Variance),
      Df = Df, PoolingValid = Valid, Imputations = 0, NumericalMcse = 0,
      ExpectedEstimate = NA_real_, ExpectedMcse = NA_real_, BetweenVariance = 0,
      WithinVariance = Variance, TotalVariance = Variance, NoMissing = TRUE)
  }
  do.call(rbind, Rows)
}

GetCompletionUniforms <- function(Indices, Missing, Seed) {
  Death <- Count <- matrix(0, Missing, length(Indices))
  for (J in seq_along(Indices)) {
    SetSimulationSeed(Seed + Indices[J])
    Death[, J] <- pmax(.Machine$double.eps, stats::runif(Missing))
    Count[, J] <- pmax(.Machine$double.eps, stats::runif(Missing))
  }
  list(Death = Death, Count = Count)
}

RunCompletionImputations <- function(Fit, Target, Scenario, Rules, Seed, Settings) {
  A <- Fit$Draws
  M <- prod(dim(A)[1:2])
  X <- matrix(A, nrow = M, dimnames = list(NULL, dimnames(A)[[3]]))
  K <- length(Scenario$Cutpoints) - 1
  Need <- which(Target$NeedsImputation)
  Wanted <- c("BetaR", "GammaR", "BetaD", "GammaD", "Alpha",
    paste0("RecurrenceLogRate[", seq_len(K), "]"), paste0("DeathLogRate[", seq_len(K), "]"),
    paste0("B[", seq_len(nrow(Target)), "]"))
  At <- match(Wanted, colnames(X))
  if (anyNA(At) || any(!is.finite(X[, At, drop = FALSE]))) stop("Posterior components are missing or nonfinite.")
  X <- X[, At, drop = FALSE]
  Meta <- data.frame(Imputation = seq_len(M), Chain = rep(seq_len(dim(A)[2]), each = dim(A)[1]),
    Iteration = rep(seq_len(dim(A)[1]), dim(A)[2]))
  Batches <- split(seq_len(M), ceiling(seq_len(M)/Settings$ImputationBatchSize))
  Results <- vector("list", length(Batches))
  Burden <- NULL
  for (Batch in seq_along(Batches)) {
    Indices <- Batches[[Batch]]
    U <- GetCompletionUniforms(Indices, length(Need), Seed)
    Z <- CompleteTrialBatchCpp(X[Indices, , drop = FALSE], Target$Treatment, Target$Age60,
      Target$ObservedCount, Target$ObservedEnd, Target$KnownDeath, Target$NeedsImputation,
      Scenario$Cutpoints, Rules$RecurrenceBorrowing, Rules$DeathBorrowing, U$Death, U$Count)
    Rows <- list()
    Outcomes <- c("RecurrentCount", "DeathRisk", "RestrictedMeanSurvival")
    for (S in seq_len(nrow(Rules))) for (O in seq_along(Outcomes)) {
      At <- ((S - 1)*3 + O - 1)*length(Indices) + seq_along(Indices)
      V <- as.data.frame(Z$Analyses[At, , drop = FALSE])
      V$Scenario <- Rules$Scenario[S]
      V$Outcome <- Outcomes[O]
      V$Imputation <- Meta$Imputation[Indices]
      V$Chain <- Meta$Chain[Indices]
      V$Iteration <- Meta$Iteration[Indices]
      V$ActiveParticipants <- sum(Target$Treatment == 1)
      V$ControlParticipants <- sum(Target$Treatment == 0)
      V$NoMissing <- !length(Need)
      Rows[[length(Rows) + 1]] <- V
    }
    Results[[Batch]] <- do.call(rbind, Rows)
    Burden <- if (is.null(Burden)) Z$Burden else Burden + Z$Burden
  }
  Analyses <- do.call(rbind, Results)
  Analyses <- Analyses[order(match(Analyses$Scenario, Rules$Scenario), Analyses$Outcome, Analyses$Imputation), ]
  Pooled <- PoolMiAnalyses(Analyses, Settings$ConfidenceLevel)
  names(Pooled)[names(Pooled) == "Scenario"] <- "Rule"
  names(Pooled)[names(Pooled) == "RubinSe"] <- "EstimatedSe"
  Pooled$Method <- "MI"
  Shifts <- list()
  for (Rule in Rules$Scenario) for (Outcome in unique(Analyses$Outcome)) {
    P <- Analyses[Analyses$Scenario == Rule & Analyses$Outcome == Outcome, ]
    Q <- Analyses[Analyses$Scenario == "MAR" & Analyses$Outcome == Outcome, ]
    Difference <- P$Estimate - Q$Estimate
    Shifts[[length(Shifts) + 1]] <- data.frame(Rule = Rule, Outcome = Outcome,
      DifferenceFromMAR = mean(Difference), PairedNumericalMcse = GetChainMcse(Difference, P))
  }
  Burden <- as.data.frame(Burden/M)
  Burden$Rule <- rep(Rules$Scenario, each = 2)
  Burden$Arm <- rep(0:1, nrow(Rules))
  Burden$Participants <- as.numeric(table(factor(Target$Treatment, levels = 0:1)))[Burden$Arm + 1]
  Burden$RequiringImputation <- vapply(Burden$Arm, function(Arm) sum(Target$NeedsImputation & Target$Treatment == Arm), numeric(1))
  # Retain aggregate summaries; participant completions remain in memory only.
  list(Pooled = Pooled, Shifts = do.call(rbind, Shifts), Burden = Burden)
}


GetCompletionSeeds <- function(Seed, Replication, Settings) {
  Base <- Seed + 1000000*Replication
  Largest <- Base + 10000 + Settings$Chains*Settings$Sampling*Settings$MaximumSamplingBlocks
  if (Largest >= .Machine$integer.max || Largest >= Base + 1000000 || Base < 1) stop("The requested seed range is too large.")
  list(Data = Base + 1, Complete = Base + 2, Initial = Base + 100,
    Sampler = Base + 1000, Imputation = Base + 10000)
}

GetCompletionDefinition <- function(Index, Settings, Software) {
  Scenario <- GetCompletionScenario(Index)
  Rules <- CheckMiScenarios(GetCompletionRules())
  Operational <- c("Replications", "CoreFraction", "MaxConcurrentFits", "OutputFolder",
    "InstallMissingPackages", "RetryFailed")
  # Reporting changes do not invalidate fitted trials; all scientific functions
  # and both compiled kernels remain part of the saved definition.
  FunctionNames <- c("SetSimulationSeed", "GetCompletionSeeds", "GenerateSimulationData",
    "GetSimulationExposure", "BuildCustomData", "CustomComponents", "GetCustomInitial",
    "JitterCustomInitial", "RunCustomChain", "GetCustomDiagnostics", "GetCustomDiagnosticStatus",
    "GetCustomBlockRecord", "CollectCustomDraws", "AppendCustomDraws", "RunCustomAutoFit",
    "GetNormalQuadrature", "IntegratedExponential", "IntegrateStateOccupancy",
    "ConditionalPopulationMoments", "ComputePopulationTruth", "GetVerifiedPopulationTruth",
    "MakeCompletionTarget", "DrawTerminalFollowup", "GetFutureMoments", "GenerateCompleteOutcomes",
    "AnalyzeCompleteOutcomes", "GetCompletionUniforms", "RunCompletionImputations",
    "GetCompletedAnalyses", "PoolMiScalar", "PoolMiAnalyses", "GetChainMcse",
    "AuditReturnedStates", "SummarizeCompletionFit", "RunCompletionReplication")
  Bodies <- lapply(mget(FunctionNames, envir = environment(GetCompletionDefinition)), function(F) list(Formals = deparse(formals(F), width.cutoff = 500), Body = deparse(body(F), width.cutoff = 500)))
  list(Version = CompletionSimulationVersion, Scenario = Scenario, Rules = Rules,
    ScenarioSeed = Settings$Seed + 100*Index, Settings = Settings[setdiff(names(Settings), Operational)],
    Versions = Software$Versions, SamplerHash = SimulationHash(CustomSamplerCode),
    ImplementationHash = SimulationHash(list(Functions = Bodies, Sampler = CustomSamplerCode, Completion = CompletionCode)))
}

SummarizeCompletionFit <- function(Auto, D, Settings) {
  AuditReturnedStates(Auto$Draws, D)
  Variables <- Auto$VariableDiagnostics
  Names <- c("BetaR", "GammaR", "BetaD", "GammaD", "Alpha", "FrailtyVariance")
  Parameters <- do.call(rbind, lapply(Names, function(Name) {
    X <- Auto$Draws[, , Name]
    Q <- stats::quantile(X, c(0.025, 0.975), names = FALSE)
    data.frame(Parameter = Name, Estimate = mean(X), PosteriorSd = stats::sd(as.numeric(X)),
      Lower = Q[1], Upper = Q[2], NumericalMcse = posterior::mcse_mean(X))
  }))
  Scores <- do.call(rbind, lapply(1:5, function(J) {
    X <- Auto$Draws[, , paste0("Scores[", J, "]")]
    E <- posterior::mcse_mean(X)
    data.frame(Parameter = Names[J], Estimate = mean(X), NumericalMcse = E,
      Review = !is.finite(E) || abs(mean(X)) > 3*E)
  }))
  Chains <- BindSimulationRows(lapply(Auto$Runs, as.data.frame))
  CachePassed <- all(is.finite(Chains$MaximumCacheDifference) & Chains$MaximumCacheDifference <= 1e-8)
  list(Parameters = Parameters, Scores = Scores, VariableDiagnostics = Variables,
    ChainDiagnostics = Chains, ScoreFlag = any(Scores$Review),
    DiagnosticsPassed = Auto$WarmupEstablished && Auto$RhatPassed && Auto$EssPassed && CachePassed)
}

RunCompletionReplication <- function(Replication, Definition, Truth, Settings, Directory) {
  Timer <- proc.time()[3]
  Path <- file.path(Directory, sprintf("Replication%05d.rds", Replication))
  Previous <- if (file.exists(Path)) readRDS(Path) else NULL
  Seeds <- GetCompletionSeeds(Definition$ScenarioSeed, Replication, Settings)
  Result <- list(Version = CompletionSimulationVersion, Replication = Replication,
    DefinitionHash = SimulationHash(Definition), Seeds = Seeds, FitStatus = "Failed", Stage = "Generate",
    Error = "", Warnings = character(), DiagnosticsPassed = FALSE, ScoreFlag = FALSE,
    Estimates = data.frame(), Burden = data.frame(), Shifts = data.frame(), DataSummary = data.frame(),
    Parameters = data.frame(), Scores = data.frame(), VariableDiagnostics = data.frame(),
    ChainDiagnostics = data.frame(), BlockDiagnostics = data.frame(), Imputations = 0,
    GenerationSeconds = NA_real_, SamplingSeconds = NA_real_, ImputationSeconds = NA_real_,
    TotalSeconds = NA_real_, WorkerPid = Sys.getpid(), StopReason = "Error")
  Warnings <- character()
  Result <- tryCatch(withCallingHandlers({
    Scenario <- Definition$Scenario
    Rules <- Definition$Rules
    Data <- GenerateSimulationData(Scenario, Seeds$Data)
    Target <- MakeCompletionTarget(Data, Scenario)
    Complete <- GenerateCompleteOutcomes(Data, Target, Scenario, Rules, Seeds$Complete)
    Result$Estimates <- AnalyzeCompleteOutcomes(Complete, Target, Settings$ConfidenceLevel)
    Result$DataSummary <- Data$Summary
    Data$Latent <- NULL
    # Neither generated future outcomes nor latent frailties enter the fit.
    Result$DataHash <- SimulationHash(Data)
    rm(Complete)
    Result$GenerationSeconds <- unname(proc.time()[3] - Timer)
    D <- BuildCustomData(Data, Scenario, Settings)
    Initial <- GetCustomInitial(Data, D)
    Jobs <- lapply(seq_len(Settings$Chains), function(J) list(Data = D,
      Initial = JitterCustomInitial(Initial, Seeds$Initial + J, J), Seed = Seeds$Sampler + J,
      Chain = J, Warmup = Settings$Warmup, Sampling = Settings$Sampling, BlockMoves = Settings$BlockMoves))
    Result$Stage <- "Sampling"
    Auto <- RunCustomAutoFit(Jobs, Settings)
    for (Name in setdiff(names(Auto), c("Draws", "Runs", "VariableDiagnostics"))) Result[[Name]] <- Auto[[Name]]
    Fit <- SummarizeCompletionFit(Auto, D, Settings)
    for (Name in names(Fit)) Result[[Name]] <- Fit[[Name]]
    Result$Stage <- "Imputation"
    Start <- proc.time()[3]
    Mi <- RunCompletionImputations(Auto, Target, Scenario, Rules, Seeds$Imputation, Settings)
    Result$Estimates <- BindSimulationRows(list(Result$Estimates, Mi$Pooled))
    Result$Burden <- Mi$Burden
    Result$Shifts <- Mi$Shifts
    Result$Imputations <- prod(dim(Auto$Draws)[1:2])
    Result$ImputationSeconds <- unname(proc.time()[3] - Start)
    Result$FitStatus <- "Completed"
    Result$Stage <- "Saved"
    Result
  }, warning = function(W) {
    Warnings <<- c(Warnings, conditionMessage(W))
    invokeRestart("muffleWarning")
  }), error = function(E) {
    Result$Error <- conditionMessage(E)
    Result
  })
  Result$Warnings <- unique(Warnings)
  Result$Review <- Result$FitStatus != "Completed" || !Result$DiagnosticsPassed || Result$ScoreFlag || length(Warnings) > 0
  Result$TotalSeconds <- unname(proc.time()[3] - Timer)
  Result$Attempts <- if (is.null(Previous)) list() else c(Previous$Attempts, list(Previous[c("FitStatus", "Stage", "Error", "TotalSeconds")]))
  if (nrow(Result$Estimates)) {
    Match <- match(paste(Result$Estimates$Rule, Result$Estimates$Outcome), paste(Truth$Rule, Truth$Outcome))
    if (anyNA(Match)) stop("An analysis has no population target.")
    Result$Estimates$Truth <- Truth$Truth[Match]
    Result$Estimates$GeneratingRule <- Result$Estimates$Rule
    Result$Estimates$MatchedRule <- TRUE
  }
  SaveSimulationRds(Result, Path)
  Result[c("Replication", "FitStatus", "DiagnosticsPassed", "ScoreFlag", "Error", "TotalSeconds", "Imputations", "StopReason")]
}

PrepareCompletionScenario <- function(Index, Settings, Software, Resources, Root) {
  Definition <- GetCompletionDefinition(Index, Settings, Software)
  Directory <- file.path(Root, Definition$Scenario$Name)
  dir.create(Directory, recursive = TRUE, showWarnings = FALSE)
  ManifestPath <- file.path(Directory, "Settings.rds")
  Requested <- Settings$Replications
  if (file.exists(ManifestPath) || file.exists(paste0(ManifestPath, ".previous"))) {
    Saved <- ReadSavedSimulation(ManifestPath)
    if (!identical(Saved$Definition, Definition)) stop("Saved settings differ. Use a new OutputFolder for a different design or program.")
    Requested <- max(Requested, Saved$Requested)
    Truth <- Saved$Truth
  } else {
    message("Calculating and checking the population targets...")
    Truth <- GetVerifiedPopulationTruth(Definition$Scenario, Definition$Rules, Settings)
  }
  GetCompletionSeeds(Definition$ScenarioSeed, Requested, Settings)
  Backup <- list.files(Directory, pattern = "^Replication[0-9]+\\.rds\\.previous$", full.names = TRUE)
  for (Path in Backup) ReadSavedSimulation(sub("\\.previous$", "", Path))
  Files <- list.files(Directory, pattern = "^Replication[0-9]+\\.rds$", full.names = TRUE)
  Results <- lapply(Files, ReadSavedSimulation)
  if (length(Results) && any(!vapply(Results, function(X) identical(X$DefinitionHash, SimulationHash(Definition)), logical(1)))) stop("Saved replications have different definitions.")
  Done <- vapply(Results, function(X) X$Replication, numeric(1))
  if (anyDuplicated(Done) || any(Done < 1 | Done > Requested)) stop("Invalid saved replication numbers.")
  Retry <- if (Settings$RetryFailed) vapply(Filter(function(X) X$FitStatus != "Completed", Results), `[[`, numeric(1), "Replication") else numeric()
  SaveSimulationRds(list(Definition = Definition, Requested = Requested, Resources = Resources, Truth = Truth), ManifestPath)
  list(Definition = Definition, Truth = Truth, Directory = Directory, Requested = Requested,
    Done = setdiff(Done, Retry), Remaining = sort(unique(c(setdiff(seq_len(Requested), Done), Retry))))
}

RunCompletionScenario <- function(Prepared, Settings, Resources, FitCluster) {
  Definition <- Prepared$Definition
  Remaining <- Prepared$Remaining
  if (!length(Remaining)) return(TRUE)
  Directory <- Prepared$Directory
  Seeds <- GetCompletionSeeds(Definition$ScenarioSeed, Remaining[1], Settings)
  Data <- GenerateSimulationData(Definition$Scenario, Seeds$Data)
  Data$Latent <- NULL
  D <- BuildCustomData(Data, Definition$Scenario, Settings)
  Audit <- AuditCustomKernels(D, JitterCustomInitial(GetCustomInitial(Data, D), 104729, 1))
  SaveSimulationRds(Audit, file.path(Directory, "ConditionalAudit.rds"))
  message(Definition$Scenario$Name, ": ", length(Remaining), "/", Prepared$Requested, " trials remaining; N = ", Definition$Scenario$Participants, ".")
  Start <- proc.time()[3]
  Done <- length(Prepared$Done)
  Report <- function(Batch) {
    Done <<- Done + length(Batch)
    Elapsed <- unname(proc.time()[3] - Start)
    message(Done, "/", Prepared$Requested, " saved; this batch: ",
      sum(vapply(Batch, function(X) X$FitStatus != "Completed", logical(1))), " failed; ",
      sum(vapply(Batch, function(X) X$FitStatus == "Completed" && !X$DiagnosticsPassed, logical(1))),
      " with MCMC flags; elapsed ", round(Elapsed/60, 1), " minutes.")
  }
  TimingPath <- file.path(Directory, "Execution.rds")
  on.exit({
    Previous <- if (file.exists(TimingPath)) ReadSavedSimulation(TimingPath) else list()
    SaveSimulationRds(c(Previous, list(list(CompletedThisInvocation = Done - length(Prepared$Done),
      ElapsedSeconds = unname(proc.time()[3] - Start), Resources = Resources))), TimingPath)
  }, add = TRUE)
  message("Checking the first trial before starting concurrent fits...")
  First <- parallel::parLapply(FitCluster, Remaining[1], RunCompletionReplication,
    Definition, Prepared$Truth, Settings, Directory)
  Report(First)
  if (First[[1]]$FitStatus != "Completed") {
    message("First trial failed: ", First[[1]]$Error, "\nExecution stopped; available results are saved.")
    return(FALSE)
  }
  Remaining <- Remaining[-1]
  if (!length(Remaining)) return(TRUE)
  for (Ids in split(Remaining, ceiling(seq_along(Remaining)/Resources$Workers))) {
    Batch <- parallel::parLapplyLB(FitCluster, Ids, RunCompletionReplication,
      Definition, Prepared$Truth, Settings, Directory)
    Report(Batch)
    if (all(vapply(Batch, function(X) X$FitStatus != "Completed", logical(1)))) {
      message("All trials in this batch failed. Execution stopped.")
      return(FALSE)
    }
  }
  TRUE
}

RunCompletionStudy <- function(Indices = 1, Settings = CompletionSettings) {
  ValidateCompletionSettings(Settings)
  if (!length(Indices) || any(Indices != 1) || anyDuplicated(Indices)) stop("Scenario index must be 1.")
  if (!nzchar(CompletionProgramPath)) stop("Run Scenario01.R with source() or Rscript.")
  Software <- EnsureCustomPackages(Settings)
  Resources <- GetCustomResources(Settings)
  Root <- file.path(dirname(CompletionProgramPath), Settings$OutputFolder)
  dir.create(Root, recursive = TRUE, showWarnings = FALSE)
  Lock <- filelock::lock(file.path(Root, "Running.lock"), timeout = 0)
  if (is.null(Lock)) stop("This study is already running. Wait for it; do not delete the lock file.")
  on.exit(filelock::unlock(Lock), add = TRUE)
  Names <- c("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")
  Previous <- Sys.getenv(Names, unset = NA_character_)
  on.exit({ for (J in seq_along(Names)) {
    if (is.na(Previous[J])) Sys.unsetenv(Names[J]) else do.call(Sys.setenv, setNames(list(Previous[J]), Names[J]))
  } }, add = TRUE)
  Sys.setenv(OMP_NUM_THREADS = "1", OPENBLAS_NUM_THREADS = "1", MKL_NUM_THREADS = "1", VECLIB_MAXIMUM_THREADS = "1")
  Prepared <- lapply(Indices, PrepareCompletionScenario, Settings, Software, Resources, Root)
  if (all(vapply(Prepared, function(X) !length(X$Remaining), logical(1)))) return(invisible(SummarizeCompletionSimulation(Root)))
  message("Completion simulation: matched MAR and J2R, one fit per trial.")
  message(Resources$Workers, " concurrent fits, ", Resources$ParallelChains, " chains in parallel per fit; budget ", Resources$Budget, "/", Resources$LogicalCores, " cores.")
  message("All retained draws are imputed. Rhat <= ", Settings$MaximumRhat, "; bulk and tail ESS >= ", Settings$MinimumEss, ".")
  message("Output: ", normalizePath(Root, winslash = "/"))
  CompiledDirectory <- file.path(Root, "CompiledSampler")
  Start <- proc.time()[3]
  message("Preparing the sampler and completion calculations...")
  CompileCustomSampler(CompiledDirectory)
  CompilationSeconds <- unname(proc.time()[3] - Start)
  FitCluster <- parallel::makePSOCKcluster(Resources$Workers)
  on.exit({
    try(parallel::clusterCall(FitCluster, StopCustomWorker), silent = TRUE)
    try(parallel::stopCluster(FitCluster), silent = TRUE)
  }, add = TRUE)
  Start <- proc.time()[3]
  parallel::clusterCall(FitCluster, InitializeCustomWorker, CompletionProgramPath, CompiledDirectory, Resources$ParallelChains)
  SaveSimulationRds(list(CompilationSeconds = CompilationSeconds,
    WorkerSetupSeconds = unname(proc.time()[3] - Start), Versions = Software$Versions,
    Resources = Resources), file.path(Root, "Setup.rds"))
  tryCatch({
    for (Item in Prepared) if (!RunCompletionScenario(Item, Settings, Resources, FitCluster)) break
  }, interrupt = function(E) message("Interrupted. Completed trials are saved; closing workers."),
    error = function(E) message("Stopped: ", conditionMessage(E)))
  try(parallel::clusterCall(FitCluster, StopCustomWorker), silent = TRUE)
  Answer <- SummarizeCompletionSimulation(Root)
  invisible(Answer)
}


WilsonCoverage <- function(Successes, Total) {
  if (!Total) return(c(Lower = NA_real_, Upper = NA_real_))
  Z <- stats::qnorm(0.975)
  P <- Successes/Total
  Center <- (P + Z^2/(2*Total))/(1 + Z^2/Total)
  Half <- Z*sqrt(P*(1 - P)/Total + Z^2/(4*Total^2))/(1 + Z^2/Total)
  c(Lower = max(0, Center - Half), Upper = min(1, Center + Half))
}

CompletionOperatingCharacteristics <- function(Estimates, Attempted) {
  if (!nrow(Estimates)) return(data.frame())
  Groups <- unique(Estimates[, c("Scenario", "Rule", "Outcome", "Method")])
  Rows <- lapply(seq_len(nrow(Groups)), function(J) {
    G <- Groups[J, ]
    P <- Estimates[Estimates$Scenario == G$Scenario & Estimates$Rule == G$Rule &
      Estimates$Outcome == G$Outcome & Estimates$Method == G$Method, ]
    E <- P[is.finite(P$Estimate), ]
    V <- P[is.finite(P$Estimate) & is.finite(P$Lower) & is.finite(P$Upper) &
      is.finite(P$EstimatedSe) & P$EstimatedSe > 0 & P$PoolingValid, ]
    N <- nrow(E)
    Nv <- nrow(V)
    Truth <- unique(P$Truth)
    if (length(Truth) != 1 || !is.finite(Truth)) stop("A summary group has inconsistent population targets.")
    Error <- E$Estimate - Truth
    Cover <- V$Lower <= Truth & V$Upper >= Truth
    Coverage <- if (Nv) mean(Cover) else NA_real_
    Bounds <- WilsonCoverage(sum(Cover), Nv)
    Average <- function(X) if (length(X) && any(is.finite(X))) mean(X[is.finite(X)]) else NA_real_
    Sd <- if (N > 1) stats::sd(E$Estimate) else NA_real_
    Rmse <- if (N) sqrt(mean(Error^2)) else NA_real_
    data.frame(G, Truth = Truth, Attempted = Attempted[[G$Scenario]],
      ValidEstimates = N, ValidIntervals = Nv,
      UnavailableEstimates = Attempted[[G$Scenario]] - N,
      UnavailableIntervals = Attempted[[G$Scenario]] - Nv,
      MeanEstimate = Average(E$Estimate), Bias = Average(Error),
      BiasMonteCarloSe = if (N > 1) Sd/sqrt(N) else NA_real_,
      Rmse = Rmse, RmseMonteCarloSe = if (N > 1 && Rmse > 0) stats::sd(Error^2)/(2*Rmse*sqrt(N)) else NA_real_,
      EmpiricalSd = Sd, MeanEstimatedSe = Average(E$EstimatedSe),
      Coverage = Coverage, CoverageMonteCarloSe = if (Nv) sqrt(Coverage*(1 - Coverage)/Nv) else NA_real_,
      CoverageMonteCarloLower = Bounds[1], CoverageMonteCarloUpper = Bounds[2],
      MeanIntervalWidth = Average(V$Upper - V$Lower),
      RejectZero = if (Nv) mean(V$Lower > 0 | V$Upper < 0) else NA_real_,
      MeanImputations = Average(E$Imputations), MeanNumericalMcse = Average(E$NumericalMcse),
      MeanNumericalToInferentialSe = Average(E$NumericalMcse/E$EstimatedSe), row.names = NULL)
  })
  do.call(rbind, Rows)
}

CompletionPairedSummary <- function(Estimates) {
  if (!nrow(Estimates)) return(data.frame())
  Mi <- Estimates[Estimates$Method == "MI", ]
  Full <- Estimates[Estimates$Method == "Complete", ]
  Key <- function(D) paste(D$Scenario, D$Replication, D$Rule, D$Outcome)
  At <- match(Key(Mi), Key(Full))
  Keep <- !is.na(At)
  Mi <- Mi[Keep, ]
  Full <- Full[At[Keep], ]
  Groups <- unique(Mi[, c("Scenario", "Rule", "Outcome")])
  if (!nrow(Groups)) return(data.frame())
  do.call(rbind, lapply(seq_len(nrow(Groups)), function(I) {
    G <- Groups[I, ]
    At <- Mi$Scenario == G$Scenario & Mi$Rule == G$Rule & Mi$Outcome == G$Outcome
    P <- Mi[At, ]
    F <- Full[At, ]
    Valid <- is.finite(P$Estimate) & is.finite(F$Estimate)
    Difference <- P$Estimate[Valid] - F$Estimate[Valid]
    Intervals <- Valid & P$PoolingValid & F$PoolingValid & is.finite(P$Lower) &
      is.finite(P$Upper) & is.finite(F$Lower) & is.finite(F$Upper)
    Cp <- P$Lower[Intervals] <= P$Truth[Intervals] & P$Upper[Intervals] >= P$Truth[Intervals]
    Cf <- F$Lower[Intervals] <= F$Truth[Intervals] & F$Upper[Intervals] >= F$Truth[Intervals]
    data.frame(G, Pairs = sum(Valid), IntervalPairs = sum(Intervals),
      MeanMiMinusComplete = if (length(Difference)) mean(Difference) else NA_real_,
      DifferenceMonteCarloSe = if (length(Difference) > 1) stats::sd(Difference)/sqrt(length(Difference)) else NA_real_,
      CompleteCoverageInPairs = if (length(Cf)) mean(Cf) else NA_real_,
      MiCoverageInPairs = if (length(Cp)) mean(Cp) else NA_real_,
      CoverageDifference = if (length(Cp)) mean(Cp - Cf) else NA_real_,
      CoverageDifferenceMonteCarloSe = if (length(Cp) > 1) stats::sd(Cp - Cf)/sqrt(length(Cp)) else NA_real_)
  }))
}

ReadCompletionSnapshot <- function(Path) {
  for (Candidate in c(Path, paste0(Path, ".previous"))) {
    if (file.exists(Candidate)) {
      X <- tryCatch(readRDS(Candidate), error = function(E) NULL)
      if (!is.null(X)) return(X)
    }
  }
  NULL
}

SummarizeCompletionSimulation <- function(OutputDir) {
  if (!dir.exists(OutputDir)) stop("No completion results found. Run Scenario01.R first.")
  Directory <- file.path(OutputDir, "Summary")
  dir.create(Directory, recursive = TRUE, showWarnings = FALSE)
  if (!requireNamespace("filelock", quietly = TRUE)) stop("Install filelock to rebuild the summaries.")
  Lock <- filelock::lock(file.path(Directory, "Summary.lock"), timeout = 0)
  if (is.null(Lock)) {
    message("Another session is rebuilding these summaries. Try again shortly.")
    return(invisible(NULL))
  }
  on.exit(filelock::unlock(Lock), add = TRUE)
  Dirs <- list.dirs(OutputDir, recursive = FALSE, full.names = TRUE)
  Dirs <- Dirs[grepl("^Scenario[0-9]+$", basename(Dirs))]
  Estimates <- Status <- Parameters <- Scores <- Blocks <- Burden <- Shifts <- Truth <- Design <- DiagnosticFlags <- Manifests <- list()
  Requested <- Attempted <- list()
  Skipped <- character()
  for (Dir in Dirs) {
    Manifest <- ReadCompletionSnapshot(file.path(Dir, "Settings.rds"))
    if (is.null(Manifest)) next
    Name <- Manifest$Definition$Scenario$Name
    Manifests[[Name]] <- Manifest
    Files <- list.files(Dir, pattern = "^Replication[0-9]+\\.rds$", full.names = TRUE)
    Results <- lapply(Files, ReadCompletionSnapshot)
    Missing <- vapply(Results, is.null, logical(1))
    Skipped <- c(Skipped, basename(Files[Missing]))
    Results <- Results[!Missing]
    DefinitionHash <- SimulationHash(Manifest$Definition)
    if (any(!vapply(Results, function(X) identical(X$DefinitionHash, DefinitionHash), logical(1)))) stop("Some saved results have a different definition.")
    Ids <- vapply(Results, `[[`, numeric(1), "Replication")
    if (anyDuplicated(Ids)) stop("Duplicate replication numbers in the results.")
    Results <- Results[order(Ids)]
    Requested[[Name]] <- Manifest$Requested
    Attempted[[Name]] <- length(Results)
    T <- Manifest$Truth
    T$Scenario <- Name
    Truth[[Name]] <- T
    Sc <- Manifest$Definition$Scenario
    Se <- Manifest$Definition$Settings
    Design[[Name]] <- data.frame(Scenario = Name, Participants = Sc$Participants,
      ActiveParticipants = Sc$ActiveParticipants, Alpha = Sc$Alpha, FrailtyVariance = Sc$FrailtyVariance,
      Horizon = tail(Sc$Cutpoints, 1), CensoringRate = Sc$CensoringRate, AgeProbability = Sc$AgeProbability,
      BetaR = Sc$BetaR, GammaR = Sc$GammaR, BetaD = Sc$BetaD, GammaD = Sc$GammaD,
      RecurrenceRates = paste(Sc$RecurrenceRates, collapse = ", "), DeathRates = paste(Sc$DeathRates, collapse = ", "),
      Cutpoints = paste(Sc$Cutpoints, collapse = ", "), FixedEffectSd = Se$FixedEffectSd, AlphaSd = Se$AlphaSd,
      FrailtyShape = Se$FrailtyShape, FrailtyRate = Se$FrailtyRate, BaselineLogMean = Se$BaselineLogMean,
      BaselineLogSd = Se$BaselineLogSd, Requested = Manifest$Requested,
      CoreBudget = Manifest$Resources$Budget, ConcurrentFits = Manifest$Resources$Workers,
      ParallelChains = Manifest$Resources$ParallelChains, Chains = Se$Chains,
      Sampling = Se$Sampling, Warmup = Se$Warmup, MinimumEss = Se$MinimumEss, MaximumRhat = Se$MaximumRhat)
    Attach <- function(D, R) {
      if (!is.data.frame(D) || !nrow(D)) return(data.frame())
      D$Scenario <- Name
      D$Replication <- R$Replication
      D$McmcPassed <- R$DiagnosticsPassed
      D
    }
    for (R in Results) {
      V <- R$VariableDiagnostics
      MaximumRhat <- if (nrow(V) && all(is.finite(V$Rhat))) max(V$Rhat) else NA_real_
      MinimumBulkEss <- if (nrow(V) && all(is.finite(V$BulkEss))) min(V$BulkEss) else NA_real_
      MinimumTailEss <- if (nrow(V) && all(is.finite(V$TailEss))) min(V$TailEss) else NA_real_
      Status[[length(Status) + 1]] <- data.frame(Scenario = Name, Replication = R$Replication,
        FitStatus = R$FitStatus, Stage = R$Stage, McmcPassed = R$DiagnosticsPassed,
        ScoreFlag = R$ScoreFlag, Warnings = paste(R$Warnings, collapse = " | "), Error = R$Error,
        StopReason = R$StopReason, Imputations = R$Imputations,
        MaximumRhat = MaximumRhat, MinimumBulkEss = MinimumBulkEss, MinimumTailEss = MinimumTailEss,
        WarmupBlocks = if (is.null(R$WarmupBlocks)) 0 else R$WarmupBlocks,
        SamplingBlocks = if (is.null(R$SamplingBlocks)) 0 else R$SamplingBlocks,
        GenerationSeconds = R$GenerationSeconds, SamplingSeconds = R$SamplingSeconds,
        ImputationSeconds = R$ImputationSeconds, TotalSeconds = R$TotalSeconds,
        ObservedDeaths = if (nrow(R$DataSummary)) R$DataSummary$Deaths else NA_real_,
        ObservedRecurrences = if (nrow(R$DataSummary)) R$DataSummary$Recurrences else NA_real_,
        CensoredEarly = if (nrow(R$DataSummary)) R$DataSummary$CensoredEarly else NA_real_)
      DiagnosticFlags[[length(DiagnosticFlags) + 1]] <- Attach(if (nrow(V)) V[V$Review, ] else V, R)
      Estimates[[length(Estimates) + 1]] <- Attach(R$Estimates, R)
      Parameters[[length(Parameters) + 1]] <- Attach(R$Parameters, R)
      Scores[[length(Scores) + 1]] <- Attach(R$Scores, R)
      Blocks[[length(Blocks) + 1]] <- Attach(R$BlockDiagnostics, R)
      Burden[[length(Burden) + 1]] <- Attach(R$Burden, R)
      Shifts[[length(Shifts) + 1]] <- Attach(R$Shifts, R)
    }
  }
  Design <- BindSimulationRows(Design)
  if (!nrow(Design)) stop("No saved scenario settings were found.")
  Estimates <- BindSimulationRows(Estimates)
  Status <- BindSimulationRows(Status)
  Tables <- list(Design = Design, PopulationTruth = BindSimulationRows(Truth),
    OperatingCharacteristics = CompletionOperatingCharacteristics(Estimates, Attempted),
    PairedComparison = CompletionPairedSummary(Estimates), ReplicationStatus = Status,
    Estimates = Estimates, ParameterSummaries = BindSimulationRows(Parameters),
    ScoreDiagnostics = BindSimulationRows(Scores), McmcFlags = BindSimulationRows(DiagnosticFlags), BlockDiagnostics = BindSimulationRows(Blocks),
    ImputationBurden = BindSimulationRows(Burden), PairedNumericalChanges = BindSimulationRows(Shifts))
  for (Name in names(Tables)) utils::write.csv(Tables[[Name]], file.path(Directory, paste0(Name, ".csv")), row.names = FALSE, na = "")
  Summary <- c("Completion simulation", "",
    "Summaries retain finite estimates, including diagnostic flags.",
    "Bias uses ValidEstimates; coverage uses ValidIntervals.",
    "Complete uses generated complete outcomes; MI uses the matching rule and Rubin pooling.",
    "Detailed settings, population targets, and diagnostics are in the accompanying CSV files.", "")
  for (Name in Design$Scenario) {
    D <- Design[Design$Scenario == Name, ]
    P <- if (nrow(Status)) Status[Status$Scenario == Name, ] else data.frame()
    Average <- function(X) if (length(X) && any(is.finite(X))) mean(X[is.finite(X)]) else NA_real_
    Bytes <- sum(file.info(list.files(file.path(OutputDir, Name), pattern = "^Replication[0-9]+\\.rds$", full.names = TRUE))$size)
    Summary <- c(Summary, paste("Scenario:", Name, "N:", D$Participants, "alpha:", D$Alpha, "horizon:", D$Horizon),
      paste("Requested:", Requested[[Name]], "attempted:", Attempted[[Name]], "remaining:", Requested[[Name]] - Attempted[[Name]]),
      paste("Completed:", if (nrow(P)) sum(P$FitStatus == "Completed") else 0,
        "failed:", if (nrow(P)) sum(P$FitStatus != "Completed") else 0,
        "MCMC flags:", if (nrow(P)) sum(P$FitStatus == "Completed" & !P$McmcPassed) else 0,
        "score flags:", if (nrow(P)) sum(P$ScoreFlag) else 0),
      paste("Mean sampling seconds:", round(Average(P$SamplingSeconds), 2),
        "mean imputation/pooling seconds:", round(Average(P$ImputationSeconds), 2),
        "mean total worker seconds:", round(Average(P$TotalSeconds), 2)),
      paste("Mean imputations per rule:", round(Average(P$Imputations[P$Imputations > 0])),
        "compact replication files (MiB):", round(Bytes/1024^2, 3)),
      paste("Concurrent fits:", D$ConcurrentFits, "parallel chains per fit:", D$ParallelChains, "core budget:", D$CoreBudget), "")
  }
  if (nrow(Tables$OperatingCharacteristics)) Summary <- c(Summary, capture.output(print(Tables$OperatingCharacteristics[,
    c("Rule", "Outcome", "Method", "Truth", "ValidEstimates", "ValidIntervals", "Bias", "EmpiricalSd", "MeanEstimatedSe", "Coverage", "CoverageMonteCarloSe")], row.names = FALSE)))
  if (length(Skipped)) Summary <- c(Summary, "A file was being updated or unreadable. Rerun this summary shortly:", Skipped)
  writeLines(Summary, file.path(Directory, "Summary.txt"))
  WriteCompletionTables(Tables, file.path(Directory, "Tables"))
  message("Results: ", normalizePath(Directory, winslash = "/"))
  invisible(list(Settings = Manifests, Tables = Tables))
}

CompletionLatexNumber <- function(X, Digits = 3) {
  if (!length(X) || !is.finite(X)) return("{--}")
  formatC(if (abs(X) < 0.5*10^(-Digits)) 0 else X, format = "f", digits = Digits)
}

WriteCompletionTable <- function(Path, Caption, Label, Columns, Header, Rows, Note) {
  Text <- c("\\begin{table}[!htbp]", "\\begingroup", "\\centering", "\\small",
    "\\setlength{\\tabcolsep}{4pt}", "\\renewcommand{\\arraystretch}{1.12}",
    "\\captionsetup{justification=justified,singlelinecheck=false,font=small}",
    paste0("\\caption{", Caption, "}"), paste0("\\label{", Label, "}"),
    paste0("\\begin{tabular}{@{}", Columns, "@{}}"), "\\toprule", Header, "\\midrule", Rows,
    "\\bottomrule", "\\end{tabular}", "\\par\\vspace{4pt}", "\\begin{minipage}{\\linewidth}",
    paste0("\\footnotesize\\justifying\\noindent ", Note), "\\end{minipage}", "\\endgroup", "\\end{table}")
  writeLines(Text, Path)
}

WriteCompletionTables <- function(Tables, Directory) {
  dir.create(Directory, recursive = TRUE, showWarnings = FALSE)
  F <- CompletionLatexNumber
  RuleLabel <- function(X) ifelse(X == "MAR", "MAR", ifelse(X == "J2RBoth", "Both switch", X))
  Files <- character()
  Labels <- c(RecurrentCount = "Recurrent count", DeathRisk = "Death risk", RestrictedMeanSurvival = "Restricted mean survival")
  OC <- Tables$OperatingCharacteristics
  if (nrow(OC)) for (Scenario in unique(OC$Scenario)) {
    P <- OC[OC$Scenario == Scenario, ]
    CoverageFormat <- if (any(round(100*P$Coverage, 1) >= 100, na.rm = TRUE)) "3.1" else "2.1"
    McseFormat <- if (any(round(100*P$CoverageMonteCarloSe, 1) >= 10, na.rm = TRUE)) "2.1" else "1.1"
    FormatMcse <- function(X) {
      if (!is.finite(X)) return("\\mbox{(--)}")
      paste0("\\mbox{(\\tablenum[table-format=", McseFormat, "]{", F(100*X, 1), "})}")
    }
    Rows <- character()
    for (Outcome in names(Labels)) {
      P <- OC[OC$Scenario == Scenario & OC$Outcome == Outcome, ]
      if (!nrow(P)) next
      P <- P[order(match(P$Rule, c("MAR", "J2RBoth")), match(P$Method, c("Complete", "MI"))), ]
      if (length(Rows)) Rows <- c(Rows, "\\addlinespace[5pt]")
      Rows <- c(Rows, paste0("\\multicolumn{8}{@{}l}{\\textbf{", Labels[Outcome], "}}\\\\*"),
        vapply(seq_len(nrow(P)), function(I) paste0(paste(c(RuleLabel(P$Rule[I]), P$Method[I],
          F(P$Bias[I]), F(P$EmpiricalSd[I]), F(P$MeanEstimatedSe[I]), F(P$Rmse[I]),
          F(100*P$Coverage[I], 1), FormatMcse(P$CoverageMonteCarloSe[I])), collapse = " & "), " \\\\"), character(1)))
    }
    File <- paste0(Scenario, "CompletionPerformance.tex")
    WriteCompletionTable(file.path(Directory, File),
      "Performance of treatment contrasts under matched generating and imputation assumptions.",
      if (Scenario == "Scenario01") "tab:CompletionPerformance" else paste0("tab:", Scenario, "CompletionPerformance"),
      paste0("ll S[table-format=-1.3] *{3}{S[table-format=1.3]} S[table-format=", CoverageFormat, "] @{\\,} l"),
      paste0("\\textbf{Rule} & \\textbf{Analysis} & \\multicolumn{1}{l}{\\textbf{Bias}} & ",
        "\\multicolumn{1}{l}{\\textbf{Emp. SD}} & \\multicolumn{1}{l}{\\textbf{Mean SE}} & ",
        "\\multicolumn{1}{l}{\\textbf{RMSE}} & \\multicolumn{2}{l}{\\shortstack[l]{\\textbf{Coverage, \\%}\\\\\\textbf{(MCSE)}}} \\\\"), Rows,
      paste("MAR retains both treatment effects after censoring; both switch removes both effects.",
        "Complete uses generated complete outcomes and a Welch interval. MI uses multiple imputation under the matching rule and Rubin pooling.",
        "Emp. SD is the empirical standard deviation of estimates; Mean SE is the average estimated standard error; RMSE is root mean squared error.",
        "Nominal coverage is 95\\%; parentheses contain Monte Carlo standard errors in percentage points.",
        "Death risk is expressed as a probability and restricted mean survival in years."))
    Files <- c(Files, File)
  }
  Truth <- Tables$PopulationTruth
  for (Scenario in unique(Truth$Scenario)) {
    P <- Truth[Truth$Scenario == Scenario, ]
    Rows <- vapply(seq_len(nrow(P)), function(I) paste0(paste(c(RuleLabel(P$Rule[I]), Labels[P$Outcome[I]],
      F(P$ControlMean[I]), F(P$ActiveMean[I]), F(P$Truth[I])), collapse = " & "), " \\\\"), character(1))
    File <- paste0(Scenario, "PopulationTargets.tex")
    WriteCompletionTable(file.path(Directory, File), "Population targets under the generating completion rules.",
      paste0("tab:", Scenario, "Targets"), "ll S[table-format=1.3] S[table-format=1.3] S[table-format=-1.3]",
      paste0("\\textbf{Rule} & \\textbf{Outcome} & \\multicolumn{1}{l}{\\textbf{Reference}} & ",
        "\\multicolumn{1}{l}{\\textbf{Active}} & \\multicolumn{1}{l}{\\textbf{Difference}} \\\\"), Rows,
      "Targets average over frailty, the baseline covariate, and the potential censoring time. Differences are active minus reference. Death risk is expressed as a probability and restricted mean survival in years.")
    Files <- c(Files, File)
  }
  D <- Tables$Design
  Rows <- vapply(seq_len(nrow(D)), function(I) paste0(paste(c(F(D$Participants[I], 0),
    F(D$Alpha[I], 2), F(D$Horizon[I], 1), F(D$CensoringRate[I], 2)), collapse = " & "), " \\\\"), character(1))
  File <- "SimulationDesign.tex"
  WriteCompletionTable(file.path(Directory, File), "Design of the completion simulation.", "tab:CompletionDesign",
    "S[table-format=3.0] S[table-format=1.2] S[table-format=1.1] S[table-format=1.2]",
    paste0("\\multicolumn{1}{l}{\\boldmath$n$} & \\multicolumn{1}{l}{\\boldmath$\\alpha$} & ",
      "\\multicolumn{1}{l}{\\textbf{Horizon}} & \\multicolumn{1}{l}{\\textbf{Censoring rate}} \\\\"), Rows,
    "The potential censoring time is exponential, generated independently of frailty and the event processes before censoring. MAR and switching both components share the observed histories. Each is evaluated against its matching population target. Time is measured in years and the censoring rate is per year.")
  Files <- c(Files, File)
  Standalone <- c("\\documentclass[11pt]{article}", "\\usepackage[margin=20mm]{geometry}",
    "\\usepackage[T1]{fontenc}", "\\usepackage{booktabs,siunitx,caption,ragged2e,placeins}",
    "\\sisetup{detect-all}", "\\begin{document}",
    "\\noindent Simulation study 2: completion and interval performance.\\par\\medskip",
    unlist(lapply(Files, function(Name) c(paste0("\\input{", Name, "}"), "\\FloatBarrier"))), "\\end{document}")
  writeLines(Standalone, file.path(Directory, "SimulationTables.tex"))
}
